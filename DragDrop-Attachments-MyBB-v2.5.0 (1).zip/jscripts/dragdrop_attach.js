/**
 * DragDrop Attachments — MyBB 1.8 plugin (v2.3.0)
 *
 * Drag & drop, browse, paste and AJAX (progress) uploads for:
 *  - New Thread / New Reply / Edit Post forms
 *  - Forum Quick Reply
 *  - Private Message compose + PM Quick Reply
 *
 * v2.2.0 UI/UX:
 *  - Radial percentage ring + live speed / bytes / elapsed waiting counter
 *  - Zone-level busy chip while the upload queue is active
 *  - Professional post attachment cards (postbit_attachments decoration)
 *
 * v2.3.0 UI/UX:
 *  - Download gate: postbit file-card links route through a professional
 *    redirect page with an Aurora Glass countdown (server-rendered; the
 *    server decides via the "wait" config whether links get ddawait=1)
 *
 * The server renders every interface element from native MyBB templates;
 * this script only wires events, performs the XHR uploads and swaps in the
 * server-rendered rows.
 *
 * Global contract (see dragdrop_jsinit template):
 *   window.DragDropAttach = [ {config}, ... ]
 */
(function () {
        "use strict";

        var registry = [];

        /* ------------------------------------------------------------------ */
        /* Tiny DOM helpers                                                    */
        /* ------------------------------------------------------------------ */

        function $(sel, root) {
                return (root || document).querySelector(sel);
        }

        function $all(sel, root) {
                return Array.prototype.slice.call((root || document).querySelectorAll(sel));
        }

        function make(tag, cls) {
                var node = document.createElement(tag);
                if (cls) {
                        node.className = cls;
                }
                return node;
        }

        function closest(node, selector) {
                while (node && node !== document) {
                        if (node.matches && node.matches(selector)) {
                                return node;
                        }
                        node = node.parentNode;
                }
                return null;
        }

        function formOf(zone) {
                return closest(zone, "form");
        }

        /* ------------------------------------------------------------------ */
        /* Boot: consume window.DragDropAttach configs (before & after load)   */
        /* ------------------------------------------------------------------ */

        function boot() {
                var list = window.DragDropAttach || [];
                for (var i = 0; i < list.length; i++) {
                        // Only mark a config as ready once its zone was actually wired;
                        // boot() re-runs on DOMContentLoaded so late markup is covered.
                        if (list[i] && !list[i].__ddReady) {
                                if (initZone(list[i])) {
                                        list[i].__ddReady = true;
                                }
                        }
                }

                // v2.2.0: professional postbit attachment cards (read-side,
                // runs on every page the script is loaded on; idempotent).
                try {
                        enhancePostbit();
                } catch (err) {}
        }

        // Wrap push() so configs arriving later are handled as well.
        (function () {
                if (!window.DragDropAttach) {
                        window.DragDropAttach = [];
                }
                var nativePush = window.DragDropAttach.push;
                window.DragDropAttach.push = function () {
                        var result = nativePush.apply(this, arguments);
                        boot();
                        return result;
                };
        })();

        if (document.readyState === "loading") {
                document.addEventListener("DOMContentLoaded", boot);
        } else {
                boot();
        }

        /* ------------------------------------------------------------------ */
        /* Zone initialisation                                                 */
        /* ------------------------------------------------------------------ */

        function initZone(cfg) {
                // Read-side decoration config (showthread pages without any
                // upload zone) — nothing to wire, the boot() call above
                // already ran the postbit decorator.
                if (cfg.context === "postbit") {
                        // v2.3.0: countdown seconds for the download gate
                        // (0 = gate disabled — links stay direct).
                        pbWait = (parseInt(cfg.wait, 10) > 0) ? parseInt(cfg.wait, 10) : 0;
                        return true;
                }

                var zone = document.getElementById(cfg.id);

                // JS-injected fallback (PM compose has no stable server-side anchor)
                if (!zone && cfg.fallback) {
                        if (!injectFallback(cfg)) {
                                return false;
                        }
                        zone = document.getElementById(cfg.id);
                }

                if (!zone) {
                        return false;
                }

                /* Attach the config to the zone element — every handler
                   (upload, remove, posthash) reads it back via zone.__cfg.
                   Missing this made uploads fail silently in earlier releases. */
                zone.__cfg = cfg;

                var drop = $(".ddattach-drop", zone);
                var input = $(".ddattach-fileinput", zone);
                var list = $(".ddattach-list", zone);

                if (cfg.hideNative) {
                        hideNativeBox(zone);
                }

                if (drop && input) {
                        drop.addEventListener("click", function (e) {
                                if (e.target && e.target.tagName && e.target.tagName.toLowerCase() === "button") {
                                        return;
                                }
                                input.click();
                        });

                        drop.addEventListener("keydown", function (e) {
                                if (e.keyCode === 13 || e.keyCode === 32) {
                                        e.preventDefault();
                                        input.click();
                                }
                        });

                        input.addEventListener("change", function () {
                                addFiles(zone, input.files);
                                input.value = "";
                        });

                        /* 2026 UX: depth-counted drag state. Moving the pointer
                           between child elements no longer flickers the highlight,
                           and dragging plain text/links is ignored entirely. */
                        var depth = 0;

                        drop.addEventListener("dragenter", function (e) {
                                e.preventDefault();
                                e.stopPropagation();
                                if (!dragHasFiles(e)) {
                                        return;
                                }
                                depth++;
                                drop.classList.add("ddattach-over");
                                swapDragText(drop, true);
                        });

                        drop.addEventListener("dragover", function (e) {
                                e.preventDefault();
                                e.stopPropagation();
                        });

                        drop.addEventListener("dragleave", function (e) {
                                var to = e.relatedTarget;
                                if (to && drop.contains(to)) {
                                        return; /* still inside the zone */
                                }
                                depth = Math.max(0, depth - 1);
                                if (depth === 0) {
                                        drop.classList.remove("ddattach-over");
                                        swapDragText(drop, false);
                                }
                        });

                        drop.addEventListener("dragend", function () {
                                depth = 0;
                                drop.classList.remove("ddattach-over");
                                swapDragText(drop, false);
                        });

                        drop.addEventListener("drop", function (e) {
                                e.preventDefault();
                                e.stopPropagation();
                                depth = 0;
                                drop.classList.remove("ddattach-over");
                                swapDragText(drop, false);
                                if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) {
                                        addFiles(zone, e.dataTransfer.files);
                                }
                        });
                }

                bindPaste(zone);
                bindResetWatcher(zone, cfg);
                detectTheme(zone);

                return true;
        }

        /* ------------------------------------------------------------------ */
        /* 2026 drop-zone helpers                                              */
        /* ------------------------------------------------------------------ */

        /** True when the dragged payload actually contains files. */
        function dragHasFiles(e) {
                var dt = e.dataTransfer;
                if (!dt || !dt.types) {
                        return false;
                }
                for (var i = 0; i < dt.types.length; i++) {
                        if (String(dt.types[i]).toLowerCase() === "files") {
                                return true;
                        }
                }
                return false;
        }

        /** Swap the headline while dragging ("Drop your files now"). */
        function swapDragText(drop, active) {
                var title = drop.querySelector(".ddattach-drop-title");
                if (!title) {
                        return;
                }
                var activeText = title.getAttribute("data-dd-active");
                var defaultText = title.getAttribute("data-dd-default");
                if (!activeText) {
                        return;
                }
                title.textContent = active ? activeText : (defaultText || title.textContent);
        }

        /**
         * Theme-adaptive design: sample the first opaque ancestor background
         * and mark the zone dark or light so the glass tokens stay readable
         * on any MyBB theme.
         */
        function detectTheme(zone) {
                if (zone.getAttribute("data-dd-theme-done")) {
                        return;
                }
                zone.setAttribute("data-dd-theme-done", "1");

                var node = zone;
                var lum = null;

                while (node && node !== document.documentElement) {
                        var bg = "";
                        try {
                                bg = window.getComputedStyle(node).backgroundColor;
                        } catch (err) {
                                bg = "";
                        }
                        var m = /rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+)\s*)?\)/.exec(bg);
                        if (m) {
                                var alpha = (m[4] === undefined) ? 1 : parseFloat(m[4]);
                                if (alpha > 0.5) {
                                        lum = 0.299 * (+m[1]) + 0.587 * (+m[2]) + 0.114 * (+m[3]);
                                        break;
                                }
                        }
                        node = node.parentNode;
                }

                zone.classList.add(lum !== null && lum < 128 ? "ddattach-dark" : "ddattach-light");
        }

        function injectFallback(cfg) {
                var form = findForm(cfg);
                if (!form || !cfg.fallback) {
                        return false;
                }

                var holder = make("div");
                holder.innerHTML = cfg.fallback;
                var node = holder.firstElementChild;

                if (!node) {
                        return false;
                }

                var table = form.querySelector("table");
                if (table && table.parentNode === form) {
                        form.insertBefore(node, table);
                } else {
                        form.appendChild(node);
                }

                return true;
        }

        function findForm(cfg) {
                if (cfg.context === "pm") {
                        var forms = $all("form[action*='private.php']");
                        for (var i = 0; i < forms.length; i++) {
                                if ($("textarea[name='message']", forms[i])) {
                                        return forms[i];
                                }
                        }
                        return forms.length ? forms[0] : null;
                }

                var quick = document.getElementById("quick_reply_form");
                if (quick) {
                        return quick;
                }

                return $("form[name='input']") || $("form");
        }

        function hideNativeBox(zone) {
                var sibling = zone.previousElementSibling;
                if (sibling && sibling.tagName === "TABLE") {
                        sibling.style.display = "none";
                }
        }

        /* ------------------------------------------------------------------ */
        /* Posthash resolution (live-aware: quick reply AJAX rotates it)       */
        /* ------------------------------------------------------------------ */

        function validHash(value) {
                return value && /^[a-f0-9]{32}$/.test(value);
        }

        function currentPosthash(zone) {
                var cfg = zone.__cfg;
                var form = formOf(zone);

                if (form) {
                        // Core quick reply input carries id="posthash" and is rotated by
                        // MyBB after every AJAX quick reply — always prefer it when found.
                        var live = form.querySelector("input#posthash");
                        if (live && validHash(live.value)) {
                                return live.value;
                        }
                }

                var mine = $(".ddattach-posthash", zone);
                if (mine && validHash(mine.value)) {
                        return mine.value;
                }

                return cfg.posthash;
        }

        /* ------------------------------------------------------------------ */
        /* File intake: browse + drop + paste, max files guard, queue          */
        /* ------------------------------------------------------------------ */

        function countStaged(zone) {
                return $all(".ddattach-item", zone).length + pending(zone).length;
        }

        function pending(zone) {
                if (!zone.__queue) {
                        zone.__queue = [];
                }
                return zone.__queue;
        }

        function addFiles(zone, files) {
                var cfg = zone.__cfg;
                var allowed = [];

                for (var i = 0; i < files.length; i++) {
                        allowed.push(files[i]);
                }

                if (cfg.maxFiles > 0) {
                        var room = cfg.maxFiles - countStaged(zone);
                        if (allowed.length > room) {
                                showError(zone, cfg.strings.maxFiles || cfg.strings.errorGeneric);
                                allowed = allowed.slice(0, Math.max(room, 0));
                        }
                }

                var queue = pending(zone);
                for (var j = 0; j < allowed.length; j++) {
                        queue.push(allowed[j]);
                }

                pump(zone);
        }

        function pump(zone) {
                if (zone.__uploading) {
                        return;
                }

                var queue = pending(zone);
                if (!queue.length) {
                        return;
                }

                var file = queue.shift();
                zone.__uploading = true;
                setBusy(zone, true);
                upload(zone, file);
        }

        function clearErrors(zone) {
                $all(".ddattach-error", zone).forEach(function (node) {
                        node.parentNode.removeChild(node);
                });
        }

        function showError(zone, html) {
                clearErrors(zone);
                var list = $(".ddattach-list", zone);
                var row = make("div");
                row.innerHTML = html;
                if (list && row.firstElementChild) {
                        list.appendChild(row.firstElementChild);
                } else if (list) {
                        row.className = "ddattach-error";
                        row.textContent = html;
                        list.appendChild(row);
                }
        }

        /* ------------------------------------------------------------------ */
        /* Upload progress UI (v2.2.0): radial % ring, live speed, elapsed     */
        /* waiting counter and the zone-level busy chip                        */
        /* ------------------------------------------------------------------ */

        function setBusy(zone, on) {
                if (!zone) {
                        return;
                }
                if (on) {
                        zone.classList.add("ddattach-busy");
                } else {
                        zone.classList.remove("ddattach-busy");
                }
        }

        /** Build one progress row from the server-rendered template. */
        function makeProgressRow(zone, file) {
                var cfg = zone.__cfg;
                var list = $(".ddattach-list", zone);
                var holder = make("div");
                holder.innerHTML = cfg.progressHtml || "";
                var prow = holder.firstElementChild;

                if (prow && list) {
                        var name = $(".ddattach-name", prow);
                        if (name) {
                                name.textContent = file.name;
                        }
                        list.appendChild(prow);
                }

                return prow || null;
        }

        /**
         * Paint one progress sample: ring + bar + % + bytes + smoothed speed.
         * The ring fills via the CSS custom property --dda-p (0-100) driving
         * a conic-gradient; the linear bar stays as the fallback/secondary.
         */
        function paintProgress(prow, loaded, total) {
                if (!prow || !total) {
                        return;
                }

                var pct = Math.min(100, Math.round((loaded / total) * 100));
                var ring = $(".ddattach-ring", prow);
                var fill = $(".ddattach-bar-fill", prow);
                var label = $(".ddattach-pct", prow);
                var bytes = $(".ddattach-bytes", prow);

                if (ring) {
                        ring.style.setProperty("--dda-p", pct);
                        ring.setAttribute("aria-valuenow", pct);
                }
                if (fill) {
                        fill.style.width = pct + "%";
                }
                if (label) {
                        label.textContent = pct + "%";
                }
                if (bytes) {
                        bytes.textContent = friendlySize(loaded) + " / " + friendlySize(total);
                }

                // Exponentially smoothed upload speed (samples > 300ms apart)
                var now = (window.performance && performance.now) ? performance.now() : Date.now();
                if (prow.__ddT0 === undefined) {
                        prow.__ddT0 = now;
                        prow.__ddB0 = loaded;
                        prow.__ddSpd = 0;
                }

                var dt = now - prow.__ddT0;
                if (dt > 300 && loaded > prow.__ddB0) {
                        var inst = (loaded - prow.__ddB0) / (dt / 1000);
                        prow.__ddSpd = prow.__ddSpd ? (prow.__ddSpd * 0.7 + inst * 0.3) : inst;
                        prow.__ddT0 = now;
                        prow.__ddB0 = loaded;
                }

                if (prow.__ddSpd > 0) {
                        var spd = $(".ddattach-speed", prow);
                        if (spd) {
                                spd.textContent = friendlySize(prow.__ddSpd) + "/s";
                        }
                }
        }

        /** Waiting counter: elapsed seconds since the row appeared. */
        function startElapsed(prow) {
                if (!prow) {
                        return;
                }
                var el = $(".ddattach-time", prow);
                if (!el) {
                        return;
                }
                var unit = prow.getAttribute("data-dd-sec") || "s";
                var t0 = Date.now();

                prow.__ddTimer = setInterval(function () {
                        if (!prow.parentNode) {
                                stopElapsed(prow);
                                return;
                        }
                        el.textContent = Math.floor((Date.now() - t0) / 1000) + unit;
                }, 500);
        }

        function stopElapsed(prow) {
                if (prow && prow.__ddTimer) {
                        clearInterval(prow.__ddTimer);
                        prow.__ddTimer = null;
                }
        }

        /* ------------------------------------------------------------------ */
        /* Size policy + formatting helpers (v2.0.0)                           */
        /* ------------------------------------------------------------------ */

        function friendlySize(bytes) {
                bytes = Number(bytes) || 0;
                if (bytes >= 1073741824) return (Math.round((bytes / 1073741824) * 100) / 100) + " GB";
                if (bytes >= 1048576) return (Math.round((bytes / 1048576) * 100) / 100) + " MB";
                if (bytes >= 1024) return (Math.round((bytes / 1024) * 100) / 100) + " KB";
                return bytes + " bytes";
        }

        /**
         * Effective max size (bytes, 0 = unlimited) for one file:
         * per-extension rule > global default.
         * The server re-validates with the full priority chain.
         */
        function limitFor(cfg, filename) {
                var ext = "", dot = String(filename).lastIndexOf(".");
                if (dot >= 0 && dot < filename.length - 1) {
                        ext = String(filename).slice(dot + 1).toLowerCase();
                }
                if (cfg.limits && cfg.limits.ext && cfg.limits.ext[ext] > 0) {
                        return cfg.limits.ext[ext];
                }
                if (cfg.limits && cfg.limits.default > 0) {
                        return cfg.limits.default;
                }
                if (cfg.maxSize > 0) {
                        return cfg.maxSize;
                }
                return 0;
        }

        /* ------------------------------------------------------------------ */
        /* XHR upload (dispatcher: size guard → chunked or classic)            */
        /* ------------------------------------------------------------------ */

        function upload(zone, file) {
                var cfg = zone.__cfg;
                clearErrors(zone);

                // Client-side size guard — the server re-validates anyway
                var limit = limitFor(cfg, file.name);
                if (limit > 0 && file.size > limit) {
                        var msg = String(cfg.strings.tooLarge || cfg.strings.errorGeneric || "")
                                .replace("{1}", file.name)
                                .replace("{2}", friendlySize(limit));
                        showError(zone, escapeHtml(msg));
                        pump(zone);
                        return;
                }

                if (cfg.chunkBytes > 0 && file.size > cfg.chunkBytes) {
                        chunkedUpload(zone, file);
                        return;
                }

                classicUpload(zone, file);
        }

        /**
         * Large files are uploaded in fixed-size slices so that every single
         * request stays below PHP's post_max_size / upload_max_filesize.
         * The server reassembles and validates the file on the final slice.
         */
        function chunkedUpload(zone, file) {
                var cfg = zone.__cfg;

                var slice = file.slice || file.webkitSlice || file.mozSlice;
                if (!slice) {
                        classicUpload(zone, file);
                        return;
                }

                var prow = makeProgressRow(zone, file);
                if (prow) {
                        startElapsed(prow);
                }

                var chunkSize = cfg.chunkBytes;
                var total = Math.ceil(file.size / chunkSize);
                var token = "u" + (cfg.uid || 0) + "_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
                var aborted = false;

                function abortServerSide() {
                        try {
                                var fd = new FormData();
                                fd.append("action", "dragdrop_upload");
                                fd.append("my_post_key", cfg.postKey);
                                fd.append("ddcontext", cfg.context);
                                fd.append("posthash", currentPosthash(zone));
                                fd.append("ddchunk", "1");
                                fd.append("ddabort", "1");
                                fd.append("ddtoken", token);

                                var xhr = new XMLHttpRequest();
                                xhr.open("POST", cfg.uploadUrl, true);
                                xhr.send(fd);
                        } catch (e) {}
                }

                function fail(html) {
                        aborted = true;
                        abortServerSide();
                        stopElapsed(prow);
                        if (prow && prow.parentNode) {
                                prow.parentNode.removeChild(prow);
                        }
                        setBusy(zone, false);
                        showError(zone, html);
                        zone.__uploading = false;
                        pump(zone);
                }

                function sendChunk(i) {
                        if (aborted) {
                                return;
                        }

                        var start = i * chunkSize;
                        var blob = slice.call(file, start, Math.min(start + chunkSize, file.size));
                        var last = (i === total - 1);

                        var fd = new FormData();
                        fd.append("action", "dragdrop_upload");
                        fd.append("my_post_key", cfg.postKey);
                        fd.append("ddcontext", cfg.context);
                        fd.append("posthash", currentPosthash(zone));
                        fd.append("fid", cfg.fid || 0);
                        fd.append("pid", cfg.pid || 0);
                        fd.append("ddchunk", "1");
                        fd.append("ddtoken", token);
                        fd.append("ddindex", i);
                        fd.append("ddtotal", total);
                        fd.append("ddchunksize", chunkSize);
                        fd.append("ddsize", file.size);
                        if (last) {
                                fd.append("ddname", file.name);
                        }
                        fd.append("attachment", blob, "chunk_" + i);

                        var xhr = new XMLHttpRequest();
                        xhr.open("POST", cfg.uploadUrl, true);

                        xhr.upload.addEventListener("progress", function (e) {
                                if (!e.lengthComputable) {
                                        return;
                                }
                                paintProgress(prow, start + e.loaded, file.size);
                        });

                        xhr.addEventListener("load", function () {
                                if (aborted) {
                                        return;
                                }

                                var data = parseJson(xhr.responseText);

                                if (!data) {
                                        fail(escapeHtml(cfg.strings.errorGeneric));
                                        return;
                                }

                                if (!data.success) {
                                        fail(data.errorHtml || escapeHtml(data.error || cfg.strings.errorGeneric));
                                        return;
                                }

                                if (!last) {
                                        paintProgress(prow, Math.min((i + 1) * chunkSize, file.size), file.size);
                                        sendChunk(i + 1);
                                        return;
                                }

                                // Final slice accepted — the server replies with the
                                // regular attachment response
                                stopElapsed(prow);
                                if (prow && prow.parentNode) {
                                        prow.parentNode.removeChild(prow);
                                }
                                setBusy(zone, false);

                                appendItem(zone, data.html);
                                updateQuota(zone, data.quota);
                                zone.__uploading = false;
                                pump(zone);
                        });

                        xhr.addEventListener("error", function () {
                                if (!aborted) {
                                        fail(escapeHtml(cfg.strings.errorGeneric));
                                }
                        });

                        xhr.send(fd);
                }

                zone.__uploading = true;
                sendChunk(0);
        }

        function classicUpload(zone, file) {
                var cfg = zone.__cfg;
                clearErrors(zone);

                var prow = makeProgressRow(zone, file);
                if (prow) {
                        startElapsed(prow);
                }

                var fd = new FormData();
                fd.append("action", "dragdrop_upload");
                fd.append("my_post_key", cfg.postKey);
                fd.append("ddcontext", cfg.context);
                fd.append("posthash", currentPosthash(zone));
                fd.append("fid", cfg.fid || 0);
                fd.append("pid", cfg.pid || 0);
                fd.append("attachment", file, file.name);

                var xhr = new XMLHttpRequest();
                xhr.open("POST", cfg.uploadUrl, true);

                xhr.upload.addEventListener("progress", function (e) {
                        if (!e.lengthComputable) {
                                return;
                        }
                        paintProgress(prow, e.loaded, e.total);
                });

                xhr.addEventListener("load", function () {
                        zone.__uploading = false;
                        setBusy(zone, false);
                        stopElapsed(prow);

                        if (prow && prow.parentNode) {
                                prow.parentNode.removeChild(prow);
                        }

                        var data = parseJson(xhr.responseText);

                        if (!data) {
                                showError(zone, cfg.strings.errorGeneric);
                        } else if (data.success) {
                                appendItem(zone, data.html);
                                updateQuota(zone, data.quota);
                        } else if (data.errorHtml) {
                                showError(zone, data.errorHtml);
                        } else if (data.error) {
                                showError(zone, escapeHtml(data.error));
                        } else if (data.errors) {
                                showError(zone, escapeHtml([].concat(data.errors).join("\n")));
                        } else {
                                showError(zone, cfg.strings.errorGeneric);
                        }

                        pump(zone);
                });

                xhr.addEventListener("error", function () {
                        zone.__uploading = false;
                        setBusy(zone, false);
                        stopElapsed(prow);
                        if (prow && prow.parentNode) {
                                prow.parentNode.removeChild(prow);
                        }
                        showError(zone, cfg.strings.errorGeneric);
                        pump(zone);
                });

                xhr.send(fd);
        }

        function parseJson(text) {
                try {
                        return JSON.parse(text);
                } catch (e) {
                        return null;
                }
        }

        function escapeHtml(text) {
                var div = make("div");
                div.textContent = text;
                return div.innerHTML;
        }

        function appendItem(zone, html) {
                var list = $(".ddattach-list", zone);
                if (!list || !html) {
                        return;
                }

                var holder = make("div");
                holder.innerHTML = html;
                var item = holder.firstElementChild;

                if (item) {
                        list.appendChild(item);
                }
        }

        function updateQuota(zone, html) {
                if (typeof html !== "string") {
                        return;
                }

                var existing = $(".ddattach-quota", zone);

                if (html === "") {
                        if (existing && existing.parentNode) {
                                existing.parentNode.removeChild(existing);
                        }
                        return;
                }

                var holder = make("div");
                holder.innerHTML = html;
                var fresh = holder.firstElementChild;

                if (!fresh) {
                        return;
                }

                if (existing && existing.parentNode) {
                        existing.parentNode.replaceChild(fresh, existing);
                } else {
                        zone.appendChild(fresh);
                }
        }

        /* ------------------------------------------------------------------ */
        /* Paste support (plain textarea setups)                               */
        /* ------------------------------------------------------------------ */

        function bindPaste(zone) {
                var form = formOf(zone);
                if (!form || form.__ddPasteBound) {
                        return;
                }
                form.__ddPasteBound = true;

                form.addEventListener("paste", function (e) {
                        if (!e.clipboardData || !e.clipboardData.files || !e.clipboardData.files.length) {
                                return;
                        }
                        addFiles(zone, e.clipboardData.files);
                });
        }

        /* ------------------------------------------------------------------ */
        /* Quick reply reset watcher                                           */
        /* ------------------------------------------------------------------ */

        function bindResetWatcher(zone, cfg) {
                if (!cfg.resetOnPost) {
                        return;
                }

                var form = formOf(zone);
                if (!form || form.__ddResetBound) {
                        return;
                }
                form.__ddResetBound = true;

                form.addEventListener("submit", function () {
                        var before = currentPosthash(zone);
                        var attempts = 0;

                        var timer = setInterval(function () {
                                attempts++;

                                if (attempts > 20 || !document.body.contains(zone)) {
                                        clearInterval(timer);
                                        return;
                                }

                                var now = currentPosthash(zone);
                                if (now !== before) {
                                        clearInterval(timer);
                                        refreshList(zone, cfg, now);
                                }
                        }, 500);
                });
        }

        function refreshList(zone, cfg, posthash) {
                var list = $(".ddattach-list", zone);

                var fd = new FormData();
                fd.append("action", "dragdrop_list");
                fd.append("my_post_key", cfg.postKey);
                fd.append("ddcontext", cfg.context);
                fd.append("posthash", posthash);
                fd.append("pid", cfg.pid || 0);

                var xhr = new XMLHttpRequest();
                xhr.open("POST", cfg.listUrl, true);

                xhr.addEventListener("load", function () {
                        var data = parseJson(xhr.responseText);

                        if (!data || !data.success) {
                                return;
                        }

                        if (list) {
                                list.innerHTML = "";
                                (data.items || []).forEach(function (html) {
                                        appendItem(zone, html);
                                });
                        }

                        updateQuota(zone, data.quota);
                });

                xhr.send(fd);
        }

        /* ------------------------------------------------------------------ */
        /* Professional post attachments (v2.2.0)                              */
        /*                                                                     */
        /* Decorates the NATIVE postbit_attachments fieldset on thread pages:  */
        /*  - thumbnails / inline images -> responsive hover grid cards        */
        /*  - file rows -> cards with a colored extension chip + size +        */
        /*    download glyph                                                   */
        /* Original <a>/<img> nodes are moved, never re-created, so lightbox   */
        /* and Attachment-Preview plugins keep working. Nested core fieldsets  */
        /* (Thumbnails / Images) are folded into the outer box.                */
        /* ------------------------------------------------------------------ */

        var DL_SVG = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>';

        /* v2.3.0: countdown seconds carried by the postbit config — when > 0
           every FILE card link gets ddawait=1 so the server shows the
           professional redirect page with the circular countdown. */
        var pbWait = 0;

        function gateHref(href) {
                if (!href || /[?&]ddawait=/.test(href)) {
                        return href;
                }
                return href + (href.indexOf("?") >= 0 ? "&" : "?") + "ddawait=1";
        }

        var PB_EXT_GROUPS = {
                img: "jpg jpeg jpe gif png bmp webp svg tif tiff avif",
                zip: "zip rar 7z tar gz bz2 xz iso",
                doc: "pdf doc docx xls xlsx ppt pptx txt csv rtf odt ods odp",
                av: "mp4 avi mkv mov wmv flv webm m4v mp3 wav ogg m4a flac aac"
        };

        function pbExtClass(ext) {
                ext = String(ext).toLowerCase();
                for (var key in PB_EXT_GROUPS) {
                        if (PB_EXT_GROUPS[key].split(" ").indexOf(ext) >= 0) {
                                return key;
                        }
                }
                return "gen";
        }

        /** Colored extension chip (falls back to a generic FILE badge). */
        function pbExtChip(name) {
                var ext = "";
                var dot = String(name).lastIndexOf(".");
                if (dot >= 0 && dot < name.length - 1) {
                        ext = name.slice(dot + 1).slice(0, 5);
                }
                var chip = make("span", "dda-pb-icon dda-ext-" + (ext ? pbExtClass(ext) : "gen"));
                chip.textContent = ext ? ext.toUpperCase() : "FILE";
                return chip;
        }

        function enhancePostbit() {
                var boxes = $all("fieldset");
                for (var i = 0; i < boxes.length; i++) {
                        try {
                                decoratePostbit(boxes[i]);
                        } catch (err) {}
                }
        }

        function isAttachmentHref(href) {
                return /attachment\.php\?(aid|thumbnail)=\d+/.test(href || "");
        }

        function decoratePostbit(fs) {
                if (!fs || fs.getAttribute("data-dd-postbit")) {
                        return false;
                }
                if (fs.classList && fs.classList.contains("ddattach-pm-panel")) {
                        return false; // PM panel ships its own design
                }
                if (fs.closest && fs.closest(".ddattach-zone")) {
                        return false; // inside an upload zone — never touch
                }
                if (closest(fs.parentNode, "fieldset")) {
                        return false; // nested box — its outer container handles it
                }

                var anchors = $all("a[href*='attachment.php']", fs).filter(function (a) {
                        return isAttachmentHref(a.getAttribute("href"));
                });

                if (!anchors.length) {
                        return false;
                }

                // Pull the "(size, downloads)" text that follows each file
                // anchor before anything is moved.
                anchors.forEach(function (a) {
                        if (a.querySelector("img")) {
                                return; // image / thumbnail anchor
                        }
                        var buf = "";
                        var node = a.nextSibling;
                        while (node && node.nodeType === 3) {
                                buf += node.nodeValue;
                                var done = node;
                                node = node.nextSibling;
                                if (done.parentNode) {
                                        done.parentNode.removeChild(done);
                                }
                        }
                        var m = /\(([^()]+)\)/.exec(buf);
                        if (m) {
                                a.__ddSize = m[1];
                        }
                });

                var shots = [];
                var files = [];
                anchors.forEach(function (a) {
                        if (a.querySelector("img")) {
                                shots.push(a);
                        } else {
                                files.push(a);
                        }
                });

                fs.setAttribute("data-dd-postbit", "1");

                if (shots.length) {
                        var grid = make("div", "dda-pb-grid");
                        shots.forEach(function (a) {
                                var card = make("div", "dda-pb-shot");
                                var img = a.querySelector("img");
                                if (img) {
                                        img.setAttribute("loading", "lazy");
                                        img.setAttribute("decoding", "async");
                                        if (img.complete && img.naturalWidth) {
                                                img.classList.add("dda-loaded");
                                        } else {
                                                img.addEventListener("load", function () {
                                                        img.classList.add("dda-loaded");
                                                });
                                                img.addEventListener("error", function () {
                                                        img.classList.add("dda-loaded");
                                                });
                                        }
                                }
                                card.appendChild(a);
                                grid.appendChild(card);
                        });
                        fs.appendChild(grid);
                }

                if (files.length) {
                        var list = make("div", "dda-pb-files");
                        files.forEach(function (a) {
                                var card = make("div", "dda-pb-card");
                                if (pbWait > 0) {
                                        // Route the download through the gate page (v2.3.0)
                                        a.setAttribute("href", gateHref(a.getAttribute("href")));
                                }
                                card.appendChild(pbExtChip((a.textContent || "").trim()));
                                card.appendChild(a);
                                if (a.__ddSize) {
                                        var size = make("span", "dda-pb-size");
                                        size.textContent = "(" + a.__ddSize + ")";
                                        card.appendChild(size);
                                }
                                var dl = make("span", "dda-pb-dl");
                                dl.setAttribute("aria-hidden", "true");
                                dl.innerHTML = DL_SVG;
                                card.appendChild(dl);
                                list.appendChild(card);
                        });
                        fs.appendChild(list);
                }

                // Fold emptied nested fieldsets (Thumbnails / Images groups)
                // into the decorated container and strip separator leftovers.
                $all("fieldset", fs).forEach(function (inner) {
                        var keep = false;
                        for (var c = 0; c < inner.childNodes.length; c++) {
                                var cn = inner.childNodes[c];
                                if (cn.nodeType === 1 && cn.tagName !== "LEGEND" && cn.tagName !== "BR") {
                                        keep = true;
                                        break;
                                }
                                if (cn.nodeType === 3 && cn.nodeValue.replace(/[\s\u00A0]+/g, "")) {
                                        keep = true;
                                        break;
                                }
                        }
                        if (!keep && inner.parentNode) {
                                inner.parentNode.removeChild(inner);
                        }
                });

                var kids = Array.prototype.slice.call(fs.childNodes);
                for (var d = 0; d < kids.length; d++) {
                        var node = kids[d];
                        if (node.nodeType === 1 && node.tagName === "BR" && node.parentNode) {
                                node.parentNode.removeChild(node);
                        } else if (node.nodeType === 3 &&
                                   !node.nodeValue.replace(/[\s\u00A0\u200f\u200e]+/g, "") &&
                                   node.parentNode) {
                                node.parentNode.removeChild(node);
                        }
                }

                detectTheme(fs);
                return true;
        }

        /* ------------------------------------------------------------------ */
        /* Public API used by the rendered template buttons                    */
        /* ------------------------------------------------------------------ */

        window.DragDropAttach = window.DragDropAttach || [];

        /** Insert the [attachment=X] BB code into the message editor. */
        window.DragDropAttach.insert = function (aid) {
                var code = "[attachment=" + aid + "]";
                var inserted = false;

                if (window.jQuery) {
                        try {
                                var editor = window.jQuery("#message").sceditor("instance");
                                if (editor) {
                                        editor.insertText(code);
                                        inserted = true;
                                }
                        } catch (e) {
                                inserted = false;
                        }
                }

                if (!inserted) {
                        var textarea = document.getElementById("message");
                        if (textarea && "selectionStart" in textarea) {
                                var start = textarea.selectionStart;
                                var end = textarea.selectionEnd;
                                textarea.value = textarea.value.substring(0, start) + code + textarea.value.substring(end);
                                textarea.selectionStart = textarea.selectionEnd = start + code.length;
                                textarea.focus();
                        } else if (textarea) {
                                textarea.value += code;
                        }
                }

                return false;
        };

        /** Remove a staged (unclaimed) attachment via AJAX. */
        window.DragDropAttach.remove = function (aid, btn) {
                var zone = closest(btn, ".ddattach-zone");
                if (!zone || !zone.__cfg) {
                        return false;
                }

                var cfg = zone.__cfg;

                if (!window.confirm(cfg.strings.removeConfirm)) {
                        return false;
                }

                var fd = new FormData();
                fd.append("action", "dragdrop_remove");
                fd.append("my_post_key", cfg.postKey);
                fd.append("aid", aid);
                fd.append("posthash", currentPosthash(zone));

                var xhr = new XMLHttpRequest();
                xhr.open("POST", cfg.removeUrl, true);

                xhr.addEventListener("load", function () {
                        var data = parseJson(xhr.responseText);

                        if (data && data.success) {
                                var row = closest(btn, ".ddattach-item");
                                if (row && row.parentNode) {
                                        row.parentNode.removeChild(row);
                                }
                                updateQuota(zone, data.quota);
                        } else if (data && data.errorHtml) {
                                showError(zone, data.errorHtml);
                        }
                });

                xhr.send(fd);

                return false;
        };

        /**
         * Remove an attachment already bound to a post (edit mode): delegate to
         * MyBB's own removal flow by filling the attachmentaid/attachmentact
         * hidden inputs of the surrounding form and submitting it.
         */
        window.DragDropAttach.removeClaimed = function (btn, aid, confirmMsg) {
                var form = formOf(btn);

                if (!form) {
                        return false;
                }

                if (confirmMsg && !window.confirm(confirmMsg)) {
                        return false;
                }

                var aidInput = form.querySelector("input[name='attachmentaid']");
                var actInput = form.querySelector("input[name='attachmentact']");

                if (aidInput && actInput) {
                        aidInput.value = aid;
                        actInput.value = "remove";
                        form.submit();
                }

                return false;
        };
})();
