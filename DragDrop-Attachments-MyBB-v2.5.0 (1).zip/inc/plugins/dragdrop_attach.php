<?php
/**
 * DragDrop Attachments — MyBB 1.8 Plugin
 *
 * المرفقات بالسحب والإفلات لمنتديات MyBB
 * Adds drag-and-drop attachment uploads to post forms, quick reply forms and
 * private messages, with image thumbnails, per-usergroup permissions and
 * storage quotas.
 *
 * Features:
 *  - Drag-and-Drop uploads into the reply / message area
 *  - Quick Reply attachment support (posthash system)
 *  - Private Message attachments (compose + PM quick reply)
 *  - Sent Items support (recipient inbox + sender Sent folder)
 *  - Automatic image thumbnails (full-resolution preserved)
 *  - Attachment Preview / lightbox compatible markup
 *  - Template-based design (12 native MyBB templates)
 *  - Per-usergroup upload permissions
 *  - Per-user / per-group / global storage quotas
 *  - Universal file type mode — accept ANY extension (deny-list protected)
 *  - Large file support — chunked uploads bypass PHP's size limits
 *  - Size limits control panel — global + per-extension max file sizes
 *  - 2026 "Aurora Glass" UI — animated drop zone, glassmorphism,
 *    micro-interactions, dark-mode aware, reduced-motion friendly
 *  - Radial percentage ring + live speed / bytes / elapsed waiting counter
 *  - Professional post attachments design — themed cards + thumbnail grid
 *    under posts (postbit_attachments), colored extension chips, image
 *    load-in effects
 *
 * Compatible with MyBB 1.8.x — PHP 7.1+
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 */

if(!defined("IN_MYBB"))
{
        die("Direct initialization of this file is not allowed.<br /><br />Please make sure IN_MYBB is defined.");
}

if(!defined("IN_ADMINCP"))
{
        /**
         * Register hooks at file-include level so that MyBB caches them on
         * activation and restores them on every request (including xmlhttp.php,
         * which does not run the global_start hook).
         */
        $plugins->add_hook("global_start", "dragdrop_attach_global_start");
        $plugins->add_hook("xmlhttp", "dragdrop_attach_xmlhttp");
        $plugins->add_hook("attachment_start", "dragdrop_attach_download_gate");
        $plugins->add_hook("attachment_start", "dragdrop_attach_attachment_serve");
        $plugins->add_hook("datahandler_pm_insert_end", "dragdrop_attach_pm_claim");
        $plugins->add_hook("datahandler_pm_insert_updatedraft_commit", "dragdrop_attach_pm_draft_saved");
}

/**
 * Admin CP integration — the control panel module under
 * Tools & Maintenance. These hooks only fire inside the Admin CP,
 * so registering them unconditionally is harmless on the front-end.
 */
$plugins->add_hook("admin_tools_menu", "dragdrop_attach_admin_menu");
$plugins->add_hook("admin_tools_action_handler", "dragdrop_attach_admin_action_handler");
$plugins->add_hook("admin_tools_permissions", "dragdrop_attach_admin_permissions");

define("DRAGDROP_ATTACH_VERSION", "2.5.0");
define("DRAGDROP_ATTACH_JSVER", "250");

/**
 * v2.5.0 anti-theft protection (hard lock, no trial) — load the
 * (encoded) license module. The module defines
 * dragdrop_attach_license_ok() / _status(). If the file is missing or
 * was tampered with, the fallback stubs below keep the plug-in safe:
 * all front-end features stay LOCKED until the module is restored, and
 * the Admin CP shows a clear warning.
 */
if(is_file(__DIR__."/dragdrop_attach_license.php"))
{
        require_once __DIR__."/dragdrop_attach_license.php";
}

if(!function_exists("dragdrop_attach_license_ok"))
{
        function dragdrop_attach_license_ok()
        {
                return false; // module missing -> features locked
        }
}

if(!function_exists("dragdrop_attach_license_status"))
{
        function dragdrop_attach_license_status()
        {
                return array("state" => "missing", "domain" => "", "master" => false);
        }
}

/**
 * Plugin information (Admin CP plugin list)
 *
 * @return array
 */
function dragdrop_attach_info()
{
        global $lang;

        $lang->load("dragdrop_attach");

        return array(
                "name"          => $lang->dragdrop_attach_name,
                "description"   => $lang->dragdrop_attach_desc,
                "website"       => "https://mybb.com",
                "author"        => "DragDrop Attachments",
                "authorsite"    => "https://mybb.com",
                "version"       => DRAGDROP_ATTACH_VERSION,
                "codename"      => "dragdrop_attach",
                "compatibility" => "18*"
        );
}

/**
 * The 12 plugin templates.
 *
 * @return array title => template body
 */
function dragdrop_attach_default_templates()
{
        $templates = array();

        /* 2026 "Aurora Glass" design system: theme-adaptive tokens, animated
           conic rim, glassmorphism panel, spring micro-interactions, dark-mode
           tuning via .ddattach-dark (set by JS luminance detection).
           v2.2.0 adds: radial % ring, waiting spinner + live metrics, busy
           chip and the professional postbit attachment cards. */
        $templates['dragdrop_css'] = '<style type="text/css">
/* ==== DragDrop Attachments v2.2 — Aurora Glass (2026) ==== */
.ddattach-zone{position:relative;}
.ddattach-zone,.ddattach-postbit{--dda-accent:#4f8ef7;--dda-accent-2:#8b5cf6;--dda-accent-3:#22d3ee;--dda-radius:16px;--dda-glass:linear-gradient(180deg,rgba(129,148,178,.08),rgba(129,148,178,.03));--dda-card:rgba(255,255,255,.55);--dda-line:rgba(100,116,139,.28);--dda-track:rgba(100,116,139,.16);color:inherit;}
.ddattach-zone{margin:8px 0;}
.ddattach-dark{--dda-card:rgba(255,255,255,.055);--dda-line:rgba(255,255,255,.17);--dda-track:rgba(255,255,255,.14);--dda-glass:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.02));}

/* drop panel with animated aurora rim */
.ddattach-drop{position:relative;border-radius:var(--dda-radius);padding:1.6px;background:linear-gradient(135deg,rgba(79,142,247,.55),rgba(139,92,246,.45),rgba(34,211,238,.5));cursor:pointer;overflow:hidden;isolation:isolate;-webkit-user-select:none;user-select:none;-webkit-tap-highlight-color:transparent;transition:transform .3s cubic-bezier(.34,1.56,.64,1),box-shadow .3s ease;}
.ddattach-drop::before{content:"";position:absolute;inset:-150%;z-index:-1;background:conic-gradient(from 0deg,rgba(79,142,247,0) 0deg,rgba(79,142,247,0) 200deg,rgba(79,142,247,.95) 290deg,rgba(139,92,246,.95) 325deg,rgba(34,211,238,.9) 348deg,rgba(79,142,247,0) 360deg);animation:dda-orbit 7s linear infinite;}
.ddattach-drop-inner{position:relative;border-radius:calc(var(--dda-radius) - 1.6px);padding:24px 18px 20px;text-align:center;background:var(--dda-glass);backdrop-filter:blur(10px) saturate(1.35);-webkit-backdrop-filter:blur(10px) saturate(1.35);transition:background .25s ease;}
.ddattach-drop:hover{transform:translateY(-1px);box-shadow:0 10px 28px -14px rgba(99,102,241,.55);}
.ddattach-drop:focus-visible{outline:none;box-shadow:0 0 0 3px rgba(99,102,241,.4);}
.ddattach-drop.ddattach-over{transform:scale(1.013);box-shadow:0 16px 44px -16px rgba(99,102,241,.65),0 0 0 4px rgba(99,102,241,.14);}
.ddattach-drop.ddattach-over::before{animation-duration:1.4s;}
.ddattach-drop.ddattach-over .ddattach-drop-inner{background:linear-gradient(180deg,rgba(79,142,247,.16),rgba(139,92,246,.11));}

/* gradient icon badge */
.ddattach-badge{position:relative;display:inline-flex;align-items:center;justify-content:center;width:58px;height:58px;border-radius:18px;color:#fff;background:linear-gradient(135deg,var(--dda-accent),var(--dda-accent-2));box-shadow:0 12px 26px -10px rgba(79,142,247,.65),inset 0 1px 0 rgba(255,255,255,.35);animation:dda-float 4.5s ease-in-out infinite;transition:transform .4s cubic-bezier(.34,1.56,.64,1),box-shadow .3s ease;}
.ddattach-badge svg{display:block;}
.ddattach-badge::after{content:"";position:absolute;inset:0;border-radius:inherit;box-shadow:0 0 0 0 rgba(99,102,241,.4);animation:dda-pulse 2.8s ease-out infinite;}
.ddattach-drop.ddattach-over .ddattach-badge{transform:translateY(-4px) scale(1.12);box-shadow:0 18px 34px -12px rgba(99,102,241,.75),inset 0 1px 0 rgba(255,255,255,.35);}

/* texts + browse pill */
.ddattach-drop-title{display:block;margin-top:12px;font-size:15px;font-weight:700;letter-spacing:.1px;}
.ddattach-browse-btn{display:inline-block;margin-top:10px;padding:7px 22px;border-radius:999px;font-size:13px;font-weight:600;color:#fff;text-decoration:none;white-space:nowrap;background:linear-gradient(135deg,var(--dda-accent),var(--dda-accent-2));box-shadow:0 8px 18px -8px rgba(79,142,247,.65),inset 0 1px 0 rgba(255,255,255,.28);transition:transform .25s cubic-bezier(.34,1.56,.64,1),box-shadow .25s ease,filter .25s ease;}
.ddattach-drop:hover .ddattach-browse-btn{transform:translateY(-1px);filter:brightness(1.06);}
.ddattach-drop:active .ddattach-browse-btn{transform:scale(.95);}
.ddattach-note{display:block;margin-top:12px;font-size:11.5px;opacity:.7;line-height:1.6;}

/* file cards */
.ddattach-list{margin-top:10px;display:flex;flex-direction:column;gap:6px;}
.ddattach-item,.ddattach-progress{display:flex;align-items:center;gap:10px;padding:8px 11px;border-radius:12px;border:1px solid var(--dda-line);background:var(--dda-card);font-size:12.5px;animation:dda-pop .4s cubic-bezier(.34,1.56,.64,1) both;transition:border-color .2s ease,transform .2s ease,box-shadow .2s ease;}
.ddattach-item:hover,.ddattach-progress:hover{border-color:rgba(99,102,241,.5);transform:translateY(-1px);box-shadow:0 8px 18px -12px rgba(15,23,42,.3);}
.ddattach-item.ddattach-claimed{opacity:.82;}
.ddattach-item .ddattach-name{flex:1 1 auto;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:ltr;text-align:start;}
.ddattach-size{opacity:.62;white-space:nowrap;direction:ltr;font-variant-numeric:tabular-nums;}
.ddattach-thumb{flex:0 0 auto;display:inline-flex;line-height:0;}
.ddattach-mini{width:38px;height:38px;max-width:38px;max-height:38px;object-fit:cover;border-radius:9px;border:1px solid var(--dda-line);background:var(--dda-track);}
.ddattach-ext{display:inline-flex;align-items:center;justify-content:center;min-width:34px;padding:4px 7px;border-radius:8px;font-size:10px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;direction:ltr;color:#fff;background:linear-gradient(135deg,rgba(99,102,241,.92),rgba(139,92,246,.92));box-shadow:inset 0 1px 0 rgba(255,255,255,.28);}
.ddattach-actions{white-space:nowrap;display:inline-flex;gap:5px;}
.ddattach-btn{font-size:11px;font-weight:600;padding:3px 11px !important;border-radius:8px !important;cursor:pointer;border:1px solid var(--dda-line) !important;background:var(--dda-track) !important;color:inherit !important;box-shadow:none !important;transition:border-color .18s ease,color .18s ease,transform .18s ease;}
.ddattach-btn:hover{border-color:var(--dda-accent) !important;color:var(--dda-accent) !important;transform:translateY(-1px);}
.ddattach-btn:active{transform:scale(.95);}

/* ================= upload progress (v2.2.0) =================
   Radial percentage ring + live metrics (status · speed · elapsed) */
.ddattach-progress{align-items:center;gap:13px;}
.ddattach-progress-body{flex:1 1 auto;min-width:0;display:flex;flex-direction:column;gap:5px;}
.ddattach-row1{display:flex;align-items:baseline;justify-content:space-between;gap:10px;}
.ddattach-progress .ddattach-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:ltr;text-align:start;font-weight:600;}
.ddattach-bytes{flex:0 0 auto;font-size:11px;opacity:.62;white-space:nowrap;direction:ltr;font-variant-numeric:tabular-nums;}
.ddattach-bar{flex:1 1 auto;height:8px;border-radius:999px;background:var(--dda-track);overflow:hidden;position:relative;}
.ddattach-bar-fill{height:100%;width:0;border-radius:999px;background:linear-gradient(90deg,var(--dda-accent),var(--dda-accent-2),var(--dda-accent-3),var(--dda-accent));background-size:280% 100%;animation:dda-shimmer 2s linear infinite;transition:width .25s ease;}
.ddattach-metrics{display:flex;align-items:center;gap:8px;font-size:11px;opacity:.78;}
.ddattach-status{display:inline-flex;align-items:center;gap:6px;font-weight:600;white-space:nowrap;}
.ddattach-sep{opacity:.5;}
.ddattach-speed,.ddattach-time{direction:ltr;font-variant-numeric:tabular-nums;white-space:nowrap;}

/* radial percentage ring — conic gradient, JS drives --dda-p (0-100) */
.ddattach-ring{position:relative;flex:0 0 auto;width:54px;height:54px;border-radius:50%;background:conic-gradient(var(--dda-accent) calc(var(--dda-p,0)*1%),var(--dda-track) 0);display:inline-flex;align-items:center;justify-content:center;box-shadow:0 8px 18px -10px rgba(79,142,247,.65);transition:background .35s ease;}
.ddattach-ring::before{content:"";position:absolute;inset:5px;border-radius:50%;background:var(--dda-card);box-shadow:inset 0 1px 3px rgba(15,23,42,.08);}
.ddattach-ring .ddattach-pct{position:relative;z-index:1;font-size:11px;font-weight:800;color:var(--dda-accent);direction:ltr;font-variant-numeric:tabular-nums;}
.ddattach-dark .ddattach-ring::before{background:rgba(18,22,32,.92);}
.ddattach-dark .ddattach-ring .ddattach-pct{color:var(--dda-accent-3);}

/* waiting spinner (status row + busy chip) */
.ddattach-spin{width:12px;height:12px;border-radius:50%;border:2px solid var(--dda-track);border-top-color:var(--dda-accent);animation:dda-rotate .75s linear infinite;flex:0 0 auto;display:inline-block;}
.ddattach-spin-invert{border-color:rgba(255,255,255,.45);border-top-color:#fff;}

/* busy chip — floats above the drop panel while the queue is active */
.ddattach-busy-state{display:none;position:absolute;top:-13px;left:50%;transform:translateX(-50%);z-index:5;align-items:center;gap:7px;padding:5px 15px;border-radius:999px;font-size:11.5px;font-weight:700;color:#fff;white-space:nowrap;pointer-events:none;background:linear-gradient(135deg,var(--dda-accent),var(--dda-accent-2));box-shadow:0 10px 22px -10px rgba(79,142,247,.75),inset 0 1px 0 rgba(255,255,255,.3);}
.ddattach-zone.ddattach-busy .ddattach-busy-state{display:inline-flex;animation:dda-pop .35s cubic-bezier(.34,1.56,.64,1) both;}
.ddattach-zone.ddattach-busy .ddattach-drop::before{animation-duration:1.6s;}

/* quota meter */
.ddattach-quota{margin-top:10px;font-size:11.5px;opacity:.85;}
.ddattach-quota-track{margin-top:5px;height:7px;border-radius:999px;background:var(--dda-track);overflow:hidden;}
.ddattach-quota-fill{height:100%;border-radius:999px;background:linear-gradient(90deg,#34d399,#22d3ee);box-shadow:0 0 10px rgba(52,211,153,.45);transition:width .5s ease;}

/* error card */
.ddattach-error{margin-top:8px;padding:8px 12px;border-radius:11px;border:1px solid rgba(239,68,68,.4);border-inline-start:3px solid #ef4444;background:rgba(239,68,68,.09);color:#b91c1c;font-size:12.5px;animation:dda-pop .3s cubic-bezier(.34,1.56,.64,1) both;}
.ddattach-dark .ddattach-error{color:#fca5a5;}

/* ============ professional post attachments (v2.2.0) ============
   JS decorates the native postbit_attachments fieldset: thumbnails become
   a responsive hover grid, file rows become cards with colored ext chips. */
.ddattach-postbit{position:relative;margin-top:10px;padding:12px 16px;border:1px solid var(--dda-line);border-radius:14px;background:var(--dda-glass);}
.ddattach-postbit legend{font-size:12.5px;font-weight:700;padding:0 8px;letter-spacing:.2px;}
.ddattach-postbit-outer{border:none;background:none;padding:0;margin-top:10px;}
.dda-pb-grid{display:flex;flex-wrap:wrap;gap:10px;margin:2px 0 4px;}
.dda-pb-shot{position:relative;padding:6px;border-radius:12px;border:1px solid var(--dda-line);background:var(--dda-card);line-height:0;transition:transform .3s cubic-bezier(.34,1.56,.64,1),box-shadow .3s ease,border-color .3s ease;}
.dda-pb-shot:hover{transform:translateY(-3px);border-color:rgba(99,102,241,.5);box-shadow:0 14px 30px -16px rgba(15,23,42,.5);}
.dda-pb-shot img.attachment{display:block;max-width:180px;max-height:135px;width:auto;height:auto;border-radius:9px;object-fit:cover;opacity:0;transform:scale(.96);transition:opacity .5s ease,transform .5s cubic-bezier(.34,1.56,.64,1);}
.dda-pb-shot img.attachment.dda-loaded{opacity:1;transform:scale(1);}
.dda-pb-files{margin-top:6px;display:flex;flex-direction:column;gap:7px;}
.dda-pb-card{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:12px;border:1px solid var(--dda-line);background:var(--dda-card);font-size:12.5px;animation:dda-pop .4s cubic-bezier(.34,1.56,.64,1) both;transition:border-color .2s ease,transform .2s ease,box-shadow .2s ease;}
.dda-pb-card:hover{border-color:rgba(99,102,241,.5);transform:translateY(-1px);box-shadow:0 8px 18px -12px rgba(15,23,42,.35);}
.dda-pb-card > a{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;text-decoration:none;}
.dda-pb-card > a:hover{text-decoration:underline;}
.dda-pb-icon{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;min-width:38px;height:34px;padding:0 8px;border-radius:9px;font-size:9.5px;font-weight:800;letter-spacing:.5px;direction:ltr;color:#fff;background:linear-gradient(135deg,rgba(99,102,241,.95),rgba(139,92,246,.95));box-shadow:inset 0 1px 0 rgba(255,255,255,.28);}
.dda-ext-img{background:linear-gradient(135deg,#10b981,#22d3ee);}
.dda-ext-zip{background:linear-gradient(135deg,#8b5cf6,#d946ef);}
.dda-ext-doc{background:linear-gradient(135deg,#4f8ef7,#38bdf8);}
.dda-ext-av{background:linear-gradient(135deg,#f97316,#f43f5e);}
.dda-pb-size{flex:0 0 auto;opacity:.62;font-size:11.5px;white-space:nowrap;direction:ltr;font-variant-numeric:tabular-nums;}
.dda-pb-dl{flex:0 0 auto;display:inline-flex;opacity:.5;transition:opacity .2s ease,transform .2s ease;}
.dda-pb-dl svg{display:block;}
.dda-pb-card:hover .dda-pb-dl{opacity:1;transform:translateY(1px);}

/* PM attachment panels */
.ddattach-pm-panel{margin-top:8px;border:1px solid var(--dda-line);background:var(--dda-glass);border-radius:12px;padding:10px 12px;backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);}
.ddattach-pm-panel legend{padding:0 6px;}
.ddattach-pm-thumbs img.attachment{max-width:140px;max-height:110px;border:1px solid var(--dda-line);border-radius:9px;margin:2px 0;transition:transform .25s ease;}
.ddattach-pm-thumbs img.attachment:hover{transform:scale(1.04);}
.ddattach-pm-inline img.attachment{max-width:100%;height:auto;}
.ddattach-pm-file{margin:3px 0;font-size:12px;}
.ddattach-pm-head{display:block;margin-bottom:2px;}

/* keyframes */
@keyframes dda-orbit{to{transform:rotate(360deg);}}
@keyframes dda-rotate{to{transform:rotate(360deg);}}
@keyframes dda-float{0%,100%{transform:translateY(0);}50%{transform:translateY(-4px);}}
@keyframes dda-pulse{0%{box-shadow:0 0 0 0 rgba(99,102,241,.4);}70%{box-shadow:0 0 0 13px rgba(99,102,241,0);}100%{box-shadow:0 0 0 0 rgba(99,102,241,0);}}
@keyframes dda-pop{from{opacity:0;transform:translateY(7px) scale(.97);}to{opacity:1;transform:translateY(0) scale(1);}}
@keyframes dda-shimmer{0%{background-position:0% 0;}100%{background-position:280% 0;}}

/* accessibility + graceful fallbacks */
@media (prefers-reduced-motion:reduce){.ddattach-drop::before,.ddattach-badge,.ddattach-badge::after,.ddattach-bar-fill,.ddattach-item,.ddattach-progress,.ddattach-error,.ddattach-spin,.dda-pb-card,.dda-pb-shot img.attachment{animation:none !important;}.ddattach-drop,.ddattach-badge,.ddattach-btn,.ddattach-item,.ddattach-progress,.ddattach-browse-btn,.ddattach-spin,.dda-pb-shot,.dda-pb-card,.dda-pb-shot img.attachment,.dda-pb-dl{transition:none !important;}}
@supports not (background:conic-gradient(red,blue)){.ddattach-drop::before{background:linear-gradient(135deg,rgba(79,142,247,.8),rgba(139,92,246,.7),rgba(34,211,238,.8));animation:none;}.ddattach-ring{background:var(--dda-track) !important;}.ddattach-ring::after{content:"";position:absolute;inset:0;border-radius:50%;background:linear-gradient(135deg,var(--dda-accent),var(--dda-accent-2));-webkit-mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0);mask-composite:exclude;padding:3px;}}
</style>';

        $templates['dragdrop_zone'] = '<div class="ddattach-zone" id="{$dd_id}" data-dd="{$dd_id}">
        {$dd_hidden}
        <input type="file" class="ddattach-fileinput" multiple="multiple" style="display:none;" />
        <div class="ddattach-busy-state" aria-live="polite"><span class="ddattach-spin ddattach-spin-invert" aria-hidden="true"></span><span>{$dd_busy}</span></div>
        <div class="ddattach-drop" tabindex="0" role="button" aria-label="{$dd_drop_text}">
                <div class="ddattach-drop-inner">
                        <span class="ddattach-badge">{$dd_icon}</span>
                        <span class="ddattach-drop-title" data-dd-default="{$dd_drop_text}" data-dd-active="{$dd_drop_active}">{$dd_drop_text}</span>
                        <span class="ddattach-browse-btn">{$dd_browse}</span>
                        <span class="ddattach-note smalltext">{$dd_note}</span>
                </div>
        </div>
        <div class="ddattach-list">{$dd_items}</div>
        {$dd_quota}
</div>';

        $templates['dragdrop_item'] = '<div class="ddattach-item" data-aid="{$dd_aid}">
        <span class="ddattach-thumb">{$dd_thumb}</span>
        <span class="ddattach-name">{$dd_name}</span>
        <span class="ddattach-size">({$dd_size})</span>
        <span class="ddattach-actions">{$dd_insert}{$dd_remove}</span>
</div>';

        $templates['dragdrop_item_claimed'] = '<div class="ddattach-item ddattach-claimed" data-aid="{$dd_aid}">
        <span class="ddattach-thumb">{$dd_thumb}</span>
        <span class="ddattach-name">{$dd_name}</span>
        <span class="ddattach-size">({$dd_size})</span>
        <span class="ddattach-actions">{$dd_insert}{$dd_remove}</span>
</div>';

        $templates['dragdrop_progress'] = '<div class="ddattach-progress" data-dd-sec="{$dd_sec}">
        <div class="ddattach-ring" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
                <span class="ddattach-pct">0%</span>
        </div>
        <div class="ddattach-progress-body">
                <div class="ddattach-row1">
                        <span class="ddattach-name">{$dd_name}</span>
                        <span class="ddattach-bytes" dir="ltr">0 / 0</span>
                </div>
                <div class="ddattach-bar"><div class="ddattach-bar-fill"></div></div>
                <div class="ddattach-metrics">
                        <span class="ddattach-status"><span class="ddattach-spin" aria-hidden="true"></span>{$dd_status}</span>
                        <span class="ddattach-sep">&middot;</span>
                        <span class="ddattach-speed" dir="ltr">&mdash;</span>
                        <span class="ddattach-sep">&middot;</span>
                        <span class="ddattach-time" dir="ltr">0{$dd_sec}</span>
                </div>
        </div>
</div>';

        $templates['dragdrop_quota'] = '<div class="ddattach-quota smalltext">
        {$dd_quota_text}
        <div class="ddattach-quota-track"><div class="ddattach-quota-fill" style="width:{$dd_percent}%;"></div></div>
</div>';

        $templates['dragdrop_error'] = '<div class="ddattach-error">{$dd_message}</div>';

        $templates['dragdrop_pm_read'] = '<fieldset class="ddattach-pm-panel">
        <legend><strong>{$dd_title}</strong></legend>
        {$dd_thumbs}
        {$dd_images}
        {$dd_files}
</fieldset>';

        $templates['dragdrop_pm_read_image'] = '<a href="attachment.php?aid={$dd_aid}" target="_blank" class="ddattach-pm-thumb-link" title="{$dd_name}"><img src="attachment.php?thumbnail={$dd_aid}" class="attachment" alt="{$dd_name}" /></a>&nbsp;&nbsp;&nbsp;';

        $templates['dragdrop_pm_read_inline'] = '<a href="attachment.php?aid={$dd_aid}" target="_blank" class="ddattach-pm-inline" title="{$dd_name}"><img src="attachment.php?aid={$dd_aid}" class="attachment" alt="{$dd_name}" /></a>&nbsp;&nbsp;&nbsp;';

        $templates['dragdrop_pm_read_file'] = '<div class="ddattach-pm-file">{$dd_icon}&nbsp;<a href="attachment.php?aid={$dd_aid}{$dd_wait}" target="_blank">{$dd_name}</a> <span class="ddattach-size">({$dd_size})</span> <span class="ddattach-size">{$dd_downloads}</span></div>';

        $templates['dragdrop_jsinit'] = '<script type="text/javascript" src="{$dd_script}"></script>
<script type="text/javascript">
/* <![CDATA[ */
window.DragDropAttach = window.DragDropAttach || [];
window.DragDropAttach.push({$dd_config});
/* ]]> */
</script>';

        return $templates;
}

/**
 * Plugin settings definitions.
 *
 * @return array
 */
function dragdrop_attach_settings()
{
        global $lang;

        return array(
                'dragdrop_attach_enabled' => array(
                        'optionscode' => 'onoff',
                        'value'       => 1,
                ),
                'dragdrop_attach_groups' => array(
                        'optionscode' => 'text',
                        'value'       => '',
                ),
                'dragdrop_attach_pm' => array(
                        'optionscode' => 'onoff',
                        'value'       => 1,
                ),
                'dragdrop_attach_quickreply' => array(
                        'optionscode' => 'onoff',
                        'value'       => 1,
                ),
                'dragdrop_attach_maxfiles' => array(
                        'optionscode' => 'text',
                        'value'       => 10,
                ),
                'dragdrop_attach_quota' => array(
                        'optionscode' => 'text',
                        'value'       => 0,
                ),
                'dragdrop_attach_groupquotas' => array(
                        'optionscode' => 'text',
                        'value'       => '',
                ),
                'dragdrop_attach_insertbutton' => array(
                        'optionscode' => 'onoff',
                        'value'       => 1,
                ),
                'dragdrop_attach_hidenative' => array(
                        'optionscode' => 'onoff',
                        'value'       => 1,
                ),
                'dragdrop_attach_logging' => array(
                        'optionscode' => 'onoff',
                        'value'       => 1,
                ),
                'dragdrop_attach_logdays' => array(
                        'optionscode' => 'text',
                        'value'       => 30,
                ),
                'dragdrop_attach_alltypes' => array(
                        'optionscode' => 'onoff',
                        'value'       => 1,
                ),
                'dragdrop_attach_denyext' => array(
                        'optionscode' => 'textarea',
                        'value'       => 'php,php3,php4,php5,php7,php8,phtml,pht,phar,cgi,pl,asp,aspx,jsp,jspf,shtml,shtm,htaccess,htpasswd',
                ),
                'dragdrop_attach_maxsize' => array(
                        'optionscode' => 'text',
                        'value'       => 0,
                ),
                'dragdrop_attach_extsizes' => array(
                        'optionscode' => 'textarea',
                        'value'       => '',
                ),
                'dragdrop_attach_chunk' => array(
                        'optionscode' => 'text',
                        'value'       => 4,
                ),
                'dragdrop_attach_postbit' => array(
                        'optionscode' => 'onoff',
                        'value'       => 1,
                ),
                'dragdrop_attach_dlwait' => array(
                        'optionscode' => 'onoff',
                        'value'       => 1,
                ),
                'dragdrop_attach_dlwait_time' => array(
                        'optionscode' => 'text',
                        'value'       => 5,
                ),
                'dragdrop_attach_dlwait_skip' => array(
                        'optionscode' => 'onoff',
                        'value'       => 1,
                ),
                'dragdrop_attach_license' => array(
                        'optionscode' => 'text',
                        'value'       => '',
                ),
        );
}

/**
 * Whether the plugin is installed.
 *
 * @return bool
 */
function dragdrop_attach_is_installed()
{
        global $db;

        return $db->table_exists("dragdrop_pm");
}

/**
 * Install: table + settings + templates.
 */
function dragdrop_attach_install()
{
        global $db, $lang, $cache;

        $lang->load("dragdrop_attach");

        // ------------------------------------------------------------------
        // 1. PM attachment mapping table
        // ------------------------------------------------------------------
        if(!$db->table_exists("dragdrop_pm"))
        {
                $db->write_query("CREATE TABLE ".TABLE_PREFIX."dragdrop_pm (
                        pmaid int unsigned NOT NULL auto_increment,
                        aid int unsigned NOT NULL default '0',
                        pmid int unsigned NOT NULL default '0',
                        uid int unsigned NOT NULL default '0',
                        is_draft tinyint(1) NOT NULL default '0',
                        PRIMARY KEY (pmaid),
                        KEY aid (aid),
                        KEY pmid (pmid),
                        KEY uid (uid)
                ) ENGINE=MyISAM".$db->build_create_table_collation().";");
        }

        // ------------------------------------------------------------------
        // 1b. Upload activity log table (Admin CP → Tools → DragDrop)
        // ------------------------------------------------------------------
        dragdrop_attach_create_log_table();

        // ------------------------------------------------------------------
        // 1c. Grant the Admin CP module permission to existing admins
        // ------------------------------------------------------------------
        dragdrop_attach_grant_admin_permission();

        // ------------------------------------------------------------------
        // 2. Settings group + settings
        // ------------------------------------------------------------------
        $query = $db->simple_select("settinggroups", "gid", "name = 'dragdrop_attach'");
        $gid = (int)$db->fetch_field($query, "gid");

        if(!$gid)
        {
                $group = array(
                        "name"        => "dragdrop_attach",
                        "title"       => $db->escape_string($lang->dragdrop_attach_name),
                        "description" => $db->escape_string($lang->dragdrop_attach_group_desc),
                        "disporder"   => "68",
                        "isdefault"   => 0
                );
                $gid = (int)$db->insert_query("settinggroups", $group);
        }

        // Remove old copies of our settings before re-inserting (re-install safe)
        $db->delete_query("settings", "gid = '".$gid."'");

        $disporder = 1;
        foreach(dragdrop_attach_settings() as $name => $def)
        {
                $setting = array(
                        "name"        => $db->escape_string($name),
                        "title"       => $db->escape_string($lang->{$name.'_title'}),
                        "description" => $db->escape_string($lang->{$name.'_desc'}),
                        "optionscode" => $db->escape_string($def['optionscode']),
                        "value"       => $db->escape_string($def['value']),
                        "disporder"   => $disporder,
                        "gid"         => $gid,
                        "isdefault"   => 0
                );
                $db->insert_query("settings", $setting);
                $disporder++;
        }

        rebuild_settings();

        // ------------------------------------------------------------------
        // 3. Templates (Global set, sid = -2)
        // ------------------------------------------------------------------
        dragdrop_attach_install_templates();
}

/**
 * (Re-)install the plugin templates into the global template set.
 */
function dragdrop_attach_install_templates()
{
        global $db;

        $titles = array();
        foreach(dragdrop_attach_default_templates() as $title => $template)
        {
                $titles[] = $db->escape_string($title);
        }

        if(!empty($titles))
        {
                $db->delete_query("templates", "title IN ('".implode("','", $titles)."') AND sid = '-2'");
        }

        foreach(dragdrop_attach_default_templates() as $title => $template)
        {
                $insert = array(
                        "title"    => $db->escape_string($title),
                        "template" => $db->escape_string($template),
                        "sid"      => -2,
                        "version"  => DRAGDROP_ATTACH_VERSION,
                        "dateline" => TIME_NOW
                );
                $db->insert_query("templates", $insert);
        }
}

/**
 * Activate.
 */
function dragdrop_attach_activate()
{
        global $db, $lang;

        $lang->load("dragdrop_attach");

        if(!dragdrop_attach_is_installed())
        {
                dragdrop_attach_install();
                return;
        }

        // Upgrade path: add new tables/settings/permissions introduced by
        // later releases without touching any of the user's saved values.
        dragdrop_attach_migrate();

        // Make sure templates are present and up to date.
        dragdrop_attach_install_templates();
}

/**
 * Create the upload activity log table when it does not exist yet.
 */
function dragdrop_attach_create_log_table()
{
        global $db;

        if(!$db->table_exists("dragdrop_log"))
        {
                $db->write_query("CREATE TABLE ".TABLE_PREFIX."dragdrop_log (
                        lid int unsigned NOT NULL auto_increment,
                        uid int unsigned NOT NULL default '0',
                        username varchar(120) NOT NULL default '',
                        filename varchar(255) NOT NULL default '',
                        filesize int unsigned NOT NULL default '0',
                        fileext varchar(10) NOT NULL default '',
                        context varchar(10) NOT NULL default 'post',
                        status varchar(12) NOT NULL default 'ok',
                        message varchar(255) NOT NULL default '',
                        ipaddress varchar(45) NOT NULL default '',
                        dateline int unsigned NOT NULL default '0',
                        PRIMARY KEY (lid),
                        KEY uid (uid),
                        KEY dateline (dateline),
                        KEY status (status)
                ) ENGINE=MyISAM".$db->build_create_table_collation().";");
        }
}

/**
 * Grant the Tools → DragDrop Attachments module permission to
 * existing administrators (super admins are always allowed).
 */
function dragdrop_attach_grant_admin_permission()
{
        if(!function_exists("change_admin_permission"))
        {
                @include_once MYBB_ROOT."admin/inc/functions.php";
        }

        if(function_exists("change_admin_permission"))
        {
                change_admin_permission("tools", "dragdrop_attach", 1);
        }
}

/**
 * Remove the Admin CP module permission (uninstall only).
 */
function dragdrop_attach_revoke_admin_permission()
{
        if(!function_exists("change_admin_permission"))
        {
                @include_once MYBB_ROOT."admin/inc/functions.php";
        }

        if(function_exists("change_admin_permission"))
        {
                change_admin_permission("tools", "dragdrop_attach", -1);
        }
}

/**
 * Idempotent upgrade: creates the log table, inserts any settings that
 * appeared after the user installed (keeping their current values) and
 * refreshes the Admin CP permission. Runs on every (re-)activation.
 */
function dragdrop_attach_migrate()
{
        global $db, $lang;

        // 1. Log table (introduced in 1.1.0)
        dragdrop_attach_create_log_table();

        // 2. Settings added after the initial release
        $query = $db->simple_select("settinggroups", "gid", "name = 'dragdrop_attach'");
        $gid = (int)$db->fetch_field($query, "gid");

        if(!$gid)
        {
                $group = array(
                        "name"        => "dragdrop_attach",
                        "title"       => $db->escape_string($lang->dragdrop_attach_name),
                        "description" => $db->escape_string($lang->dragdrop_attach_group_desc),
                        "disporder"   => "68",
                        "isdefault"   => 0
                );
                $gid = (int)$db->insert_query("settinggroups", $group);
        }

        $disporder = 20;

        foreach(dragdrop_attach_settings() as $name => $def)
        {
                $query = $db->simple_select("settings", "sid", "name = '".$db->escape_string($name)."'");
                $sid = (int)$db->fetch_field($query, "sid");

                if($sid > 0)
                {
                        continue; // keep the administrator's current value
                }

                $setting = array(
                        "name"        => $db->escape_string($name),
                        "title"       => $db->escape_string($lang->{$name.'_title'}),
                        "description" => $db->escape_string($lang->{$name.'_desc'}),
                        "optionscode" => $db->escape_string($def['optionscode']),
                        "value"       => $db->escape_string($def['value']),
                        "disporder"   => $disporder,
                        "gid"         => $gid,
                        "isdefault"   => 0
                );
                $db->insert_query("settings", $setting);
                $disporder++;
        }

        rebuild_settings();

        // 2b. v2.5.0: the trial system was removed — drop the two
        // obsolete settings (enforcement toggle + trial clock stamp)
        // left behind by 2.4.x installs.
        $db->delete_query("settings", "name IN ('dragdrop_attach_enforce','dragdrop_attach_licstart')");

        // 3. Admin CP module permission
        dragdrop_attach_grant_admin_permission();
}

/**
 * Deactivate (nothing destructive — settings and data are preserved).
 */
function dragdrop_attach_deactivate()
{
        // Intentionally left empty.
}

/**
 * Uninstall: remove table, settings and templates.
 */
function dragdrop_attach_uninstall()
{
        global $db, $cache;

        if($db->table_exists("dragdrop_pm"))
        {
                $db->drop_table("dragdrop_pm");
        }

        if($db->table_exists("dragdrop_log"))
        {
                $db->drop_table("dragdrop_log");
        }

        dragdrop_attach_revoke_admin_permission();

        $db->delete_query("settings", "name LIKE 'dragdrop_attach_%'");

        $query = $db->simple_select("settinggroups", "gid", "name = 'dragdrop_attach'");
        $gid = (int)$db->fetch_field($query, "gid");
        if($gid)
        {
                $db->delete_query("settinggroups", "gid = '".$gid."'");
        }

        $titles = array();
        foreach(dragdrop_attach_default_templates() as $title => $template)
        {
                $titles[] = $db->escape_string($title);
        }
        if(!empty($titles))
        {
                $db->delete_query("templates", "title IN ('".implode("','", $titles)."')");
        }

        rebuild_settings();
}

// ======================================================================
// Bootstrap
// ======================================================================

/**
 * global_start: load language and register page-level hooks.
 */
function dragdrop_attach_global_start()
{
        global $mybb, $lang, $plugins;

        if(!defined("THIS_SCRIPT"))
        {
                return;
        }

        $lang->load("dragdrop_attach");

        if(dragdrop_attach_enabled() !== true)
        {
                return;
        }

        // v2.5.0 anti-theft (hard lock): without a valid license key the
        // forum keeps working but every plug-in front-end feature is off.
        if(!dragdrop_attach_license_ok())
        {
                return;
        }

        switch(THIS_SCRIPT)
        {
                case "newthread.php":
                        $plugins->add_hook("newthread_end", "dragdrop_attach_fullform");
                        break;

                case "newreply.php":
                        $plugins->add_hook("newreply_end", "dragdrop_attach_fullform");
                        break;

                case "editpost.php":
                        $plugins->add_hook("editpost_end", "dragdrop_attach_fullform");
                        break;

                case "showthread.php":
                        if($mybb->settings['dragdrop_attach_postbit'] == 1)
                        {
                                // v2.2.0: restyle the native postbit_attachments box
                                // (works for every viewer — guests included)
                                $plugins->add_hook("showthread_end", "dragdrop_attach_postbit_assets");
                        }
                        if($mybb->settings['dragdrop_attach_quickreply'] == 1)
                        {
                                $plugins->add_hook("showthread_end", "dragdrop_attach_showthread");
                        }
                        break;

                case "private.php":
                        if($mybb->settings['dragdrop_attach_pm'] == 1)
                        {
                                $plugins->add_hook("private_send_end", "dragdrop_attach_pm_compose");
                                $plugins->add_hook("private_read_end", "dragdrop_attach_pm_read");
                        }
                        break;
        }
}

/**
 * Master on/off switch (plugin active + setting enabled + core attachments on).
 *
 * @return bool
 */
function dragdrop_attach_enabled()
{
        global $mybb;

        if($mybb->settings['dragdrop_attach_enabled'] != 1)
        {
                return false;
        }

        if($mybb->settings['enableattachments'] != 1 && THIS_SCRIPT != "attachment.php")
        {
                return false;
        }

        return true;
}

/**
 * Is the current user allowed to upload attachments through this plugin?
 * Guests are always rejected; an empty groups setting means every
 * logged-in member, otherwise a comma separated list of group IDs.
 *
 * @return bool
 */
function dragdrop_attach_user_allowed()
{
        global $mybb;

        if((int)$mybb->user['uid'] === 0)
        {
                return false;
        }

        $groups = trim((string)$mybb->settings['dragdrop_attach_groups']);

        if($groups !== "" && !is_member($groups))
        {
                return false;
        }

        return true;
}

/**
 * Resolve the storage quota in bytes for a user.
 *
 * Priority:
 *  1. per-group overrides   ("2=50,3=200" = gid=MB; 0 MB = unlimited)
 *  2. plugin default quota  (MB, 0 = unlimited)
 *  3. core usergroup quota  (usergroups.attachquota, KB)
 *
 * @param int $uid
 * @return int bytes, 0 = unlimited
 */
function dragdrop_attach_quota_bytes($uid = 0)
{
        global $mybb, $db;

        $raw = trim((string)$mybb->settings['dragdrop_attach_groupquotas']);

        if($raw !== "")
        {
                $best = null;

                foreach(explode(",", $raw) as $pair)
                {
                        $pair = trim($pair);
                        if($pair === "" || strpos($pair, "=") === false)
                        {
                                continue;
                        }

                        list($gid, $mb) = explode("=", $pair, 2);
                        $gid = (int)trim($gid);
                        $mb  = (float)trim($mb);

                        // Entries with 0 are ignored (the default quota then applies)
                        if($gid > 0 && $mb > 0 && is_member($gid, $uid))
                        {
                                if($best === null || $mb * 1048576 > $best)
                                {
                                        $best = (int)round($mb * 1048576);
                                }
                        }
                }

                if($best !== null)
                {
                        return $best; // group override wins (may be 0 = unlimited)
                }
        }

        $mb = (float)$mybb->settings['dragdrop_attach_quota'];
        if($mb > 0)
        {
                return (int)round($mb * 1048576);
        }

        $core = isset($mybb->usergroup['attachquota']) ? (int)$mybb->usergroup['attachquota'] : 0;
        if($core > 0)
        {
                return $core * 1024;
        }

        return 0;
}

/**
 * Current storage usage for a user (post + PM attachments both live in
 * the core attachments table, so a single SUM covers everything).
 *
 * @param int $uid
 * @return int bytes
 */
function dragdrop_attach_usage_bytes($uid)
{
        global $db;

        $uid = (int)$uid;

        $query = $db->simple_select("attachments", "SUM(filesize) AS usage_total", "uid = '".$uid."'");
        return (int)$db->fetch_field($query, "usage_total");
}

// ======================================================================
// File type & size policy (v2.0.0)
// ======================================================================

/**
 * Extensions that can be executed by the web server itself. These are
 * ALWAYS denied, even in universal file type mode, and cannot be removed
 * from the Admin CP deny list.
 *
 * @return array
 */
function dragdrop_attach_builtin_denied()
{
        return array(
                "php", "php3", "php4", "php5", "php7", "php8", "phtml", "pht", "phar",
                "cgi", "pl", "asp", "aspx", "jsp", "jspf", "shtml", "shtm",
                "htaccess", "htpasswd"
        );
}

/**
 * The effective deny list: built-in executables + the administrator's
 * extra extensions from the "Size limits" control panel tab.
 *
 * @return array lowercase extensions
 */
function dragdrop_attach_deny_list()
{
        global $mybb;

        $list = dragdrop_attach_builtin_denied();

        $raw = isset($mybb->settings['dragdrop_attach_denyext'])
                ? (string)$mybb->settings['dragdrop_attach_denyext'] : "";

        foreach(preg_split('#[\s,]+#', my_strtolower($raw)) as $ext)
        {
                $ext = preg_replace('#[^a-z0-9]#', '', $ext);

                if($ext !== "")
                {
                        $list[] = $ext;
                }
        }

        return array_values(array_unique($list));
}

/**
 * Whether universal file type mode is enabled (accept any extension that
 * is not denied, even when not defined in the core attachment types).
 *
 * @return bool
 */
function dragdrop_attach_all_types()
{
        global $mybb;

        return isset($mybb->settings['dragdrop_attach_alltypes'])
                && (int)$mybb->settings['dragdrop_attach_alltypes'] === 1;
}

/**
 * Parse the per-extension size rules setting ("zip=500,mp4=800").
 * Accepts commas and newlines as separators, MB values with decimals.
 *
 * @return array ext (lowercase) => bytes
 */
function dragdrop_attach_parse_extsizes()
{
        global $mybb;

        $rules = array();

        $raw = isset($mybb->settings['dragdrop_attach_extsizes'])
                ? (string)$mybb->settings['dragdrop_attach_extsizes'] : "";

        foreach(preg_split('#[\r\n,]+#', $raw) as $pair)
        {
                $pair = trim($pair);

                if($pair === "" || strpos($pair, "=") === false)
                {
                        continue;
                }

                list($ext, $mb) = explode("=", $pair, 2);
                $ext = my_strtolower(preg_replace('#[^a-z0-9]#i', '', trim($ext)));
                $mb  = (float)str_replace(",", ".", trim($mb));

                if($ext !== "" && $mb > 0)
                {
                        $rules[$ext] = (int)round(min($mb, 1000000) * 1048576); // 1 TB sanity cap
                }
        }

        return $rules;
}

/**
 * Resolve the effective maximum size for one file, in bytes.
 *
 * Priority:
 *  1. per-extension rule from the size limits panel
 *  2. global plugin max size (dragdrop_attach_maxsize, MB)
 *  3. the core attachment type limit (attachtypes.maxsize, KB)
 *  4. 0 = unlimited
 *
 * @param string    $ext          lowercase extension
 * @param int|null  $type_maxsize attachtypes.maxsize in KB (null = unregistered type)
 * @return int bytes (0 = unlimited)
 */
function dragdrop_attach_file_limit($ext, $type_maxsize = null)
{
        global $mybb;

        $rules = dragdrop_attach_parse_extsizes();
        $ext = my_strtolower((string)$ext);

        if(isset($rules[$ext]))
        {
                return $rules[$ext];
        }

        $global = (float)(isset($mybb->settings['dragdrop_attach_maxsize'])
                ? $mybb->settings['dragdrop_attach_maxsize'] : 0);

        if($global > 0)
        {
                return (int)round($global * 1048576);
        }

        if($type_maxsize !== null && (int)$type_maxsize > 0)
        {
                return (int)$type_maxsize * 1024;
        }

        return 0;
}

/**
 * Chunked-upload threshold in bytes (files above this size are uploaded
 * in slices, bypassing PHP's post_max_size / upload_max_filesize).
 *
 * @return int bytes (0 = chunking disabled)
 */
function dragdrop_attach_chunk_bytes()
{
        global $mybb;

        $mb = isset($mybb->settings['dragdrop_attach_chunk'])
                ? (float)$mybb->settings['dragdrop_attach_chunk'] : 4;

        if($mb <= 0)
        {
                return 0;
        }

        return (int)round(min($mb, 32) * 1048576); // hard cap 32 MB per slice
}

/**
 * The chunk staging directory (uploads/dragdrop_tmp), created on demand.
 *
 * @param bool $create
 * @return string absolute path ("" when creation failed)
 */
function dragdrop_attach_tmp_dir($create = false)
{
        global $mybb;

        $uploadspath = !empty($mybb->settings['uploadspath']) ? $mybb->settings['uploadspath'] : './uploads';
        $dir = mk_path_abs($uploadspath)."/dragdrop_tmp";

        if($create && !is_dir($dir))
        {
                @mkdir($dir, 0755);

                if(is_dir($dir))
                {
                        @file_put_contents($dir."/index.html", "");
                }
        }

        return is_dir($dir) ? $dir : "";
}

/**
 * Remove chunk staging files left behind by aborted uploads.
 *
 * @param int $max_age seconds (default 12 h)
 * @return int deleted count
 */
function dragdrop_attach_chunk_gc($max_age = 43200)
{
        $dir = dragdrop_attach_tmp_dir();

        if($dir === "")
        {
                return 0;
        }

        $deleted = 0;
        $cutoff = TIME_NOW - (int)$max_age;

        if(($dh = @opendir($dir)) !== false)
        {
                while(($entry = readdir($dh)) !== false)
                {
                        if($entry === "." || $entry === ".." || $entry === "index.html")
                        {
                                continue;
                        }

                        $path = $dir."/".$entry;

                        if(is_file($path) && @filemtime($path) < $cutoff)
                        {
                                if(@unlink($path))
                                {
                                        $deleted++;
                                }
                        }
                }

                closedir($dh);
        }

        return $deleted;
}

/**
 * Delete one user's chunk staging file (aborted upload).
 *
 * @param string $token
 * @param int    $uid
 * @return bool
 */
function dragdrop_attach_chunk_delete($token, $uid)
{
        $token = dragdrop_attach_chunk_token($token);

        if($token === "" || (int)$uid === 0 || strpos($token, "u".(int)$uid."_") !== 0)
        {
                return false;
        }

        $dir = dragdrop_attach_tmp_dir();

        if($dir === "")
        {
                return false;
        }

        return @unlink($dir."/".$token.".part");
}

/**
 * Sanitize a chunk token (client-generated, user-owned).
 *
 * @param string $token
 * @return string the sanitized token ("" when invalid)
 */
function dragdrop_attach_chunk_token($token)
{
        $token = preg_replace('#[^a-z0-9_]#i', '', (string)$token);

        if(!preg_match('#^u\d+_[a-z0-9]{6,40}$#i', $token))
        {
                return "";
        }

        return $token;
}

/**
 * Detect a sane MIME type for a stored file (universal file type mode).
 *
 * @param string $path absolute file path
 * @return string MIME type ("" when it cannot be determined)
 */
function dragdrop_attach_detect_mime($path)
{
        $mime = "";

        if(function_exists("finfo_open"))
        {
                $info = @finfo_open(FILEINFO_MIME_TYPE);

                if($info)
                {
                        $mime = (string)@finfo_file($info, $path);
                        finfo_close($info);
                }
        }
        elseif(function_exists("mime_content_type"))
        {
                $mime = (string)@mime_content_type($path);
        }

        if(!preg_match('#^[a-z0-9/\-\.\+]+$#i', $mime))
        {
                return "";
        }

        // Never trust a detected script MIME — force neutral download types
        if(preg_match('#(php|x-httpd|script)#i', $mime))
        {
                return "application/octet-stream";
        }

        return $mime;
}

// ======================================================================
// Rendering helpers (all output is built from plugin templates)
// ======================================================================

/**
 * Render a plugin template with variables.
 *
 * @param string $title template title (without prefix)
 * @param array  $vars  variables
 * @return string
 */
function dragdrop_attach_tpl($title, $vars = array())
{
        global $templates;

        $template = $templates->get("dragdrop_".$title);

        foreach($vars as $key => $value)
        {
                $$key = $value;
        }

        eval("\$rendered = \"".$template."\";");

        return $rendered;
}

/**
 * The drop-zone icon (inline SVG paperclip — theme independent).
 *
 * @return string
 */
function dragdrop_attach_icon_svg()
{
        return '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/></svg>';
}

/**
 * Small extension icon for non-image files.
 *
 * @param string $ext
 * @return string
 */
function dragdrop_attach_ext_icon($ext)
{
        return '<span class="ddattach-ext">'.htmlspecialchars_uni(my_strtoupper($ext)).'</span>';
}

/**
 * Render the storage quota bar (or an empty string when unlimited).
 *
 * @return string
 */
function dragdrop_attach_render_quota()
{
        global $mybb, $lang;

        $quota = dragdrop_attach_quota_bytes((int)$mybb->user['uid']);

        if($quota <= 0)
        {
                return "";
        }

        $used = dragdrop_attach_usage_bytes((int)$mybb->user['uid']);
        $percent = ($used / $quota) * 100;
        if($percent > 100)
        {
                $percent = 100;
        }

        return dragdrop_attach_tpl("quota", array(
                "dd_quota_text" => $lang->sprintf($lang->dragdrop_quota_used, get_friendly_size($used), get_friendly_size($quota)),
                "dd_percent"    => (int)round($percent)
        ));
}

/**
 * Render one row of the upload list.
 *
 * @param array $att     attachment row
 * @param bool  $claimed true when already bound to a post (editpost)
 * @param bool  $insert  show the "insert into post" button
 * @return string
 */
function dragdrop_attach_render_item($att, $claimed = false, $insert = true)
{
        global $mybb, $lang;

        $aid  = (int)$att['aid'];
        $name = htmlspecialchars_uni($att['filename']);
        $size = get_friendly_size((int)$att['filesize']);
        $ext  = my_strtolower(get_extension($att['filename']));

        // Thumbnail / icon
        $thumb = dragdrop_attach_ext_icon($ext);
        if(in_array($ext, array("gif", "png", "jpg", "jpeg", "jpe", "bmp", "webp")))
        {
                if(!empty($att['thumbnail']) && $att['thumbnail'] !== "SMALL")
                {
                        $thumb = '<img class="ddattach-mini" src="attachment.php?thumbnail='.$aid.'" alt="" />';
                }
                else
                {
                        $thumb = '<img class="ddattach-mini" src="attachment.php?aid='.$aid.'" alt="" />';
                }
        }

        // Insert button (posts only — [attachment] BB code does not work in PMs)
        $insert_html = "";
        if($insert && $mybb->settings['dragdrop_attach_insertbutton'] == 1)
        {
                $insert_html = '<input type="button" class="button ddattach-btn" value="'.$lang->dragdrop_insert.'" onclick="return DragDropAttach.insert('.$aid.');" />';
        }

        // Remove button
        if($claimed)
        {
                // Already bound to a post: delegate to MyBB's own removal flow
                $confirm_js = str_replace("'", "\\'", str_replace(array("\r", "\n"), " ", $lang->dragdrop_remove_confirm));
                $remove_html = '<input type="button" class="button ddattach-btn" value="'.$lang->dragdrop_remove.'" onclick="return DragDropAttach.removeClaimed(this, '.$aid.', \''. $confirm_js .'\');" />';
        }
        else
        {
                $remove_html = '<input type="button" class="button ddattach-btn" value="'.$lang->dragdrop_remove.'" onclick="return DragDropAttach.remove('.$aid.', this);" />';
        }

        $tpl = $claimed ? "item_claimed" : "item";

        return dragdrop_attach_tpl($tpl, array(
                "dd_aid"    => $aid,
                "dd_thumb"  => $thumb,
                "dd_name"   => $name,
                "dd_size"   => $size,
                "dd_insert" => $insert_html,
                "dd_remove" => $remove_html
        ));
}

/**
 * Render the complete drop zone.
 *
 * @param string $context "post" or "pm"
 * @param array  $opts    fid, pid, pmid, posthash, mode, items
 * @return string empty when the zone must not be shown
 */
function dragdrop_attach_render_zone($context, $opts = array())
{
        global $mybb, $lang, $cache;

        if(dragdrop_attach_enabled() !== true || !dragdrop_attach_user_allowed())
        {
                return "";
        }

        if($context == "pm" && $mybb->settings['dragdrop_attach_pm'] != 1)
        {
                return "";
        }

        static $cleanup_done = false;
        if(!$cleanup_done)
        {
                $cleanup_done = true;
                dragdrop_attach_cleanup_orphans();
        }

        $posthash = trim((string)(isset($opts['posthash']) ? $opts['posthash'] : $mybb->get_input('posthash')));

        if(!preg_match('#^[a-f0-9]{32}$#', $posthash) && isset($GLOBALS['posthash'])
                && preg_match('#^[a-f0-9]{32}$#', (string)$GLOBALS['posthash']))
        {
                // Quick reply / post forms set a global posthash (showthread.php etc.)
                $posthash = (string)$GLOBALS['posthash'];
        }

        if(!preg_match('#^[a-f0-9]{32}$#', $posthash))
        {
                $posthash = md5($mybb->user['uid']."_".random_str(32));
        }

        $pid  = isset($opts['pid']) ? (int)$opts['pid'] : 0;
        $pmid = isset($opts['pmid']) ? (int)$opts['pmid'] : 0;

        $zone_id = "ddattach_zone_".$context.(($pid > 0) ? "_".$pid : (($pmid > 0) ? "_".$pmid : ""));

        // Hidden posthash field — PM forms have none of their own, and the
        // editpost form omits it as well, so always provide one for our zone.
        $hidden = '<input type="hidden" name="posthash" value="'.htmlspecialchars_uni($posthash).'" class="ddattach-posthash" />';

        // Notes: max files + max size per attachment
        $notes = array();
        $maxfiles = (int)$mybb->settings['dragdrop_attach_maxfiles'];
        if($maxfiles > 0)
        {
                $notes[] = $lang->sprintf($lang->dragdrop_note_maxfiles, $maxfiles);
        }

        // Effective size hint: plugin limit (global / per-type) when set,
        // otherwise the smallest core attachment type limit.
        $limits = dragdrop_attach_file_limit(""); // global level (no ext rule)
        $ext_rules = dragdrop_attach_parse_extsizes();

        if($limits > 0)
        {
                $notes[] = $lang->sprintf($lang->dragdrop_note_maxsize, get_friendly_size($limits));
        }
        elseif(!empty($ext_rules))
        {
                $notes[] = $lang->dragdrop_note_sizerules;
        }
        else
        {
                $maxsize = 0;
                $attachtypes = (array)$cache->read("attachtypes");
                foreach($attachtypes as $at)
                {
                        if(!empty($at['maxsize']) && ($maxsize == 0 || $at['maxsize'] < $maxsize))
                        {
                                $maxsize = (int)$at['maxsize'];
                        }
                }

                if($maxsize > 0)
                {
                        $notes[] = $lang->sprintf($lang->dragdrop_note_maxsize, get_friendly_size($maxsize * 1024));
                }
        }

        if(dragdrop_attach_all_types())
        {
                $notes[] = $lang->dragdrop_note_alltypes;
        }

        // Prefilled (server-rendered) items — unclaimed bucket + claimed on edit
        $items_html = "";
        $items = dragdrop_attach_current_items($context, $posthash, $pid, $pmid, $opts);
        foreach($items as $item)
        {
                $items_html .= $item;
        }

        $zone = dragdrop_attach_tpl("zone", array(
                "dd_id"       => $zone_id,
                "dd_hidden"   => $hidden,
                "dd_icon"     => dragdrop_attach_icon_svg(),
                "dd_drop_text" => $lang->dragdrop_drop_text,
                "dd_drop_active" => isset($lang->dragdrop_drop_active) ? $lang->dragdrop_drop_active : "",
                "dd_browse"   => $lang->dragdrop_browse,
                "dd_note"     => implode(" &middot; ", $notes),
                "dd_items"    => $items_html,
                "dd_busy"     => isset($lang->dragdrop_busy) ? $lang->dragdrop_busy : "",
                "dd_quota"    => dragdrop_attach_render_quota()
        ));

        // Push the page assets (css + js + config) into <head>
        $config = array(
                "id"         => $zone_id,
                "context"    => $context,
                "posthash"   => $posthash,
                "fid"        => isset($opts['fid']) ? (int)$opts['fid'] : 0,
                "pid"        => $pid,
                "maxFiles"   => $maxfiles,
                "uploadUrl"  => "xmlhttp.php?action=dragdrop_upload",
                "removeUrl"  => "xmlhttp.php?action=dragdrop_remove",
                "listUrl"    => "xmlhttp.php?action=dragdrop_list",
                "postKey"    => $mybb->post_code,
                "canInsert"  => ($context == "post" && $mybb->settings['dragdrop_attach_insertbutton'] == 1) ? 1 : 0,
                "hideNative" => ($context == "post" && $mybb->settings['dragdrop_attach_hidenative'] == 1) ? 1 : 0,
                "resetOnPost" => !empty($opts['resetOnPost']) ? 1 : 0,
                "progressHtml" => dragdrop_attach_tpl("progress", array(
                        "dd_name"   => "",
                        "dd_status" => $lang->dragdrop_uploading,
                        "dd_sec"    => isset($lang->dragdrop_unit_sec) ? $lang->dragdrop_unit_sec : "s"
                )),
                "strings" => array(
                        "uploading"     => $lang->dragdrop_uploading,
                        "removeConfirm" => $lang->dragdrop_remove_confirm,
                        "errorGeneric"  => $lang->dragdrop_error_generic,
                        "maxFiles"      => $maxfiles > 0 ? $lang->sprintf($lang->dragdrop_error_maxfiles, $maxfiles) : ""
                )
        );

        if(!empty($opts['inject']))
        {
                $config['inject'] = $opts['inject'];
                $config['fallback'] = $zone;
        }

        // Client-side size policy + chunked upload settings (v2.0.0)
        $config['uid'] = (int)$mybb->user['uid'];
        $config['maxSize'] = ($limits > 0) ? $limits : 0;
        $config['limits'] = array(
                "default" => ($limits > 0) ? $limits : 0,
                "ext"     => (object)$ext_rules
        );
        $config['chunkBytes'] = dragdrop_attach_chunk_bytes();
        $config['strings']['tooLarge'] = $lang->dragdrop_error_client_too_large;

        dragdrop_attach_page_assets($config);

        return $zone;
}

/**
 * Collect the currently staged (and claimed, when editing) attachments for a
 * zone and return them as rendered item HTML.
 *
 * @param string $context
 * @param string $posthash
 * @param int    $pid
 * @param int    $pmid
 * @param array  $opts
 * @return array
 */
function dragdrop_attach_current_items($context, $posthash, $pid, $pmid, $opts = array())
{
        global $mybb, $db;

        $items = array();
        $uid = (int)$mybb->user['uid'];

        if($context == "pm" && $pmid > 0)
        {
                // Draft: reuse the attachments already mapped to this draft PM
                $query = $db->query("
                        SELECT a.*
                        FROM ".TABLE_PREFIX."attachments a
                        INNER JOIN ".TABLE_PREFIX."dragdrop_pm m ON (m.aid = a.aid)
                        WHERE m.pmid = '".(int)$pmid."'
                                AND m.uid = '".$uid."'
                                AND a.uid = '".$uid."'
                        ORDER BY a.aid ASC
                ");

                while($att = $db->fetch_array($query))
                {
                        $items[] = dragdrop_attach_render_item($att, false, false);
                }

                return $items;
        }

        $where = "uid = '".$uid."' AND pid = 0 AND posthash = '".$db->escape_string($posthash)."'";

        $query = $db->simple_select("attachments", "*", $where." ORDER BY aid ASC");
        while($att = $db->fetch_array($query))
        {
                $items[] = dragdrop_attach_render_item($att, false, $context == "post");
        }

        // Editing an existing post: also list attachments already bound to it
        if($context == "post" && $pid > 0)
        {
                $query = $db->simple_select("attachments", "*", "pid = '".(int)$pid."' ORDER BY aid ASC");
                while($att = $db->fetch_array($query))
                {
                        $items[] = dragdrop_attach_render_item($att, true, $context == "post");
                }
        }

        return $items;
}

/**
 * Append CSS / JS / config to $headerinclude (fires before template eval).
 *
 * @param array $config JS config
 */
function dragdrop_attach_page_assets($config)
{
        static $css_done = false;
        static $js_done = false;

        global $headerinclude, $mybb;

        $headerinclude = isset($headerinclude) ? $headerinclude : "";

        if(!$css_done)
        {
                $headerinclude .= dragdrop_attach_tpl("css", array());
                $css_done = true;
        }

        $json_flags = JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP;
        if(defined("JSON_UNESCAPED_SLASHES"))
        {
                $json_flags |= JSON_UNESCAPED_SLASHES;
        }

        $script = $mybb->asset_url."/jscripts/dragdrop_attach.js?ver=".DRAGDROP_ATTACH_JSVER;

        if(!$js_done)
        {
                $js_done = true;

                $headerinclude .= dragdrop_attach_tpl("jsinit", array(
                        "dd_script" => htmlspecialchars_uni($script),
                        "dd_config" => json_encode($config, $json_flags)
                ));

                return;
        }

        /**
         * A second config on the same page (v2.2.0: postbit decoration +
         * quick-reply zone, or several zones): emit only an extra push
         * block — the script tag itself must not repeat, a second execution
         * would wire every zone's event listeners twice.
         */
        $headerinclude .= '<script type="text/javascript">
/* <![CDATA[ */
window.DragDropAttach.push('.json_encode($config, $json_flags).');
/* ]]> */
</script>';
}

/**
 * Lazy cleanup: remove the current user's abandoned unclaimed uploads
 * (older than 3 days, never attached to a post, not mapped to a PM).
 * Keeps uploads/ tidy without relying on a scheduled task.
 *
 * @param int $limit
 * @return int deleted count
 */
function dragdrop_attach_cleanup_orphans($limit = 10)
{
        global $mybb, $db;

        if((int)$mybb->user['uid'] === 0)
        {
                return 0;
        }

        require_once MYBB_ROOT."inc/functions_upload.php";

        $cutoff = TIME_NOW - (3 * 86400);
        $uid = (int)$mybb->user['uid'];

        // Chunked-upload staging files expire much faster than orphans
        dragdrop_attach_chunk_gc(43200);

        $query = $db->query("
                SELECT a.aid, a.attachname, a.thumbnail
                FROM ".TABLE_PREFIX."attachments a
                LEFT JOIN ".TABLE_PREFIX."dragdrop_pm m ON (m.aid = a.aid)
                WHERE a.uid = '".$uid."'
                        AND a.pid = 0
                        AND a.posthash != ''
                        AND a.dateuploaded < '".$cutoff."'
                        AND m.pmaid IS NULL
                ORDER BY a.aid ASC
                LIMIT ".(int)$limit."
        ");

        $uploadspath = !empty($mybb->settings['uploadspath']) ? $mybb->settings['uploadspath'] : './uploads';
        $uploadspath_abs = mk_path_abs($uploadspath);
        $deleted = array();

        while($att = $db->fetch_array($query))
        {
                $deleted[] = (int)$att['aid'];

                // Delete the physical files when nothing else references them
                $refs = (int)$db->fetch_field(
                        $db->simple_select("attachments", "COUNT(aid) AS refs", "attachname = '".$db->escape_string($att['attachname'])."'"),
                        "refs"
                );

                if($refs <= 1)
                {
                        delete_uploaded_file($uploadspath_abs."/".$att['attachname']);
                        if(!empty($att['thumbnail']) && $att['thumbnail'] !== "SMALL")
                        {
                                delete_uploaded_file($uploadspath_abs."/".$att['thumbnail']);
                        }
                }
        }

        if(!empty($deleted))
        {
                $db->delete_query("attachments", "aid IN (".implode(",", $deleted).")");
        }

        return count($deleted);
}

// ======================================================================
// Page hooks — post forms, quick reply, private messages
// ======================================================================

/**
 * newthread_end / newreply_end / editpost_end:
 * append the drop zone right below the native attachment box.
 */
function dragdrop_attach_fullform()
{
        global $attachbox, $mybb, $fid, $pid;

        if(empty($attachbox) || !dragdrop_attach_enabled() || !dragdrop_attach_user_allowed())
        {
                return;
        }

        $forumpermissions = forum_permissions((int)$fid);
        if($forumpermissions['canpostattachments'] != 1)
        {
                return;
        }

        $context = "post";
        $edit_pid = 0;
        if(THIS_SCRIPT == "editpost.php")
        {
                $edit_pid = (int)$pid;
        }

        $zone = dragdrop_attach_render_zone($context, array(
                "fid" => (int)$fid,
                "pid" => $edit_pid
        ));

        if($zone !== "")
        {
                $attachbox .= $zone;
        }
}

/**
 * showthread_end (v2.2.0): load the plugin CSS + JS on thread pages so the
 * script can restyle the native postbit_attachments fieldset into the
 * professional card design. Runs for all viewers — no upload permission
 * required, since this is a read-side visual enhancement.
 */
function dragdrop_attach_postbit_assets()
{
        global $mybb;

        if(dragdrop_attach_enabled() !== true)
        {
                return;
        }

        // Minimal config — initZone() recognises context=postbit and skips
        // zone wiring; the script's boot() decorates the fieldsets itself.
        // "wait" carries the download-gate countdown (0 = gate disabled) so
        // decoratePostbit() can route file-card links through the gate page.
        $wait = 0;

        if(isset($mybb->settings['dragdrop_attach_dlwait']) && (int)$mybb->settings['dragdrop_attach_dlwait'] === 1)
        {
                $wait = (int)$mybb->settings['dragdrop_attach_dlwait_time'];

                if($wait < 1)
                {
                        $wait = 1;
                }

                if($wait > 60)
                {
                        $wait = 60;
                }
        }

        dragdrop_attach_page_assets(array(
                "id"      => "",
                "context" => "postbit",
                "wait"    => $wait
        ));
}

/**
 * showthread_end: inject the drop zone into the quick reply form.
 */
function dragdrop_attach_showthread()
{
        global $quickreply, $mybb, $thread, $forumpermissions, $posthash;

        if(empty($quickreply) || !dragdrop_attach_enabled() || !dragdrop_attach_user_allowed())
        {
                return;
        }

        if($forumpermissions['canpostattachments'] != 1 || $mybb->user['uid'] == 0)
        {
                return;
        }

        $zone = dragdrop_attach_render_zone("post", array(
                "fid" => (int)$thread['fid'],
                "resetOnPost" => 1
        ));

        if($zone === "")
        {
                return;
        }

        $GLOBALS['quickreply'] = dragdrop_attach_insert_into_form($quickreply, $zone);
}

/**
 * private_send_end: compose / draft form.
 * The zone is delivered as a JS fallback (injected into the form client-side)
 * because the PM compose template has no stable server-side anchor variable.
 */
function dragdrop_attach_pm_compose()
{
        global $mybb, $db;

        if(!dragdrop_attach_enabled() || !dragdrop_attach_user_allowed() || $mybb->user['uid'] == 0)
        {
                return;
        }

        if($mybb->settings['dragdrop_attach_pm'] != 1 || $mybb->usergroup['canusepms'] != 1 || $mybb->usergroup['cansendpms'] == 0)
        {
                return;
        }

        $pmid = (int)$mybb->get_input('pmid');
        $posthash = "";
        $opts = array(
                "pmid" => $pmid,
                "inject" => 1
        );

        // Editing a saved draft? Reuse its attachments + posthash.
        if($pmid > 0)
        {
                $folder = (int)$db->fetch_field(
                        $db->simple_select("privatemessages", "folder", "pmid = '".$pmid."' AND uid = '".(int)$mybb->user['uid']."'"),
                        "folder"
                );

                if($folder === 3)
                {
                        $query = $db->query("
                                SELECT a.posthash
                                FROM ".TABLE_PREFIX."attachments a
                                INNER JOIN ".TABLE_PREFIX."dragdrop_pm m ON (m.aid = a.aid)
                                WHERE m.pmid = '".$pmid."'
                                        AND m.uid = '".(int)$mybb->user['uid']."'
                                        AND a.uid = '".(int)$mybb->user['uid']."'
                                        AND a.posthash != ''
                                ORDER BY a.aid ASC
                                LIMIT 1
                        ");

                        $posthash = (string)$db->fetch_field($query, "posthash");
                        $opts['posthash'] = $posthash;
                }
        }

        dragdrop_attach_render_zone("pm", $opts);
}

/**
 * private_read_end: PM quick reply zone + attachments panel in the read view.
 */
function dragdrop_attach_pm_read()
{
        global $message, $pm, $mybb, $db, $lang, $templates, $quickreply;

        if(!dragdrop_attach_enabled() || !dragdrop_attach_user_allowed() || $mybb->user['uid'] == 0)
        {
                return;
        }

        $pmid = isset($pm['pmid']) ? (int)$pm['pmid'] : (int)$mybb->get_input('pmid');

        // -------------------------------------------------------------
        // 1. Attachments panel below the message body
        // -------------------------------------------------------------
        if($pmid > 0 && $mybb->settings['dragdrop_attach_pm'] == 1)
        {
                $panel = dragdrop_attach_render_pm_panel($pmid);
                if($panel !== "")
                {
                        $GLOBALS['message'] .= $panel;
                }
        }

        // -------------------------------------------------------------
        // 2. Drop zone inside the PM quick reply form
        // -------------------------------------------------------------
        if(!empty($quickreply) && $mybb->settings['dragdrop_attach_pm'] == 1
                && $mybb->usergroup['canusepms'] == 1 && $mybb->usergroup['cansendpms'] != 0)
        {
                $zone = dragdrop_attach_render_zone("pm", array("pmid" => 0));
                if($zone !== "")
                {
                        $GLOBALS['quickreply'] = dragdrop_attach_insert_into_form($quickreply, $zone);
                }
        }
}

/**
 * Build the attachments panel for a read private message.
 * Mirrors the core postbit attachment markup so lightbox plugins such as
 * Attachment Preview work out of the box.
 *
 * @param int $pmid
 * @return string
 */
function dragdrop_attach_render_pm_panel($pmid)
{
        global $db, $lang, $mybb;

        $pmid = (int)$pmid;

        $query = $db->query("
                SELECT a.*
                FROM ".TABLE_PREFIX."attachments a
                INNER JOIN ".TABLE_PREFIX."dragdrop_pm m ON (m.aid = a.aid)
                WHERE m.pmid = '".$pmid."'
                        AND m.is_draft = 0
                ORDER BY a.aid ASC
        ");

        if($db->num_rows($query) == 0)
        {
                return "";
        }

        $thumbs = "";
        $images = "";
        $files  = "";

        while($att = $db->fetch_array($query))
        {
                $aid  = (int)$att['aid'];
                $name = htmlspecialchars_uni($att['filename']);
                $ext  = my_strtolower(get_extension($att['filename']));
                $is_image = in_array($ext, array("gif", "png", "jpg", "jpeg", "jpe", "bmp", "webp"));

                if($is_image)
                {
                        if(!empty($att['thumbnail']) && $att['thumbnail'] !== "SMALL")
                        {
                                // Clickable thumbnail — full-resolution preserved via attachment.php?aid=
                                $thumbs .= dragdrop_attach_tpl("pm_read_image", array(
                                        "dd_aid"  => $aid,
                                        "dd_name" => $name
                                ));
                        }
                        else
                        {
                                // Small image — display inline at original size
                                $images .= dragdrop_attach_tpl("pm_read_inline", array(
                                        "dd_aid"  => $aid,
                                        "dd_name" => $name
                                ));
                        }
                }
                else
                {
                        $files .= dragdrop_attach_tpl("pm_read_file", array(
                                "dd_aid"      => $aid,
                                "dd_name"     => $name,
                                "dd_size"     => get_friendly_size((int)$att['filesize']),
                                "dd_downloads" => $lang->sprintf($lang->dragdrop_pm_downloads, (int)$att['downloads']),
                                "dd_icon"     => dragdrop_attach_ext_icon($ext),
                                "dd_wait"     => dragdrop_attach_gate_param()
                        ));
                }
        }

        $thumbs_row = "";
        if($thumbs !== "")
        {
                $thumbs_row = '<span class="ddattach-pm-head smalltext"><strong>'.$lang->dragdrop_pm_thumbnails.'</strong></span><div class="ddattach-pm-thumbs">'.$thumbs.'</div>';
        }

        $images_row = "";
        if($images !== "")
        {
                $images_row = '<span class="ddattach-pm-head smalltext"><strong>'.$lang->dragdrop_pm_images.'</strong></span><div class="ddattach-pm-inline-row">'.$images.'</div>';
        }

        $files_row = "";
        if($files !== "")
        {
                $files_row = '<span class="ddattach-pm-head smalltext"><strong>'.$lang->dragdrop_pm_files.'</strong></span>'.$files;
        }

        return dragdrop_attach_tpl("pm_read", array(
                "dd_title"  => $lang->dragdrop_pm_title,
                "dd_thumbs" => $thumbs_row,
                "dd_images" => $images_row,
                "dd_files"  => $files_row
        ));
}

// ======================================================================
// Download gate (v2.3.0) — professional redirect page with a countdown
// shown before an attachment download starts. Triggered ONLY when the
// request carries the ddawait=1 token (added by the plugin's own download
// links: postbit file cards + PM file rows), so thumbnails, inline images,
// lightbox fetches and bots hitting plain links are never intercepted.
// ======================================================================

/**
 * Sanitized countdown seconds from the ACP setting (1-60, default 5).
 *
 * @return int
 */
function dragdrop_attach_gate_seconds()
{
        global $mybb;

        $s = isset($mybb->settings['dragdrop_attach_dlwait_time']) ? (int)$mybb->settings['dragdrop_attach_dlwait_time'] : 5;

        if($s < 1)
        {
                $s = 1;
        }

        if($s > 60)
        {
                $s = 60;
        }

        return $s;
}

/**
 * URL fragment appended to plugin-rendered download links when the gate
 * is enabled (empty string otherwise).
 *
 * @return string
 */
function dragdrop_attach_gate_param()
{
        global $mybb;

        if(!isset($mybb->settings['dragdrop_attach_dlwait']) || (int)$mybb->settings['dragdrop_attach_dlwait'] !== 1)
        {
                return "";
        }

        return "&amp;ddawait=1";
}

/**
 * Color category for an extension — mirrors the JS postbit card chips.
 *
 * @param string $ext
 * @return string img | zip | doc | av | (empty = generic)
 */
function dragdrop_attach_ext_category($ext)
{
        $ext = my_strtolower((string)$ext);

        if(in_array($ext, array("png", "jpg", "jpeg", "jpe", "gif", "bmp", "webp", "svg", "tif", "tiff", "ico", "avif")))
        {
                return "img";
        }

        if(in_array($ext, array("zip", "rar", "7z", "gz", "tar", "bz2", "xz", "cab", "iso")))
        {
                return "zip";
        }

        if(in_array($ext, array("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "rtf", "odt", "ods", "odp", "epub")))
        {
                return "doc";
        }

        if(in_array($ext, array("mp4", "avi", "mkv", "mov", "wmv", "flv", "webm", "m4v", "mp3", "wav", "ogg", "m4a", "flac", "aac")))
        {
                return "av";
        }

        return "";
}

/**
 * attachment_start: render the countdown gate page and stop. The real
 * download continues after the redirect to the plain attachment.php URL,
 * where the core (or the PM serve hook) increments the download counter.
 */
function dragdrop_attach_download_gate()
{
        global $mybb, $lang, $attachment;

        // v2.5.0 anti-theft: the countdown gate is a licensed feature too
        if(!dragdrop_attach_license_ok())
        {
                return;
        }

        if(!isset($mybb->input['ddawait']) || isset($mybb->input['thumbnail']))
        {
                return;
        }

        if(empty($attachment) || empty($attachment['aid']))
        {
                return; // invalid aid — let core show its standard error
        }

        if(!isset($mybb->settings['dragdrop_attach_dlwait']) || (int)$mybb->settings['dragdrop_attach_dlwait'] !== 1)
        {
                return;
        }

        // Never gate sub-resource fetches (hotlinked <img>/<video>, scripts…);
        // only real top-level navigations see the countdown page.
        if(isset($_SERVER['HTTP_SEC_FETCH_DEST']) && !in_array($_SERVER['HTTP_SEC_FETCH_DEST'], array("document", "empty", "")))
        {
                return;
        }

        if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && my_strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === "xmlhttprequest")
        {
                return;
        }

        $lang->load("dragdrop_attach");

        $ext = my_strtolower(get_extension($attachment['filename']));
        $skip = (!isset($mybb->settings['dragdrop_attach_dlwait_skip']) || (int)$mybb->settings['dragdrop_attach_dlwait_skip'] == 1);
        $dir = "ltr";

        if(isset($lang->settings['dir']) && $lang->settings['dir'] === "rtl")
        {
                $dir = "rtl";
        }

        echo dragdrop_attach_gate_html(array(
                "name"       => $attachment['filename'],
                "ext"        => $ext,
                "size"       => get_friendly_size((int)$attachment['filesize']),
                "target"     => "attachment.php?aid=".(int)$attachment['aid'],
                "seconds"    => dragdrop_attach_gate_seconds(),
                "skip"       => $skip,
                "downloads"  => (int)$attachment['downloads'],
                "dir"        => $dir,
                "bbname"     => isset($mybb->settings['bbname']) ? $mybb->settings['bbname'] : "",
                "t_title"    => $lang->dragdrop_gate_title,
                "t_starts"   => $lang->dragdrop_gate_starts,
                "t_ready"    => $lang->dragdrop_gate_ready,
                "t_now"      => $lang->dragdrop_gate_now,
                "t_cancel"   => $lang->dragdrop_gate_cancel,
                "t_hint"     => $lang->dragdrop_gate_hint,
                "t_dl"       => $lang->dragdrop_gate_dlcount,
                "t_sec"      => isset($lang->dragdrop_unit_sec) ? $lang->dragdrop_unit_sec : "s"
        ));
        exit;
}

/**
 * The standalone Aurora Glass countdown page (pure function — also used by
 * the ACP live preview). All texts arrive pre-localized in $opts.
 *
 * @param array $opts name, ext, size, target, seconds, skip, downloads,
 *                    dir, bbname, t_title, t_starts, t_ready, t_now,
 *                    t_cancel, t_hint, t_dl, t_sec
 * @return string full HTML document
 */
function dragdrop_attach_gate_html($opts)
{
        $o = array_merge(array(
                "name" => "", "ext" => "", "size" => "", "target" => "#",
                "seconds" => 5, "skip" => true, "downloads" => 0,
                "dir" => "ltr", "bbname" => "",
                "t_title" => "Preparing your download", "t_starts" => "Your download will start automatically in",
                "t_ready" => "Starting…", "t_now" => "Download now",
                "t_cancel" => "Cancel and go back", "t_hint" => "",
                "t_dl" => "", "t_sec" => "s"
        ), (array)$opts);

        $o['seconds'] = (int)$o['seconds'];

        if($o['seconds'] < 1)
        {
                $o['seconds'] = 1;
        }

        if($o['seconds'] > 60)
        {
                $o['seconds'] = 60;
        }

        $name = htmlspecialchars_uni((string)$o['name']);
        $ext = my_strtoupper(preg_replace('#[^a-z0-9]#i', '', (string)$o['ext']));
        $cat = dragdrop_attach_ext_category($o['ext']);
        $cat = ($cat !== "") ? " c-".$cat : "";
        $size = htmlspecialchars_uni((string)$o['size']);
        $target = (string)$o['target'];
        $skip = !empty($o['skip']);
        $dl = (int)$o['downloads'];
        $bbname = htmlspecialchars_uni((string)$o['bbname']);
        $title = htmlspecialchars_uni((string)$o['t_title']);
        $starts = htmlspecialchars_uni((string)$o['t_starts']);
        $ready = htmlspecialchars_uni((string)$o['t_ready']);
        $now = htmlspecialchars_uni((string)$o['t_now']);
        $cancel = htmlspecialchars_uni((string)$o['t_cancel']);
        $hint = htmlspecialchars_uni((string)$o['t_hint']);
        $sec = htmlspecialchars_uni((string)$o['t_sec']);
        $dlpill = "";

        if($o['t_dl'] !== "")
        {
                $dlpill = '<span class="pill">'.str_replace('{1}', (string)$dl, (string)$o['t_dl']).'</span>';
        }

        $skip_btn = "";

        if($skip)
        {
                $skip_btn = '<a class="btn" href="'.$target.'" rel="nofollow"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>'.$now.'</a>';
        }

        return '<!DOCTYPE html>
<html dir="'.$o['dir'].'" lang="'.($o['dir'] === "rtl" ? "ar" : "en").'">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="robots" content="noindex, nofollow" />
<title>'.$title.' - '.$bbname.'</title>
<noscript><meta http-equiv="refresh" content="'.$o['seconds'].';url='.$target.'" /></noscript>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%}
body{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;background:radial-gradient(1100px 750px at 88% -10%,rgba(79,142,247,.17),transparent 60%),radial-gradient(950px 700px at -8% 108%,rgba(139,92,246,.15),transparent 55%),linear-gradient(180deg,#0b1020,#0e1428 55%,#0b1020);font-family:"Segoe UI",Tahoma,Arial,sans-serif;color:#e7ecf7;-webkit-font-smoothing:antialiased;overflow-x:hidden}
.bg{position:fixed;inset:0;z-index:0;overflow:hidden;pointer-events:none}
.bg span{position:absolute;border-radius:50%;filter:blur(90px);opacity:.5;animation:dda-drift 11s ease-in-out infinite}
.bg .b1{width:420px;height:420px;top:-140px;inset-inline-start:-100px;background:radial-gradient(circle,rgba(79,142,247,.5),transparent 70%)}
.bg .b2{width:380px;height:380px;bottom:-120px;inset-inline-end:-80px;background:radial-gradient(circle,rgba(139,92,246,.45),transparent 70%);animation-delay:-3.5s}
.bg .b3{width:300px;height:300px;top:40%;inset-inline-start:55%;background:radial-gradient(circle,rgba(34,211,238,.35),transparent 70%);animation-delay:-7s}
.card{position:relative;z-index:1;width:100%;max-width:460px;border-radius:22px;padding:1.6px;background:linear-gradient(135deg,rgba(79,142,247,.55),rgba(139,92,246,.45),rgba(34,211,238,.5));overflow:hidden;isolation:isolate;box-shadow:0 30px 80px -30px rgba(0,0,0,.7);animation:dda-pop .5s cubic-bezier(.34,1.56,.64,1) both}
.inner{position:relative;border-radius:20.5px;padding:30px 26px 24px;text-align:center;background:linear-gradient(180deg,rgba(255,255,255,.065),rgba(255,255,255,.02));backdrop-filter:blur(14px) saturate(1.3);-webkit-backdrop-filter:blur(14px) saturate(1.3)}
.chip{display:inline-flex;align-items:center;justify-content:center;width:58px;height:58px;border-radius:18px;font-size:12.5px;font-weight:800;letter-spacing:.5px;color:#fff;direction:ltr;background:linear-gradient(135deg,#4f8ef7,#8b5cf6);box-shadow:0 14px 30px -12px rgba(79,142,247,.7),inset 0 1px 0 rgba(255,255,255,.35);animation:dda-float 4.5s ease-in-out infinite}
.chip.c-img{background:linear-gradient(135deg,#10b981,#22d3ee);box-shadow:0 14px 30px -12px rgba(16,185,129,.7),inset 0 1px 0 rgba(255,255,255,.35)}
.chip.c-zip{background:linear-gradient(135deg,#8b5cf6,#d946ef);box-shadow:0 14px 30px -12px rgba(139,92,246,.7),inset 0 1px 0 rgba(255,255,255,.35)}
.chip.c-doc{background:linear-gradient(135deg,#4f8ef7,#38bdf8);box-shadow:0 14px 30px -12px rgba(79,142,247,.7),inset 0 1px 0 rgba(255,255,255,.35)}
.chip.c-av{background:linear-gradient(135deg,#f97316,#f43f5e);box-shadow:0 14px 30px -12px rgba(249,115,22,.7),inset 0 1px 0 rgba(255,255,255,.35)}
.name{margin-top:14px;font-size:16px;font-weight:700;word-break:break-word;direction:ltr;unicode-bidi:embed}
.meta{margin-top:9px;display:flex;justify-content:center;gap:7px;flex-wrap:wrap}
.pill{padding:3px 11px;border-radius:999px;font-size:11px;font-weight:600;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);opacity:.85;direction:ltr;font-variant-numeric:tabular-nums}
.ring{position:relative;width:104px;height:104px;margin:22px auto 8px;border-radius:50%;background:conic-gradient(#4f8ef7 calc(var(--dda-p,100)*1%),rgba(255,255,255,.1) 0);display:flex;align-items:center;justify-content:center;box-shadow:0 14px 30px -14px rgba(79,142,247,.8);transition:background .9s linear}
.ring::before{content:"";position:absolute;inset:7px;border-radius:50%;background:rgba(13,18,34,.95);box-shadow:inset 0 2px 6px rgba(0,0,0,.5)}
.ring .n{position:relative;z-index:1;font-size:34px;font-weight:800;direction:ltr;font-variant-numeric:tabular-nums;color:#fff;text-shadow:0 2px 12px rgba(79,142,247,.6)}
.ring.done{background:conic-gradient(#34d399 calc(var(--dda-p,0)*1%),rgba(255,255,255,.1) 0);box-shadow:0 14px 30px -14px rgba(52,211,153,.8)}
.ring.done .n{font-size:22px;color:#34d399;text-shadow:0 2px 12px rgba(52,211,153,.6)}
.bar{height:7px;border-radius:999px;background:rgba(255,255,255,.09);overflow:hidden;margin:8px 2px 0}
.bar span{display:block;height:100%;width:100%;border-radius:999px;background:linear-gradient(90deg,#4f8ef7,#8b5cf6,#22d3ee,#4f8ef7);background-size:280% 100%;animation:dda-shimmer 2s linear infinite;transition:width .95s linear}
.txt{margin-top:14px;font-size:13.5px;opacity:.9}
.txt b{color:#8ab4ff;font-variant-numeric:tabular-nums}
.actions{margin-top:18px;display:flex;gap:10px;justify-content:center;flex-wrap:wrap}
.btn{display:inline-flex;align-items:center;gap:8px;padding:10px 22px;border-radius:12px;font-size:13.5px;font-weight:700;text-decoration:none;cursor:pointer;border:1px solid transparent;background:linear-gradient(135deg,#4f8ef7,#8b5cf6);color:#fff;box-shadow:0 12px 26px -12px rgba(79,142,247,.8),inset 0 1px 0 rgba(255,255,255,.3);transition:transform .25s cubic-bezier(.34,1.56,.64,1),filter .25s ease}
.btn:hover{transform:translateY(-2px);filter:brightness(1.07)}
.btn:active{transform:scale(.96)}
.btn.ghost{background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.18);box-shadow:none;color:#dbe4f5}
.btn.ghost:hover{border-color:rgba(139,92,246,.55);color:#fff}
.btn svg{display:block}
.hint{margin-top:16px;font-size:11.5px;opacity:.55;line-height:1.7}
.brand{margin-top:4px;font-size:10px;opacity:.3;letter-spacing:.3px}
@keyframes dda-drift{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(-26px,22px) scale(1.06)}}
@keyframes dda-float{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}
@keyframes dda-pop{from{opacity:0;transform:translateY(14px) scale(.97)}to{opacity:1;transform:none}}
@keyframes dda-shimmer{0%{background-position:0% 0}100%{background-position:280% 0}}
@media (prefers-reduced-motion:reduce){.bg span,.chip,.bar span,.card{animation:none !important}.ring,.bar span,.btn{transition:none !important}}
@supports not (background:conic-gradient(red,blue)){.ring{background:rgba(255,255,255,.1)}.ring::after{content:"";position:absolute;inset:0;border-radius:50%;background:linear-gradient(135deg,#4f8ef7,#8b5cf6);-webkit-mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0);mask-composite:exclude;padding:4px}}
</style>
</head>
<body>
<div class="bg" aria-hidden="true"><span class="b1"></span><span class="b2"></span><span class="b3"></span></div>
<main class="card">
        <div class="inner">
                <div class="chip'.$cat.'">'.$ext.'</div>
                <h1 class="name">'.$name.'</h1>
                <div class="meta">
                        <span class="pill">'.$size.'</span>
                        <span class="pill">'.$ext.'</span>
                        '.$dlpill.'
                </div>
                <div class="ring" id="ddaRing" role="timer" aria-live="polite"><span class="n" id="ddaNum">'.$o['seconds'].'</span></div>
                <div class="bar" aria-hidden="true"><span id="ddaFill"></span></div>
                <p class="txt">'.$starts.' <b id="ddaSec">'.$o['seconds'].'</b> '.$sec.'</p>
                <div class="actions">
                        '.$skip_btn.'
                        <button type="button" class="btn ghost" onclick="history.back()"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>'.$cancel.'</button>
                </div>
                <p class="hint">'.$hint.'</p>
                '.($bbname !== "" ? '<p class="brand">'.$bbname.' &middot; DragDrop Attachments</p>' : '<p class="brand">DragDrop Attachments</p>').'
        </div>
</main>
<script>
(function(){
        "use strict";
        var total = '.$o['seconds'].', left = total;
        var num = document.getElementById("ddaNum"), sec = document.getElementById("ddaSec"),
                ring = document.getElementById("ddaRing"), fill = document.getElementById("ddaFill");
        function paint(){
                var p = total > 0 ? (left / total) * 100 : 0;
                ring.style.setProperty("--dda-p", p.toFixed(2));
                fill.style.width = p.toFixed(2) + "%";
                if(left > 0){
                        num.textContent = left;
                        sec.textContent = left;
                }
        }
        paint();
        var t = setInterval(function(){
                left--;
                if(left <= 0){
                        clearInterval(t);
                        left = 0;
                        paint();
                        ring.classList.add("done");
                        num.textContent = "'.addcslashes($ready, "\\'").'";
                        fill.style.width = "0%";
                        setTimeout(function(){ window.location.replace("'.$target.'"); }, 350);
                        return;
                }
                paint();
        }, 1000);
})();
</script>
</body>
</html>';
}

/**
 * attachment_start: serve files/thumbnails for attachments that belong to a
 * sent private message. Core attachment.php is post-oriented and would reject
 * PM attachments (pid = 0 + different owner), so we deliver them ourselves
 * after verifying the viewer is the sender or a recipient of the PM.
 */
function dragdrop_attach_attachment_serve()
{
        global $mybb, $db, $attachment, $lang;

        if(empty($attachment) || empty($attachment['aid']))
        {
                return;
        }

        $aid = (int)$attachment['aid'];

        // Only intercept attachments mapped to a sent PM
        $query = $db->simple_select("dragdrop_pm", "pmid", "aid = '".$aid."' AND is_draft = 0", array("limit" => 1));
        $pmid = (int)$db->fetch_field($query, "pmid");

        if($pmid <= 0)
        {
                return; // normal post attachment — continue with core logic
        }

        $me = (int)$mybb->user['uid'];

        if($me === 0)
        {
                error_no_permission();
        }

        // Viewer must own the PM copy (recipient or sender's Sent Items copy)
        $owner = $db->fetch_array($db->simple_select("privatemessages", "uid, fromid", "pmid = '".$pmid."'", array("limit" => 1)));

        if(!$owner || ((int)$owner['uid'] !== $me && (int)$owner['fromid'] !== $me))
        {
                error_no_permission();
        }

        $uploadspath = !empty($mybb->settings['uploadspath']) ? $mybb->settings['uploadspath'] : './uploads';
        $uploadspath_abs = mk_path_abs($uploadspath);

        if(isset($mybb->input['thumbnail']))
        {
                // ----- Thumbnail -----
                if(empty($attachment['thumbnail']) || $attachment['thumbnail'] === "SMALL"
                        || !file_exists($uploadspath_abs."/".$attachment['thumbnail']))
                {
                        error($lang->error_invalidattachment);
                }

                $thumb_ext = get_extension($attachment['thumbnail']);
                switch($thumb_ext)
                {
                        case "gif":  $type = "image/gif"; break;
                        case "bmp":  $type = "image/bmp"; break;
                        case "png":  $type = "image/png"; break;
                        case "jpg":
                        case "jpeg":
                        case "jpe":  $type = "image/jpeg"; break;
                        default:     $type = "image/unknown";
                }

                header("Content-disposition: filename=\"".basename($attachment['filename'])."\"");
                header("Content-type: ".$type);
                header("Content-length: ".@filesize($uploadspath_abs."/".$attachment['thumbnail']));

                dragdrop_attach_readfile($uploadspath_abs."/".$attachment['thumbnail']);
                exit;
        }

        // ----- Full file -----
        if(!file_exists($uploadspath_abs."/".$attachment['attachname']))
        {
                error($lang->error_invalidattachment);
        }

        // Count the download
        $db->update_query("attachments", array("downloads" => (int)$attachment['downloads'] + 1), "aid = '".$aid."'");

        $filetype = $attachment['filetype'];
        $disposition = "attachment";

        switch($filetype)
        {
                case "application/pdf":
                case "image/bmp":
                case "image/gif":
                case "image/jpeg":
                case "image/pjpeg":
                case "image/png":
                case "text/plain":
                        header("Content-type: {$filetype}");
                        $disposition = "inline";
                        break;
                default:
                        if(!$filetype)
                        {
                                $filetype = "application/force-download";
                        }
                        header("Content-type: {$filetype}");
        }

        header("Content-disposition: {$disposition}; filename=\"".basename($attachment['filename'])."\"");
        header("Content-length: ".(int)$attachment['filesize']);

        dragdrop_attach_readfile($uploadspath_abs."/".$attachment['attachname']);
        exit;
}

/**
 * Stream a file to the browser in chunks.
 *
 * @param string $path
 */
function dragdrop_attach_readfile($path)
{
        $handle = @fopen($path, "rb");

        if(!$handle)
        {
                return;
        }

        while(!feof($handle))
        {
                echo fread($handle, 8192);
        }

        fclose($handle);
}

/**
 * Insert HTML into a rendered form string: before the first <table> tag
 * (falls back to just before </form>).
 *
 * @param string $form rendered form HTML
 * @param string $zone zone HTML
 * @return string
 */
function dragdrop_attach_insert_into_form($form, $zone)
{
        $pos = stripos($form, "<table");

        if($pos !== false)
        {
                return substr($form, 0, $pos).$zone.substr($form, $pos);
        }

        $pos = strripos($form, "</form>");

        if($pos !== false)
        {
                return substr($form, 0, $pos).$zone.substr($form, $pos);
        }

        return $form.$zone;
}

// ======================================================================
// PM datahandlers — claiming staged attachments when a PM is sent/saved
// ======================================================================

/**
 * Fetch the attachment IDs staged (uploaded, pid = 0) under a posthash for
 * the current sender.
 *
 * @param string $posthash
 * @param int    $sender_uid
 * @return array
 */
function dragdrop_attach_staged_aids($posthash, $sender_uid)
{
        global $db;

        if(!preg_match('#^[a-f0-9]{32}$#', (string)$posthash) || (int)$sender_uid === 0)
        {
                return array();
        }

        $aids = array();
        $query = $db->simple_select(
                "attachments",
                "aid",
                "posthash = '".$db->escape_string($posthash)."' AND uid = '".(int)$sender_uid."' AND pid = 0",
                array("order_by" => "aid", "order_dir" => "ASC")
        );

        while($row = $db->fetch_array($query))
        {
                $aids[] = (int)$row['aid'];
        }

        return $aids;
}

/**
 * datahandler_pm_insert_updatedraft_commit:
 * map staged attachments to the draft PM (is_draft = 1) so they survive
 * between draft editing sessions.
 */
function dragdrop_attach_pm_draft_saved(&$pmhandler)
{
        global $mybb, $db;

        $posthash = trim((string)$mybb->get_input('posthash'));
        $sender_uid = isset($pmhandler->data['sender']['uid']) ? (int)$pmhandler->data['sender']['uid'] : (int)$mybb->user['uid'];
        $draft_pmid = (int)$pmhandler->pmid;

        $aids = dragdrop_attach_staged_aids($posthash, $sender_uid);

        if(empty($aids) || $draft_pmid <= 0)
        {
                return;
        }

        // Drop previous draft mappings for these attachments (old draft was deleted)
        $db->delete_query("dragdrop_pm", "aid IN (".implode(",", $aids).") AND is_draft = 1");

        $inserts = array();
        foreach($aids as $aid)
        {
                $inserts[] = array(
                        "aid"      => $aid,
                        "pmid"     => $draft_pmid,
                        "uid"      => $sender_uid,
                        "is_draft" => 1
                );
        }

        $db->insert_query_multiple("dragdrop_pm", $inserts);
}

/**
 * datahandler_pm_insert_end:
 * the PM was sent. Bind the staged attachments to every generated copy:
 * one per recipient (Inbox) plus the sender's Sent Items copy, then clear
 * the staging posthash so the attachments can never be claimed by a post.
 */
function dragdrop_attach_pm_claim(&$pmhandler)
{
        global $mybb, $db, $cache;

        $posthash = trim((string)$mybb->get_input('posthash'));
        $sender_uid = isset($pmhandler->data['sender']['uid']) ? (int)$pmhandler->data['sender']['uid'] : (int)$mybb->user['uid'];

        $aids = dragdrop_attach_staged_aids($posthash, $sender_uid);

        if(empty($aids))
        {
                return;
        }

        // Recipient copies (pmid array built by the PM datahandler)
        $pmids = array();
        if(!empty($pmhandler->pmid) && is_array($pmhandler->pmid))
        {
                foreach($pmhandler->pmid as $pmid)
                {
                        $pmid = (int)$pmid;
                        if($pmid > 0)
                        {
                                $pmids[] = $pmid;
                        }
                }
        }

        // Sender's Sent Items copy (created when "save a copy" is checked)
        $savecopy = isset($pmhandler->data['options']['savecopy']) ? (int)$pmhandler->data['options']['savecopy'] : 1;

        if($savecopy && count($pmids) > 0)
        {
                $sent_pmid = (int)$db->fetch_field(
                        $db->simple_select(
                                "privatemessages",
                                "pmid",
                                "uid = '".$sender_uid."' AND fromid = '".$sender_uid."' AND folder = 2",
                                array("order_by" => "pmid", "order_dir" => "DESC", "limit" => 1)
                        ),
                        "pmid"
                );

                if($sent_pmid > 0)
                {
                        $pmids[] = $sent_pmid;
                }
        }

        if(empty($pmids))
        {
                return;
        }

        // Remove stale draft mappings — the draft (if any) was consumed by this send
        $db->delete_query("dragdrop_pm", "aid IN (".implode(",", $aids).") AND is_draft = 1");

        $inserts = array();
        foreach($aids as $aid)
        {
                foreach($pmids as $pmid)
                {
                        $inserts[] = array(
                                "aid"      => $aid,
                                "pmid"     => $pmid,
                                "uid"      => $sender_uid,
                                "is_draft" => 0
                        );
                }
        }

        $db->insert_query_multiple("dragdrop_pm", $inserts);

        // Release the staging posthash (attachments now belong to the PMs only)
        $db->update_query("attachments", array("posthash" => ""), "aid IN (".implode(",", $aids).")");
}

// ======================================================================
// Admin CP — control panel module registration (Tools & Maintenance)
// The module itself lives in admin/modules/tools/dragdrop_attach.php
// ======================================================================

/**
 * admin_tools_menu hook: sidebar entry.
 */
function dragdrop_attach_admin_menu(&$sub_menu)
{
        global $lang;

        $lang->load("dragdrop_attach", false, true);

        if(!isset($lang->dragdrop_acp_menu) || $lang->dragdrop_acp_menu === "")
        {
                $lang->dragdrop_acp_menu = "DragDrop Attachments";
        }

        $sub_menu['90'] = array(
                "id"    => "dragdrop_attach",
                "title" => $lang->dragdrop_acp_menu,
                "link"  => "index.php?module=tools-dragdrop_attach"
        );
}

/**
 * admin_tools_action_handler hook: action → module file mapping.
 */
function dragdrop_attach_admin_action_handler(&$actions)
{
        $actions['dragdrop_attach'] = array('active' => 'dragdrop_attach', 'file' => 'dragdrop_attach.php');
}

/**
 * admin_tools_permissions hook: entry in the admin permissions editor.
 */
function dragdrop_attach_admin_permissions(&$admin_permissions)
{
        global $lang;

        $lang->load("dragdrop_attach", false, true);

        $admin_permissions['dragdrop_attach'] = $lang->dragdrop_acp_permission;
}

// ======================================================================
// Upload activity log (Admin CP → Tools → DragDrop Attachments → Logs)
// ======================================================================

/**
 * Whether upload logging is enabled.
 *
 * @return bool
 */
function dragdrop_attach_logging_enabled()
{
        global $mybb;

        return isset($mybb->settings['dragdrop_attach_logging']) && (int)$mybb->settings['dragdrop_attach_logging'] === 1;
}

/**
 * Write one row into the upload activity log.
 *
 * @param string $status  ok | denied | error
 * @param array  $ctx     upload context: filename, filesize, ext, context
 * @param string $message optional detail (error text)
 */
function dragdrop_attach_write_log($status, $ctx, $message = "")
{
        global $mybb, $db;

        if(!dragdrop_attach_logging_enabled() || !is_array($ctx))
        {
                return;
        }

        $message = trim(strip_tags(htmlspecialchars_decode((string)$message, ENT_QUOTES)));

        if(my_strlen($message) > 250)
        {
                $message = my_substr($message, 0, 250)."…";
        }

        $ext = my_strtolower((string)(isset($ctx['ext']) ? $ctx['ext'] : ""));

        $entry = array(
                "uid"       => (int)$mybb->user['uid'],
                "username"  => $db->escape_string((string)$mybb->user['username']),
                "filename"  => $db->escape_string(my_substr((string)(isset($ctx['filename']) ? $ctx['filename'] : ""), 0, 250)),
                "filesize"  => (int)(isset($ctx['filesize']) ? $ctx['filesize'] : 0),
                "fileext"   => $db->escape_string(my_substr($ext, 0, 10)),
                "context"   => (isset($ctx['context']) && $ctx['context'] === "pm") ? "pm" : "post",
                "status"    => in_array($status, array("ok", "denied", "error")) ? $status : "error",
                "message"   => $db->escape_string($message),
                "ipaddress" => $db->escape_string(get_ip()),
                "dateline"  => TIME_NOW
        );

        $db->insert_query("dragdrop_log", $entry);

        // Lazy retention pruning on a fraction of uploads keeps the table
        // small without requiring a scheduled task.
        $days = (int)$mybb->settings['dragdrop_attach_logdays'];

        if($days > 0 && mt_rand(1, 20) === 1)
        {
                $db->delete_query("dragdrop_log", "dateline < '".(TIME_NOW - ($days * 86400))."'");
        }
}

// ======================================================================
// AJAX endpoints (hooked into xmlhttp.php)
// ======================================================================

/**
 * xmlhttp hook dispatcher.
 */
function dragdrop_attach_xmlhttp()
{
        global $mybb;

        // v2.4.0 anti-theft: block the plug-in upload endpoints when locked
        if(!dragdrop_attach_license_ok())
        {
                return;
        }

        $action = $mybb->get_input('action');

        if($action === "dragdrop_upload")
        {
                dragdrop_attach_ajax_upload();
        }
        elseif($action === "dragdrop_remove")
        {
                dragdrop_attach_ajax_remove();
        }
        elseif($action === "dragdrop_list")
        {
                dragdrop_attach_ajax_list();
        }
}

/**
 * Send a JSON error response and stop.
 * While an upload is in flight the denial is written to the activity log.
 *
 * @param string $message language string
 */
function dragdrop_attach_json_error($message)
{
        global $lang;

        if(!empty($GLOBALS['dragdrop_upload_ctx']))
        {
                dragdrop_attach_write_log("denied", $GLOBALS['dragdrop_upload_ctx'], $message);
        }

        dragdrop_attach_send_json(array(
                "success"  => 0,
                "errorHtml" => dragdrop_attach_tpl("error", array("dd_message" => $message)),
                "error"    => $message
        ));
}

/**
 * Send a JSON response.
 *
 * @param array $data
 */
function dragdrop_attach_send_json($data)
{
        global $charset;

        if(!isset($charset))
        {
                $charset = "UTF-8";
        }

        header("Content-type: application/json; charset={$charset}");
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
}

/**
 * Move an assembled (chunk-staged) file into its final uploads location.
 * The staging file was written by PHP itself, so the regular
 * move_uploaded_file() flow does not apply.
 *
 * @param string $src  absolute staging path
 * @param string $dest absolute destination path
 * @return array error flag (mirrors upload_file()'s shape)
 */
function dragdrop_attach_store_assembled($src, $dest)
{
        if(!file_exists($src))
        {
                return array("error" => 1);
        }

        if(!@rename($src, $dest))
        {
                if(!@copy($src, $dest))
                {
                        return array("error" => 1);
                }

                @unlink($src);
        }

        @chmod($dest, 0644);

        return array("error" => 0);
}

/**
 * Receive one slice of a chunked upload (large file support).
 *
 * POST: ddtoken, ddindex, ddtotal, ddchunksize, ddname, ddsize
 * FILE: attachment (the raw slice)
 *
 * Intermediate slices end the request with a JSON acknowledgement.
 * The final slice returns the assembled file description:
 * array(name, path, size).
 */
function dragdrop_attach_chunk_receive($uid)
{
        global $mybb, $lang;

        $token = dragdrop_attach_chunk_token($mybb->get_input('ddtoken'));

        if($token === "" || strpos($token, "u".(int)$uid."_") !== 0)
        {
                dragdrop_attach_json_error($lang->dragdrop_error_chunk_invalid);
        }

        $index      = (int)$mybb->get_input('ddindex');
        $total      = (int)$mybb->get_input('ddtotal');
        $chunksize  = (int)$mybb->get_input('ddchunksize');
        $total_size = (int)$mybb->get_input('ddsize');

        if($total < 1 || $index < 0 || $index >= $total || $chunksize < 65536
                || $total_size < 1 || $total_size > 4294967295
                || ($index === $total - 1 && $total_size <= $index * $chunksize))
        {
                dragdrop_attach_json_error($lang->dragdrop_error_chunk_invalid);
        }

        $dir = dragdrop_attach_tmp_dir(true);

        if($dir === "")
        {
                dragdrop_attach_json_error($lang->dragdrop_error_upload);
        }

        $part_path = $dir."/".$token.".part";

        if(empty($_FILES['attachment']) || !is_uploaded_file($_FILES['attachment']['tmp_name']))
        {
                dragdrop_attach_json_error($lang->dragdrop_error_upload);
        }

        $chunk_len = (int)@filesize($_FILES['attachment']['tmp_name']);

        if($chunk_len < 1)
        {
                dragdrop_attach_json_error($lang->dragdrop_error_upload);
        }

        // Slice length integrity: fixed size everywhere except the last one
        if($index === $total - 1)
        {
                if($chunk_len !== $total_size - ($index * $chunksize))
                {
                        dragdrop_attach_json_error($lang->dragdrop_error_chunk_restart);
                }
        }
        elseif($chunk_len !== $chunksize)
        {
                dragdrop_attach_json_error($lang->dragdrop_error_chunk_restart);
        }

        // Continuing slices must join the staged file at the exact offset
        if($index > 0)
        {
                $have = file_exists($part_path) ? (int)@filesize($part_path) : -1;

                if($have !== $index * $chunksize)
                {
                        dragdrop_attach_json_error($lang->dragdrop_error_chunk_restart);
                }
        }

        // Append the slice (mode "wb" truncates stale first slices)
        $in = @fopen($_FILES['attachment']['tmp_name'], "rb");
        $out = @fopen($part_path, ($index === 0) ? "wb" : "ab");

        if(!$in || !$out)
        {
                if($in) { fclose($in); }
                if($out) { fclose($out); }
                dragdrop_attach_json_error($lang->dragdrop_error_upload);
        }

        stream_copy_to_stream($in, $out);
        fclose($in);
        fclose($out);

        clearstatcache();
        $have = (int)@filesize($part_path);
        $expected = ($index === $total - 1) ? $total_size : ($index + 1) * $chunksize;

        if($have !== $expected)
        {
                dragdrop_attach_json_error($lang->dragdrop_error_chunk_restart);
        }

        // Intermediate slice — acknowledge and wait for the next one
        if($index < $total - 1)
        {
                dragdrop_attach_send_json(array(
                        "success"  => 1,
                        "chunk"    => 1,
                        "received" => $index + 1
                ));
        }

        // Final slice — hand the assembled file to the regular pipeline
        $filename = trim((string)$mybb->get_input('ddname'));
        $filename = ltrim(basename(' '.$filename)); // UTF-8 safe basename (like core)
        $filename = preg_replace("#[\x00-\x1f]#", "", $filename);

        if($filename === "" || my_strlen($filename) > 255)
        {
                dragdrop_attach_json_error($lang->dragdrop_error_upload);
        }

        return array(
                "name" => $filename,
                "path" => $part_path,
                "size" => $total_size
        );
}

/**
 * AJAX: upload one attachment.
 *
 * POST: my_post_key, ddcontext (post|pm), posthash, fid, pid, attachment (file)
 * Chunked mode adds: ddchunk=1, ddtoken, ddindex, ddtotal, ddchunksize,
 *                    ddname, ddsize — plus ddabort=1 to cancel.
 */
function dragdrop_attach_ajax_upload()
{
        global $mybb, $db, $lang, $cache, $plugins;

        require_once MYBB_ROOT."inc/functions_upload.php";

        $lang->load("dragdrop_attach");

        if(!verify_post_check($mybb->get_input('my_post_key'), true))
        {
                dragdrop_attach_json_error($lang->dragdrop_error_postkey);
        }

        if(dragdrop_attach_enabled() !== true)
        {
                dragdrop_attach_json_error($lang->dragdrop_error_disabled);
        }

        if(!dragdrop_attach_user_allowed())
        {
                dragdrop_attach_json_error($lang->dragdrop_error_notallowed);
        }

        $context = ($mybb->get_input('ddcontext') === "pm") ? "pm" : "post";
        $posthash = trim((string)$mybb->get_input('posthash'));
        $fid = (int)$mybb->get_input('fid');
        $pid = (int)$mybb->get_input('pid');
        $uid = (int)$mybb->user['uid'];

        // Upload context for the activity log (filled in as validation
        // progresses; every denial is recorded by dragdrop_attach_json_error).
        $GLOBALS['dragdrop_upload_ctx'] = array(
                "context"  => $context,
                "filename" => "",
                "filesize" => 0,
                "ext"      => ""
        );

        // ------------------------------------------------------------------
        // Chunked upload (large file support)
        // ------------------------------------------------------------------
        $is_chunk = ($mybb->get_input('ddchunk') === "1");

        if($is_chunk && $mybb->get_input('ddabort') === "1")
        {
                // Client cancelled — drop the staging file and stop
                dragdrop_attach_chunk_delete($mybb->get_input('ddtoken'), $uid);
                dragdrop_attach_send_json(array("success" => 1, "aborted" => 1));
        }

        if(!preg_match('#^[a-f0-9]{32}$#', $posthash))
        {
                dragdrop_attach_json_error($lang->dragdrop_error_generic);
        }

        if($context == "pm")
        {
                if($mybb->settings['dragdrop_attach_pm'] != 1)
                {
                        dragdrop_attach_json_error($lang->dragdrop_error_pm_disabled);
                }

                if($mybb->usergroup['canusepms'] != 1 || $mybb->usergroup['cansendpms'] == 0)
                {
                        dragdrop_attach_json_error($lang->dragdrop_error_notallowed);
                }
        }
        else
        {
                $forum = get_forum($fid);

                if(!$forum)
                {
                        dragdrop_attach_json_error($lang->dragdrop_error_invalid);
                }

                $forumpermissions = forum_permissions($fid);

                if($forumpermissions['canview'] != 1 || $forumpermissions['canpostattachments'] != 1)
                {
                        dragdrop_attach_json_error($lang->dragdrop_error_notallowed);
                }

                if($forum['open'] == 0 && !is_moderator($fid, "canpostclosed"))
                {
                        dragdrop_attach_json_error($lang->dragdrop_error_forum_closed);
                }

                if(!empty($forum['password']) && check_forum_password($fid, 0, true) !== true)
                {
                        dragdrop_attach_json_error($lang->dragdrop_error_notallowed);
                }

                if($forumpermissions['canpostthreads'] != 1 && $forumpermissions['canpostreplys'] != 1
                        && !is_moderator($fid, "caneditposts"))
                {
                        dragdrop_attach_json_error($lang->dragdrop_error_notallowed);
                }
        }

        // ------------------------------------------------------------------
        // Obtain the file: chunk-assembled staging file or a classic upload
        // ------------------------------------------------------------------
        if($is_chunk)
        {
                @set_time_limit(0);

                $assembled = dragdrop_attach_chunk_receive($uid);

                $file = array(
                        "name"     => $assembled['name'],
                        "type"     => "",
                        "tmp_name" => $assembled['path'],
                        "error"    => 0,
                        "size"     => $assembled['size']
                );
        }
        else
        {
                if(empty($_FILES['attachment']) || !is_uploaded_file($_FILES['attachment']['tmp_name']))
                {
                        dragdrop_attach_json_error($lang->dragdrop_error_upload);
                }

                $file = $_FILES['attachment'];
        }

        $filename = trim((string)$file['name']);
        $filename = ltrim(basename(' '.$filename)); // UTF-8 safe basename (like core)
        $filename = preg_replace("#[\x00-\x1f]#", "", $filename);

        if($filename === "" || my_strlen($filename) > 255)
        {
                dragdrop_attach_json_error($lang->dragdrop_error_upload);
        }

        $ext = my_strtolower(get_extension($filename));

        // Hard-deny server-executable extensions: built-in list + the extra
        // extensions configured in the Admin CP size limits panel
        if(in_array($ext, dragdrop_attach_deny_list()))
        {
                dragdrop_attach_json_error($lang->dragdrop_error_invalid_type);
        }

        $attachtypes = (array)$cache->read("attachtypes");
        $type_maxsize = null;
        $registered = isset($attachtypes[$ext]);

        if($registered)
        {
                $attachtype = $attachtypes[$ext];
                $type_maxsize = !empty($attachtype['maxsize']) ? (int)$attachtype['maxsize'] : 0;

                if(!is_member($attachtype['groups']))
                {
                        dragdrop_attach_json_error($lang->dragdrop_error_invalid_type);
                }

                if($context == "post" && $attachtype['forums'] != -1
                        && strpos(",".$attachtype['forums'].",", ",".$fid.",") === false)
                {
                        dragdrop_attach_json_error($lang->dragdrop_error_invalid_type);
                }
        }
        elseif(!dragdrop_attach_all_types())
        {
                // Unregistered extension and universal file type mode is off
                dragdrop_attach_json_error($lang->dragdrop_error_invalid_type);
        }

        $filesize = (int)@filesize($file['tmp_name']);

        if($filesize < 1)
        {
                dragdrop_attach_json_error($lang->dragdrop_error_upload);
        }

        $GLOBALS['dragdrop_upload_ctx']['filename'] = $filename;
        $GLOBALS['dragdrop_upload_ctx']['filesize'] = $filesize;
        $GLOBALS['dragdrop_upload_ctx']['ext'] = $ext;

        // Effective size limit: per-extension rule > global max size > core
        // attachment type limit (unlimited when nothing is configured)
        $limit = dragdrop_attach_file_limit($ext, $registered ? $type_maxsize : null);

        if($limit > 0 && $filesize > $limit)
        {
                dragdrop_attach_json_error($lang->sprintf(
                        $lang->dragdrop_error_too_large,
                        htmlspecialchars_uni($filename),
                        get_friendly_size($limit)
                ));
        }

        // ------------------------------------------------------------------
        // Per-message file count
        // ------------------------------------------------------------------
        $maxfiles = (int)$mybb->settings['dragdrop_attach_maxfiles'];

        if($maxfiles > 0)
        {
                $count = (int)$db->fetch_field(
                        $db->simple_select("attachments", "COUNT(aid) AS total",
                                "posthash = '".$db->escape_string($posthash)."' AND uid = '".$uid."' AND pid = 0"),
                        "total"
                );

                if($context == "post" && $pid > 0)
                {
                        $count += (int)$db->fetch_field(
                                $db->simple_select("attachments", "COUNT(aid) AS total", "pid = '".$pid."'"),
                                "total"
                        );
                }

                if($count >= $maxfiles)
                {
                        dragdrop_attach_json_error($lang->sprintf($lang->dragdrop_error_maxfiles, $maxfiles));
                }
        }

        // ------------------------------------------------------------------
        // Duplicate filename inside the same message
        // ------------------------------------------------------------------
        $dup_where = "uid = '".$uid."' AND pid = 0 AND posthash = '".$db->escape_string($posthash)."' AND filename = '".$db->escape_string($filename)."'";

        if($context == "post" && $pid > 0)
        {
                $dup_where .= " OR (pid = '".$pid."' AND filename = '".$db->escape_string($filename)."')";
        }

        $duplicate = (int)$db->fetch_field(
                $db->simple_select("attachments", "COUNT(aid) AS total", "(".$dup_where.")"),
                "total"
        );

        if($duplicate > 0)
        {
                dragdrop_attach_json_error($lang->sprintf($lang->dragdrop_error_duplicate, htmlspecialchars_uni($filename)));
        }

        // ------------------------------------------------------------------
        // Storage quota
        // ------------------------------------------------------------------
        $quota = dragdrop_attach_quota_bytes($uid);

        if($quota > 0)
        {
                $used = dragdrop_attach_usage_bytes($uid);

                if(($used + $filesize) > $quota)
                {
                        dragdrop_attach_json_error($lang->sprintf(
                                $lang->dragdrop_error_quota,
                                get_friendly_size($quota)
                        ));
                }
        }

        // ------------------------------------------------------------------
        // Move the file into the uploads directory (core naming conventions)
        // ------------------------------------------------------------------
        $uploadspath = !empty($mybb->settings['uploadspath']) ? $mybb->settings['uploadspath'] : './uploads';
        $uploadspath_abs = mk_path_abs($uploadspath);

        $month_dir = "";
        if($mybb->safemode == false)
        {
                $month_dir = gmdate("Ym");
                if(!@is_dir($uploadspath_abs."/".$month_dir))
                {
                        @mkdir($uploadspath_abs."/".$month_dir);
                        if(!@is_dir($uploadspath_abs."/".$month_dir))
                        {
                                $month_dir = "";
                        }
                }
        }

        $stored_name = "post_".$uid."_".TIME_NOW."_".md5(random_str()).".attach";

        if($is_chunk)
        {
                // Assembled staging file is already on this volume — move it
                $moved = dragdrop_attach_store_assembled($file['tmp_name'], $uploadspath_abs.($month_dir !== "" ? "/".$month_dir : "")."/".$stored_name);

                if(!empty($moved['error']) && $month_dir !== "")
                {
                        // Monthly directory failed — fall back to the root uploads directory
                        $month_dir = "";
                        $moved = dragdrop_attach_store_assembled($file['tmp_name'], $uploadspath_abs."/".$stored_name);
                }
        }
        else
        {
                $moved = upload_file($file, $uploadspath_abs.($month_dir !== "" ? "/".$month_dir : ""), $stored_name);

                if(!empty($moved['error']) && $month_dir !== "")
                {
                        // Monthly directory failed — fall back to the root uploads directory
                        $month_dir = "";
                        $moved = upload_file($file, $uploadspath_abs."/", $stored_name);
                }
        }

        if(!empty($moved['error']))
        {
                dragdrop_attach_json_error($lang->dragdrop_error_upload);
        }

        if($month_dir !== "")
        {
                $stored_name = $month_dir."/".$stored_name;
        }

        if(!file_exists($uploadspath_abs."/".$stored_name))
        {
                dragdrop_attach_json_error($lang->dragdrop_error_upload);
        }

        // ------------------------------------------------------------------
        // MIME type — chunked uploads carry no browser MIME, and universal
        // mode types are unregistered, so derive a sane type from the content
        // ------------------------------------------------------------------
        $moved_type = isset($moved['type']) ? (string)$moved['type'] : "";

        if($moved_type === "")
        {
                $moved_type = dragdrop_attach_detect_mime($uploadspath_abs."/".$stored_name);
        }

        // ------------------------------------------------------------------
        // Image validation + thumbnail (mirrors core behaviour)
        // ------------------------------------------------------------------
        $thumbnail = "";

        if(in_array($ext, array("gif", "png", "jpg", "jpeg", "jpe")))
        {
                switch(my_strtolower($moved_type))
                {
                        case "image/gif":     $img_type = 1; break;
                        case "image/jpeg":
                        case "image/x-jpg":
                        case "image/x-jpeg":
                        case "image/pjpeg":
                        case "image/jpg":     $img_type = 2; break;
                        case "image/png":
                        case "image/x-png":   $img_type = 3; break;
                        default:              $img_type = 0;
                }

                $supported_mimes = array();
                foreach($attachtypes as $at)
                {
                        if(!empty($at['mimetype']))
                        {
                                $supported_mimes[] = $at['mimetype'];
                        }
                }

                $img_dimensions = @getimagesize($uploadspath_abs."/".$stored_name);

                $mime = "";
                if(function_exists("finfo_open"))
                {
                        $file_info = finfo_open(FILEINFO_MIME);
                        list($mime, ) = explode(";", finfo_file($file_info, $uploadspath_abs."/".$stored_name), 1);
                        finfo_close($file_info);
                }
                elseif(function_exists("mime_content_type"))
                {
                        $mime = mime_content_type($uploadspath_abs."/".$stored_name);
                }

                if(!is_array($img_dimensions) || ($img_dimensions[2] != $img_type && !in_array($mime, $supported_mimes)))
                {
                        delete_uploaded_file($uploadspath_abs."/".$stored_name);
                        dragdrop_attach_json_error($lang->dragdrop_error_invalid);
                }

                // Generate the thumbnail when the image exceeds the configured size
                require_once MYBB_ROOT."inc/functions_image.php";

                $thumbname = str_replace(".attach", "_thumb.".$ext, $stored_name);
                $generated = generate_thumbnail(
                        $uploadspath_abs."/".$stored_name,
                        $uploadspath_abs,
                        $thumbname,
                        $mybb->settings['attachthumbh'],
                        $mybb->settings['attachthumbw']
                );

                if(!empty($generated['filename']))
                {
                        $thumbnail = $generated['filename'];
                }
                elseif(isset($generated['code']) && $generated['code'] == 4)
                {
                        $thumbnail = "SMALL";
                }
        }

        // ------------------------------------------------------------------
        // Visibility (mirrors core moderation behaviour for posts)
        // ------------------------------------------------------------------
        $visible = 1;

        if($context == "post")
        {
                $forumpermissions = forum_permissions($fid);

                if($forumpermissions['modattachments'] == 1 && !is_moderator($fid, "canapproveunapproveattachs"))
                {
                        $visible = 0;
                }
        }

        // ------------------------------------------------------------------
        // Insert the attachment row
        // ------------------------------------------------------------------
        $filetype = $moved_type;

        if(!preg_match("#^[a-z0-9/\-\.\+]+$#i", $filetype))
        {
                $filetype = "";
        }

        $attacharray = array(
                "pid"          => 0,
                "posthash"     => $db->escape_string($posthash),
                "uid"          => $uid,
                "filename"     => $db->escape_string($filename),
                "filetype"     => $db->escape_string($filetype),
                "filesize"     => $filesize,
                "attachname"   => $db->escape_string($stored_name),
                "downloads"    => 0,
                "dateuploaded" => TIME_NOW,
                "thumbnail"    => $db->escape_string($thumbnail),
                "visible"      => $visible
        );

        $aid = (int)$db->insert_query("attachments", $attacharray);

        $plugins->run_hooks("dragdrop_attach_upload_end", $attacharray);

        dragdrop_attach_write_log("ok", $GLOBALS['dragdrop_upload_ctx']);
        unset($GLOBALS['dragdrop_upload_ctx']);

        // ------------------------------------------------------------------
        // Response: rendered list row + refreshed quota bar
        // ------------------------------------------------------------------
        $row = $attacharray;
        $row['aid'] = $aid;

        dragdrop_attach_send_json(array(
                "success"  => 1,
                "aid"      => $aid,
                "posthash" => $posthash,
                "isimage"  => ($thumbnail !== "" || in_array($ext, array("gif", "png", "jpg", "jpeg", "jpe"))) ? 1 : 0,
                "html"     => dragdrop_attach_render_item($row, false, $context == "post"),
                "quota"    => dragdrop_attach_render_quota()
        ));
}

/**
 * AJAX: remove a staged (unclaimed) attachment.
 *
 * POST: my_post_key, aid, posthash
 */
function dragdrop_attach_ajax_remove()
{
        global $mybb, $db, $lang;

        require_once MYBB_ROOT."inc/functions_upload.php";

        $lang->load("dragdrop_attach");

        if(!verify_post_check($mybb->get_input('my_post_key'), true))
        {
                dragdrop_attach_json_error($lang->dragdrop_error_postkey);
        }

        $aid = (int)$mybb->get_input('aid');
        $posthash = trim((string)$mybb->get_input('posthash'));
        $uid = (int)$mybb->user['uid'];

        if($uid === 0 || !preg_match('#^[a-f0-9]{32}$#', $posthash))
        {
                dragdrop_attach_json_error($lang->dragdrop_error_generic);
        }

        $attachment = $db->fetch_array($db->simple_select(
                "attachments",
                "aid",
                "aid = '".$aid."' AND uid = '".$uid."' AND pid = 0 AND posthash = '".$db->escape_string($posthash)."'"
        ));

        if($attachment)
        {
                // Drop any draft mappings first
                $db->delete_query("dragdrop_pm", "aid = '".$aid."'");

                // Core helper: removes the row, files and empty monthly directories
                remove_attachment(0, $posthash, $aid);
        }

        dragdrop_attach_send_json(array(
                "success" => 1,
                "aid"     => $aid,
                "quota"   => dragdrop_attach_render_quota()
        ));
}

/**
 * AJAX: list the currently staged attachments (used after quick reply
 * submissions reset the posthash).
 *
 * POST: my_post_key, ddcontext, posthash, pid
 */
function dragdrop_attach_ajax_list()
{
        global $mybb, $db, $lang;

        $lang->load("dragdrop_attach");

        if(!verify_post_check($mybb->get_input('my_post_key'), true))
        {
                dragdrop_attach_json_error($lang->dragdrop_error_postkey);
        }

        if(dragdrop_attach_enabled() !== true || !dragdrop_attach_user_allowed())
        {
                dragdrop_attach_json_error($lang->dragdrop_error_notallowed);
        }

        $context = ($mybb->get_input('ddcontext') === "pm") ? "pm" : "post";
        $posthash = trim((string)$mybb->get_input('posthash'));
        $pid = (int)$mybb->get_input('pid');
        $uid = (int)$mybb->user['uid'];

        if(!preg_match('#^[a-f0-9]{32}$#', $posthash))
        {
                dragdrop_attach_send_json(array("success" => 1, "items" => array(), "quota" => ""));
        }

        if($context == "pm" && $mybb->settings['dragdrop_attach_pm'] != 1)
        {
                dragdrop_attach_json_error($lang->dragdrop_error_pm_disabled);
        }

        $items = dragdrop_attach_current_items($context, $posthash, ($context == "post" ? $pid : 0), 0, array());

        dragdrop_attach_send_json(array(
                "success" => 1,
                "items"   => $items,
                "quota"   => dragdrop_attach_render_quota()
        ));
}
