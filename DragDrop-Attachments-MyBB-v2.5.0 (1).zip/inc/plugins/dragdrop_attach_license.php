<?php
/**
 * DragDrop Attachments — license & anti-theft module
 * وحدة حماية وترخيص إضافة المرفقات بالسحب والإفلات
 *
 * Encoded distribution build — DO NOT EDIT.
 * Keys are domain-locked HMAC signatures; any install without a valid
 * key is locked IMMEDIATELY (no trial) until a key is entered in
 * Admin CP -> Tools -> DragDrop Attachments -> License.
 */

if(!defined("IN_MYBB"))
{
        die("Direct initialization of this file is not allowed.");
}

if(!function_exists("dragdrop_attach_license_ok"))
{
        /**
         * Rolling-XOR stream decoder (pair of the builder encoder).
         */
        function dragdrop_attach_lic_stream($data, $pass)
        {
                $out = "";
                $plen = strlen($pass);
                for($i = 0, $n = strlen($data); $i < $n; $i++)
                {
                        $out .= $data[$i] ^ $pass[$i % $plen];
                }

                return $out;
        }

        $___ddal = 'hGEIRu4KKs7dNRG4TxKOIFIIg9N2Ciz8Y+7NRVel2nnfytJlJBAbk/XkJ5Bc/lGT1ygQsgjqpFSJZ8FV2Kfup5wfvzQr7rjXnodl725pI1S5EgIOj1J6eA1hZ18tgm0zw+98S6eiQxwk6o0UUaKPF/AfpRR7zwld9cYbwWbNlNeS5uLLh7fAncwkqgoGDpd8m52GrD4gSGg62A7AW8HJdrtKrwKuV7nDRSBRo2l6RNoXNzs3GKD3Ua6jVP5yjPhanqXlzb31mt2x4w9sXZT58LYC+X32Gix3QZqTBqt46WZB7dY3CJ8pVITrfkxpDZCqAZnd1/cGnUykLtd9+/DbKCEhzk7m7kKOpCGEqUulZG6vm+kQFHZX9F57Z6bA90K3QApCGUdbhMy3KzWVfBfU3QxUmL/WrujEMhqbHJMA96gSLzFqBBB7gAsRSyJgLY68vTatEnwudvgPa4h7QHq75zMOoUB4LZ0ZEi7QOCvJEJgEmTDYk1zVGXaFrFNcant0EYME7dFT9HB1/ddG+VAL6B6WQVFxq5EhcVz/PL0QA3wOfNMBDKeu72DdA8zc88CvmqbLHyUfsduI6Kd38SdbynfiKlGpD7WLM4Rk900OGnLQ5RHXr92eElSf4ZC2Kac9/fYrKq5fzBEeBmMsB4DTVMOJ0dLMyGvOM7qNxtJRqKX21PRW2mQTUvHUjSYJDTVYo7/nXlIaJ7Ee1iJI5NamkQxNMWdW5LAtyh4qdnRol9dVfu0DPtuL1rS6OyUWkLlD+56V8jM91FcMbUn4Ge+JygdLysPqhKPaXcTVdfn13/yE3A23RTB+ijMayWebMWe8fRXy1nEkJkUfgVXXkh3K70nU2u3P5sCZQkuwDQ4tZG6uaw/Cq86OqZ4W4LSU0K79CwC57+rv5u3vXw1OHNDeLoWONvrp4gvkTNGyqWjd3ZuvpdGhKsMaCcO8O8a8dVi0eyfxGHd5GCRmViC806vJpTMhKa3c4g2wCL4ztWdnctDGeWOutDwFAvSrXBg4y5qQtbhPCWk/9SjeEG246L+2zxVGWfsTI8MIy1fvd0ezONSaezvGPVPMLqcqoYJdlnTktmLGZ+nE8L4UZWlpQ4wGq1pYeCwMNIlrf7q+BsZ8d7lXX9S3L1rCA3Fq43nI28JzYYMu6tCiKdi+8jvwZrz0HbuW/4tbPsWZZaAxaytmcyOT07EJW1qEMxWttAYwPjBil2hg0TyCII4zPcIYUXoKqypZSfO0U+fvIldUxdPUpXPs9pZDrcUhGWQZ8tC6G5OhQgzjuLCyKhEnBfFAEtAheRaZPlWVrhMg0XyumTgPyKR+/+yCD27QlN9C3snwKxLLEHBOcFsF9VL8RHoETWaxGCVoWOT0xsg4dQc7MH5Q0ZOsEqfZMEmU+rwkhird2zTvnM0+MvmcD++qQ5CbRjYV7elqwPA2yMahNiuRxMXivvxdp8YmNtUaMqv5p91eBFBW0CbLPh5aZGZnCT0EhvUlOiVynLBxYJULrJapnyPIxGmo1+AUx+Yo6az8SomUnmqOan/86fqf92tFGVoIulghocHsqOvXmidqduy6xilRfbfDmfsN8+gxeCBTnQFINSrSKQLnpoIoLokqnt3qUybYmr8tBtudPkQTr99kLk629bHPw2hyQoJmgCYfehUs8ir+9tIIb+jrjpYC8fY3SPXb5AOhriDzCm5emki/aCAzRCiKowcu33tn5ojnIIIuRjS3YufDdKG0NJIuPmx3gXXzLaAat3lTkYkJkz3cdiPp/VyvVgKGc/9vWFNW2dIpBm5u9FBkXud+uDlvl8IYpuT2QnL13RVI26YYEroGwyWSXeQov/uXzlfiuiqrkNxLB7v7VTBvlyR/vvNoIgW0Gcy1ISCCAC0AiUc4KtIg29ea9FdjTBbR2O/+wayo3vHI5vIiGVIodZ9o1sY8cG11UdL5rSxIoK5Z0yYcwH6IAQlx8j2nEAmwH8mM50TiJ8MCCvxc7O+w3WbtKvw1CXQeUYgJFGDK2AXkYQawjAJkRK8Ag9FPPT/UoU457nefIqyHX8qp++vB3FVVIZARQ8OCC4PgyDBPk85MEL06+OXRdM6AN1xxJyL884T2qZL6niOa50gn/w+l2GThEqnWtudTYAy+szU+8yHEX361GIyjNEMXJx6yDUDrhFwtQce3ACfUIQhciF3OU7pYyK7RPOKDktLsDKtMTldmQLNTPgf6qoyYkZpVwhKwfc03/N3OiWiBWg0Okjc5cuBFNhd4dPSK9vdrGKRfe3NS2riN+W8B3UDmnXWSyJhKE7l1lA83hSsbL0uSoprt04RmUsf8b3WYM8Q7HcjJ1u/J+MLQEkSTI0NQrDyThZ5/uQ1bE4YRLRRUK3SqTU2wD2PwFPKXBlC0KBk/WDIqssYMrwHscPmbvQUSZGD8LqW3hpVpMnJ42/FIXE7Wn8JeCa612C9Gc4tnFgys0957JJ0Fv1Sqr/zI1kQrc3Pas7D9uMrhW8ogrezsQDstX0vQIoDaiZnANuFhQGPIVRqJb9pQ8fr1ToHrU54Wo5PbXZSdNGB4q+JjZDMhkq47+ZGMUpG/Mp18mc5dPevPIPm5Npsrm6S5Vnq1uWPSO8QwPriJeebDVptqhlsciVvLQRFsaL6QkCJl5tvmX4ONd7KPMGacfjcyucHVFr2za/GVXKt8zrdmE3Z0tA5LQeU//EWv9oyOd31TEEA2nSFrwWAT5m/RATf3skG6EHAL6ctQBd6Gfz7m84dlXR2fa2Xh4s270/zGdGKv5al10u/JIpPJXH5xWfIvYTEXhmwV89hsi0ap7xkDSSLMHmccklpU8MsCd4D7cJm+AnLtu5gbY02HBt0kl0hj04sWb37/Mie02pSWqbaY4eD3H7L8WRunYew8qGXiofWR7fO5xj/uZ2xfK/yXlIYtbfIDYM2DOgqkUN/r5jiV9wINdr+obYNJe/VEodhCay+byzgcZc7JN/tCzPqUCWEOHmd3t5PDxGc2E3guV8Q2c5Ojco1vY1CaWXu+uaBkUhHtBFmZfAzcoyZ7D2b2eJ07j+sJNRmmFx2Y0SRte9+kDGsnw4yoMfKM/1938BBtpvBpJaynyPbwa+VugGZz7VsTnlS9Af4xoQJXEgEMw8VxJcs0';

        if(is_string($___ddal) && crc32($___ddal) === 1332952363)
        {
                $___ddad = @gzinflate(dragdrop_attach_lic_stream(@base64_decode($___ddal), "18c452802f14e432"."73501359"));

                if(is_string($___ddad) && strpos($___ddad, "function dragdrop_attach_lic_normalize") !== false)
                {
                        eval($___ddad);
                }
                unset($___ddad);
        }
        unset($___ddal);
}