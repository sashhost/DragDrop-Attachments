<?php
/**
 * DragDrop Attachments — Arabic Admin CP language pack
 * حزمة لغة لوحة الإدارة العربية لإضافة المرفقات بالسحب والإفلات
 */

$l['dragdrop_attach_name'] = "المرفقات بالسحب والإفلات (DragDrop Attachments)";
$l['dragdrop_attach_desc'] = "رفع المرفقات بالسحب والإفلات في المشاركات والرد السريع والرسائل الخاصة — مع الصور المصغرة، وصلاحيات لكل مجموعة، وحصص التخزين، وتصميم مبني على قوالب MyBB الأصلية (12 قالباً).";
$l['dragdrop_attach_group_desc'] = "إعدادات إضافة المرفقات بالسحب والإفلات (الرفع، مرفقات الرسائل الخاصة، الحصص والصلاحيات).";

$l['dragdrop_attach_enabled_title'] = "تفعيل الإضافة";
$l['dragdrop_attach_enabled_desc'] = "عند التعطيل تختفي مناطق السحب والإفلات ويستمر عمل صندوق المرفقات الافتراضي في MyBB كالمعتاد.";

$l['dragdrop_attach_groups_title'] = "المجموعات المسموح لها";
$l['dragdrop_attach_groups_desc'] = "قائمة مفصولة بفواصل لأرقام المجموعات المسموح لها باستخدام الرفع بالسحب والإفلات (مثال: 2,3,4,6). اتركها فارغة للسماح لجميع الأعضاء المسجلين (الضيوف مستثنون دائماً).";

$l['dragdrop_attach_pm_title'] = "مرفقات الرسائل الخاصة";
$l['dragdrop_attach_pm_desc'] = "يضيف منطقة رفع إلى نموذج إنشاء الرسائل الخاصة والرد السريع للرسائل، ويعرض المرفقات على المستلمين وفي مجلد الصادر لدى المرسل.";

$l['dragdrop_attach_quickreply_title'] = "دعم الرد السريع في المنتديات";
$l['dragdrop_attach_quickreply_desc'] = "يضيف منطقة الرفع إلى نموذج الرد السريع في المواضيع، وتُربط الملفات بنظام posthash القياسي في MyBB عند إرسال الرد.";

$l['dragdrop_attach_maxfiles_title'] = "الحد الأقصى للملفات لكل رسالة";
$l['dragdrop_attach_maxfiles_desc'] = "عدد الملفات المسموح إرفاقها في الرسالة الواحدة. ضع 0 لاستخدام حد MyBB الأساسي (الإعدادات ← النشر ← maxattachments).";

$l['dragdrop_attach_quota_title'] = "حصة التخزين الافتراضية (ميجابايت)";
$l['dragdrop_attach_quota_desc'] = "حصة تخزين المرفقات لكل عضو بالميجابايت، وتحتسب مرفقات المشاركات والرسائل الخاصة معاً. ضع 0 لعدم التحديد (تُستخدم حينها حصة MyBB الأساسية لكل مجموعة كبديل).";

$l['dragdrop_attach_groupquotas_title'] = "حصص التخزين لكل مجموعة (ميجابايت)";
$l['dragdrop_attach_groupquotas_desc'] = "تجاوز الحصة الافتراضية لمجموعات محددة. الصيغة: رقم_المجموعة=الميجابايت مفصولة بفواصل، مثال: 2=50,3=200 (القيم الصفرية تُتجاهل وتُعتمد أعلى قيمة مطابقة للعضو).";

$l['dragdrop_attach_insertbutton_title'] = "إظهار زر \"إدراج في المشاركة\"";
$l['dragdrop_attach_insertbutton_desc'] = "يضيف زراً بجانب كل مرفق لإدراج كود [attachment=X] في موضع المؤشر داخل المحرر. ينطبق على نماذج المشاركات فقط.";

$l['dragdrop_attach_hidenative_title'] = "إخفاء صندوق المرفقات الافتراضي";
$l['dragdrop_attach_hidenative_desc'] = "عند نشاط منطقة السحب والإفلات في نماذج المشاركات الكاملة، يُخفى صندوق المرفقات الكلاسيكي لتجنب تداخل واجهتي رفع. عطّله للإبقاء على الاثنين معاً.";

$l['dragdrop_attach_logging_title'] = "تسجيل نشاط الرفع";
$l['dragdrop_attach_logging_desc'] = "يسجل كل محاولة رفع (الناجحة والمرفوضة) في سجل النشاط، ويمكن الاطلاع عليه من: الصيانة والأدوات ← المرفقات بالسحب والإفلات ← سجل النشاط.";

$l['dragdrop_attach_logdays_title'] = "مدة الاحتفاظ بالسجل (أيام)";
$l['dragdrop_attach_logdays_desc'] = "تُحذف سجلات النشاط الأقدم من هذا العدد من الأيام تلقائياً. ضع 0 للاحتفاظ بها للأبد.";

$l['dragdrop_attach_alltypes_title'] = "الوضع الشامل لقبول الصيغ";
$l['dragdrop_attach_alltypes_desc'] = "يقبل كل امتدادات الملفات حتى غير المعرّفة في أنواع مرفقات MyBB (الأدوات ← المرفقات بالسحب والإفلات ← حدود الحجم). امتدادات البرمجيات القابلة للتنفيذ مرفوضة دائماً.";

$l['dragdrop_attach_denyext_title'] = "الامتدادات المحظورة";
$l['dragdrop_attach_denyext_desc'] = "امتدادات إضافية يُرفض رفعها دائماً (مفصولة بفواصل). امتدادات البرمجيات القابلة للتنفيذ على الخادم (php, asp, cgi...) محظورة دائماً بصرف النظر عن هذه القائمة.";

$l['dragdrop_attach_maxsize_title'] = "الحد الأقصى العام لحجم الملف (ميجابايت)";
$l['dragdrop_attach_maxsize_desc'] = "الحجم الأقصى للمرفق الواحد بالميجابايت. ضع 0 للاعتماد على حدود الأنواع في إعدادات مرفقات MyBB، أو ضع قيمة لتجاوزها.";

$l['dragdrop_attach_extsizes_title'] = "قواعد الحجم لكل امتداد (ميجابايت)";
$l['dragdrop_attach_extsizes_desc'] = "قاعدة في كل سطر (أو مفصولة بفواصل): الامتداد=الميجابايت، مثال: zip=500, mp4=800, iso=2048. القاعدة تتجاوز دائماً الحد العام وحد نوع المرفق الأساسي.";

$l['dragdrop_attach_chunk_title'] = "عتبة الرفع المجزأ (ميجابايت)";
$l['dragdrop_attach_chunk_desc'] = "الملفات الأكبر من هذا الحجم تُرفع على شكل أجزاء بهذا الحجم، متجاوزة حدود upload_max_filesize / post_max_size في PHP — وهذا ما يجعل رفع الملفات الضخمة ممكناً. ضع 0 للتعطيل. الحد الأقصى: 32 ميجابايت.";

$l['dragdrop_attach_postbit_title'] = "التصميم الاحترافي لمرفقات المواضيع";
$l['dragdrop_attach_postbit_desc'] = "يعيد تصميم صندوق مرفقات المشاركات الظاهر أسفل الردود بأسلوب 2026: بطاقات ملفات أنيقة مع شارة امتداد ملونة وحجم الملف وأيقونة تنزيل، وشبكة مصغرات متجاوبة بتأثيرات ظهور سلسة (يعمل لجميع الزوار).";

$l['dragdrop_attach_dlwait_title'] = "بوابة التحميل (صفحة إعادة التوجيه بعدّاد)";
$l['dragdrop_attach_dlwait_desc'] = "عند الضغط على رابط تنزيل مرفق تظهر صفحة انتظار احترافية بأسلوب Aurora Glass مع عدّاد تنازلي دائري، ثم يبدأ التحميل تلقائياً. تعمل مع بطاقات مرفقات المواضيع وروابط ملفات الرسائل الخاصة.";

$l['dragdrop_attach_dlwait_time_title'] = "مدة الانتظار (ثانية)";
$l['dragdrop_attach_dlwait_time_desc'] = "عدد الثواني التي يعدّها العدّاد التنازلي قبل بدء التحميل تلقائياً (من 1 إلى 60، الافتراضي 5).";

$l['dragdrop_attach_dlwait_skip_title'] = "زر «تحميل الآن» (تخطي الانتظار)";
$l['dragdrop_attach_dlwait_skip_desc'] = "إظهار زر يتيح للزائر بدء التحميل فوراً دون انتظار انتهاء العدّاد.";

// ---------------------------------------------------------------------
// لوحة تحكم الإضافة (الأدوات والصيانة ← المرفقات بالسحب والإفلات)
// ---------------------------------------------------------------------

$l['dragdrop_acp_menu'] = "المرفقات بالسحب والإفلات";
$l['dragdrop_acp_permission'] = "يمكنه إدارة لوحة المرفقات بالسحب والإفلات";

$l['dragdrop_acp_tab_stats'] = "الإحصائيات";
$l['dragdrop_acp_tab_stats_desc'] = "استهلاك التخزين، الرفع لكل فترة، أكثر الأعضاء والامتدادات والأقساماً.";
$l['dragdrop_acp_tab_browse'] = "استعراض المرفقات";
$l['dragdrop_acp_tab_browse_desc'] = "بحث وعرض وحذف المرفقات (مشاركات، رسائل خاصة، مسودات، وملفات قيد الرفع).";
$l['dragdrop_acp_tab_quotas'] = "حصص المجموعات";
$l['dragdrop_acp_tab_quotas_desc'] = "تجاوزات حصص التخزين لكل مجموعة مع عرض توضيحي.";
$l['dragdrop_acp_tab_limits'] = "حدود الحجم";
$l['dragdrop_acp_tab_limits_desc'] = "الصيغ المسموح بها، الحد الأقصى لحجم الملف والامتدادات، والرفع المجزأ للملفات الكبيرة.";
$l['dragdrop_acp_tab_dlwait'] = "بوابة التحميل";
$l['dragdrop_acp_tab_dlwait_desc'] = "صفحة إعادة التوجيه بعدّاد انتظار تنازلي احترافي قبل بدء تنزيل المرفقات، مع معاينة حية.";
$l['dragdrop_acp_tab_logs'] = "سجل النشاط";
$l['dragdrop_acp_tab_logs_desc'] = "كل محاولات الرفع عبر مناطق السحب والإفلات.";
$l['dragdrop_acp_tab_tools'] = "الأدوات";
$l['dragdrop_acp_tab_tools_desc'] = "تنظيف الملفات اليتيمة، سلامة خريطة الرسائل الخاصة، إصلاح القوالب، وفحوصات النظام.";

$l['dragdrop_acp_yes'] = "نعم";
$l['dragdrop_acp_no'] = "لا";

// الإحصائيات
$l['dragdrop_acp_stats_settings_link'] = "افتح إعدادات المرفقات بالسحب والإفلات";
$l['dragdrop_acp_stats_overview'] = "نظرة عامة على المرفقات";
$l['dragdrop_acp_stats_metric'] = "المؤشر";
$l['dragdrop_acp_stats_value'] = "القيمة";
$l['dragdrop_acp_stats_total'] = "إجمالي المرفقات";
$l['dragdrop_acp_stats_size'] = "المساحة المستخدمة";
$l['dragdrop_acp_stats_today'] = "جديد اليوم";
$l['dragdrop_acp_stats_week'] = "آخر 7 أيام";
$l['dragdrop_acp_stats_month'] = "آخر 30 يوماً";
$l['dragdrop_acp_stats_unapproved'] = "بانتظار الموافقة";
$l['dragdrop_acp_stats_pm'] = "مرفقات الرسائل الخاصة";
$l['dragdrop_acp_stats_drafts'] = "مرفقات المسودات";
$l['dragdrop_acp_stats_staged'] = "قيد الرفع (غير ملتصقة)";
$l['dragdrop_acp_stats_downloads'] = "إجمالي التحميلات";
$l['dragdrop_acp_stats_topusers'] = "أكثر الأعضاء استهلاكاً للتخزين";
$l['dragdrop_acp_stats_topext'] = "أكثر أنواع الملفات";
$l['dragdrop_acp_stats_topforums'] = "أكثر الأقساماً";
$l['dragdrop_acp_stats_server'] = "فحوصات النظام";

$l['dragdrop_acp_col_user'] = "العضو";
$l['dragdrop_acp_col_count'] = "الملفات";
$l['dragdrop_acp_col_size'] = "الحجم";
$l['dragdrop_acp_col_controls'] = "التحكم";
$l['dragdrop_acp_col_ext'] = "الامتداد";
$l['dragdrop_acp_col_forum'] = "القسم";
$l['dragdrop_acp_col_file'] = "الملف";
$l['dragdrop_acp_col_posted'] = "ملتصق بـ";
$l['dragdrop_acp_col_downloads'] = "التحميلات";
$l['dragdrop_acp_col_date'] = "التاريخ";
$l['dragdrop_acp_col_ip'] = "عنوان IP";
$l['dragdrop_acp_col_group'] = "المجموعة";
$l['dragdrop_acp_col_quota'] = "الحصة (ميجابايت)";
$l['dragdrop_acp_col_effective'] = "الحصة الفعلية";

// الاستعراض
$l['dragdrop_acp_browse_view'] = "عرض";
$l['dragdrop_acp_browse_filters'] = "خيارات التصفية";
$l['dragdrop_acp_browse_keyword'] = "اسم الملف يحتوي";
$l['dragdrop_acp_browse_uid'] = "رقم العضو";
$l['dragdrop_acp_browse_ext'] = "الامتداد";
$l['dragdrop_acp_browse_forum'] = "القسم";
$l['dragdrop_acp_browse_forum_all'] = "كل الأقسام";
$l['dragdrop_acp_browse_context'] = "النوع";
$l['dragdrop_acp_browse_ctx_all'] = "كل الأنواع";
$l['dragdrop_acp_browse_inpost'] = "مشاركة";
$l['dragdrop_acp_browse_inpm'] = "رسالة خاصة";
$l['dragdrop_acp_browse_indraft'] = "مسودة رسالة";
$l['dragdrop_acp_browse_instaged'] = "قيد الرفع";
$l['dragdrop_acp_browse_sort'] = "الترتيب";
$l['dragdrop_acp_sort_date'] = "الأحدث أولاً";
$l['dragdrop_acp_sort_size'] = "الأكبر أولاً";
$l['dragdrop_acp_sort_downloads'] = "الأكثر تحميلاً";
$l['dragdrop_acp_sort_name'] = "اسم الملف (أ-ي)";
$l['dragdrop_acp_browse_visible'] = "الظهور";
$l['dragdrop_acp_browse_vis_all'] = "كل المرفقات";
$l['dragdrop_acp_browse_vis_waiting'] = "بانتظار الموافقة فقط";
$l['dragdrop_acp_browse_apply'] = "تصفية";
$l['dragdrop_acp_browse_results'] = "المرفقات";
$l['dragdrop_acp_browse_none'] = "لا توجد مرفقات مطابقة.";
$l['dragdrop_acp_browse_unapproved'] = "بانتظار الموافقة";

$l['dragdrop_acp_delete'] = "حذف";
$l['dragdrop_acp_delete_confirm'] = "هل أنت متأكد من حذف هذا المرفق نهائياً؟";
$l['dragdrop_acp_delete_confirm_named'] = "هل أنت متأكد من حذف \"{1}\" نهائياً؟ سيُحذف الملف من الخادم أيضاً.";
$l['dragdrop_acp_delete_success'] = "حُذف المرفق بنجاح.";
$l['dragdrop_acp_delete_missing'] = "المرفق المطلوب غير موجود.";

// الحصص
$l['dragdrop_acp_quotas_users'] = "الأعضاء الأساسيون";
$l['dragdrop_acp_quota_inherit'] = "يتبع الافتراضي";
$l['dragdrop_acp_quota_core'] = "حد MyBB الأساسي";
$l['dragdrop_acp_quotas_unlimited'] = "بلا حدود";
$l['dragdrop_acp_quotas_note'] = "اترك الحقل فارغاً (أو 0) لتتبع المجموعة الحصة الافتراضية. تحتسب الحصص مرفقات المشاركات والرسائل الخاصة معاً لكل عضو.";
$l['dragdrop_acp_quotas_save'] = "حفظ الحصص";
$l['dragdrop_acp_quotas_saved'] = "حُفظت حصص المجموعات بنجاح.";
$l['dragdrop_acp_quotas_default'] = "الحصة الافتراضية الحالية: {1} ميجابايت لكل عضو (تجاوز المجموعة له الأولوية دائماً).";
$l['dragdrop_acp_quotas_default_none'] = "لا توجد حصة افتراضية — المجموعات بدون تجاوز لها تخزين غير محدود (يُستخدم حد MyBB الأساسي attachquota كبديل إن ضُبط).";

// سجل النشاط
$l['dragdrop_acp_logs_disabled'] = "تسجيل نشاط الرفع معطل حالياً.";
$l['dragdrop_acp_logs_status'] = "الحالة";
$l['dragdrop_acp_logs_status_all'] = "كل الحالات";
$l['dragdrop_acp_log_ok'] = "ناجح";
$l['dragdrop_acp_log_denied'] = "مرفوض";
$l['dragdrop_acp_log_error'] = "خطأ";
$l['dragdrop_acp_logs_search'] = "اسم المستخدم أو اسم الملف…";
$l['dragdrop_acp_logs_prune'] = "حذف الأقدم من {1} يوماً";
$l['dragdrop_acp_logs_clear'] = "حذف كل السجلات";
$l['dragdrop_acp_logs_clear_confirm'] = "حذف جميع سجلات النشاط؟ لا يمكن التراجع عن هذا الإجراء.";
$l['dragdrop_acp_logs_pruned'] = "حُذفت سجلات النشاط الأقدم من {1} يوم/أيام.";
$l['dragdrop_acp_logs_cleared'] = "حُذفت جميع سجلات النشاط.";
$l['dragdrop_acp_logs_keep'] = "مدة الاحتفاظ: تُحذف السجلات الأقدم من {1} يوم/أيام تلقائياً.";
$l['dragdrop_acp_logs_none'] = "لا توجد سجلات مطابقة.";
$l['dragdrop_acp_logs_detail'] = "التفاصيل";

// الأدوات
$l['dragdrop_acp_tools_orphans_card'] = "الملفات اليتيمة";
$l['dragdrop_acp_tools_orphans_title'] = "ملفات في مجلد الرفع لم تعد مرتبطة بأي مرفق";
$l['dragdrop_acp_tools_orphans_desc'] = "يفحص مجلد uploads (مع المجلدات الشهرية الفرعية) بحثاً عن ملفات لا تنتمي لأي سجل مرفق. تُتجاهل الملفات الأحدث من 3 أيام لأنها قد تكون قيد الرفع الآن.";
$l['dragdrop_acp_tools_scan'] = "افحص الآن";
$l['dragdrop_acp_tools_orphans_found'] = "عُثر على {1} ملف/ملفات يتيمة بحجم إجمالي {2}.";
$l['dragdrop_acp_tools_orphans_none'] = "لا توجد ملفات يتيمة — مجلد الرفع نظيف.";
$l['dragdrop_acp_tools_delete_orphans'] = "حذف الملفات اليتيمة ({1})";
$l['dragdrop_acp_orphans_deleted'] = "حُذف {1} ملف/ملفات وحُررت مساحة {2} من القرص.";

$l['dragdrop_acp_tools_pm_card'] = "خريطة مرفقات الرسائل الخاصة";
$l['dragdrop_acp_tools_pm_title'] = "سجلات ربط يتيمة في خريطة الرسائل الخاصة";
$l['dragdrop_acp_tools_pm_desc'] = "يتحقق أن كل سجل في الخريطة الداخلية لمرفقات الرسائل الخاصة لا يزال يشير إلى مرفق ورسالة موجودين فعلاً، وينظف البقايا.";
$l['dragdrop_acp_tools_pm_issues'] = "عُثر على {1} سجل ربط يتيمي.";
$l['dragdrop_acp_tools_pm_ok'] = "خريطة مرفقات الرسائل الخاصة سليمة.";
$l['dragdrop_acp_tools_pm_fix'] = "إزالة السجلات اليتيمة ({1})";
$l['dragdrop_acp_pm_fixed'] = "أُزيل {1} سجل ربط يتيمي.";

$l['dragdrop_acp_tools_tpl_card'] = "قوالب الإضافة";
$l['dragdrop_acp_tools_tpl_title'] = "حالة مجموعة القوالب";
$l['dragdrop_acp_tools_tpl_desc'] = "تأتي الإضافة بـ 12 قالباً في مجموعة القوالب العامة. إعادة التثبيت تستعيد النسخ الأصلية إذا حُذف أو تلف أي منها أثناء التعديل.";
$l['dragdrop_acp_tools_tpl_ok'] = "جميع القوالب ({1}) موجودة في مجموعة القوالب العامة.";
$l['dragdrop_acp_tools_tpl_missing'] = "وُجد {1} من أصل {2} قالباً فقط — أعد التثبيت لاستعادة الناقص.";
$l['dragdrop_acp_tools_tpl_reinstall'] = "إعادة تثبيت القوالب";
$l['dragdrop_acp_tpl_reinstalled'] = "أُعيد تثبيت قوالب الإضافة بنجاح.";

// فحوصات النظام
$l['dragdrop_acp_diag_check'] = "الفحص";
$l['dragdrop_acp_diag_value'] = "القيمة";
$l['dragdrop_acp_diag_version'] = "إصدار الإضافة";
$l['dragdrop_acp_diag_php'] = "إصدار PHP";
$l['dragdrop_acp_diag_uploads_dir'] = "مجلد الرفع";
$l['dragdrop_acp_diag_missing'] = "مفقود";
$l['dragdrop_acp_diag_uploads_writable'] = "قابلية الكتابة في مجلد الرفع";
$l['dragdrop_acp_diag_monthly'] = "مجلد الشهر الحالي";
$l['dragdrop_acp_diag_ready'] = "موجود";
$l['dragdrop_acp_diag_will_create'] = "سيُنشأ عند أول رفع";
$l['dragdrop_acp_diag_gd'] = "امتداد GD (المصغرات)";
$l['dragdrop_acp_diag_attachtypes'] = "أنواع المرفقات المسموحة";
$l['dragdrop_acp_diag_maxfiles'] = "الحد الأقصى للملفات لكل رسالة";
$l['dragdrop_acp_diag_core_limit'] = "حد النواة";
$l['dragdrop_acp_diag_logging'] = "تسجيل نشاط الرفع";
$l['dragdrop_acp_diag_php_limits'] = "حدود الرفع في PHP";
$l['dragdrop_acp_diag_alltypes'] = "الوضع الشامل لقبول الصيغ";
$l['dragdrop_acp_diag_chunking'] = "الرفع المجزأ للأكبر من";
$l['dragdrop_acp_diag_disabled'] = "معطل";
$l['dragdrop_acp_diag_templates'] = "قوالب الإضافة الموجودة";

// حدود الحجم
$l['dragdrop_acp_limits_info'] = "اقبل أي صيغة ملفات، وتحكم بالحد الأقصى لحجم المرفقات، وفعّل الرفع المجزأ للملفات الضخمة. القيم المُدخلة هنا هي نفسها مجموعة إعدادات الإضافة — وتنطبق في كل مكان تُستخدم فيه منطقة السحب والإفلات.";
$l['dragdrop_acp_limits_php'] = "حدود الخادم المُبلّغ عنها من PHP: upload_max_filesize = {1} · post_max_size = {2}. الأجزاء الأكبر من هذه القيم يرفضها الخادم قبل تشغيل الإضافة — أبقِ عتبة التقسيم أقل منها.";
$l['dragdrop_acp_limits_types'] = "الصيغ المسموح بها";
$l['dragdrop_acp_limits_sizes'] = "الأحجام القصوى للملفات";
$l['dragdrop_acp_limits_alltypes'] = "الوضع الشامل لقبول الصيغ";
$l['dragdrop_acp_limits_alltypes_desc'] = "عند التفعيل، يُقبل كل امتداد حتى غير المعرّف في (الإعدادات ← أنواع المرفقات). الامتدادات في قائمة الحظر أدناه (وسكربتات الخادم القابلة للتنفيذ) مرفوضة دائماً.";
$l['dragdrop_acp_limits_denyext'] = "الامتدادات المحظورة";
$l['dragdrop_acp_limits_denyext_desc'] = "امتدادات إضافية للرفض مفصولة بفواصل، مثال: exe,msi,bat. القائمة المدمجة لسكربتات الخادم (php, phar, asp, cgi...) لا يمكن إزالتها.";
$l['dragdrop_acp_limits_maxsize'] = "الحد الأقصى العام لحجم الملف (ميجابايت)";
$l['dragdrop_acp_limits_maxsize_desc'] = "0 = الاعتماد على حدود أنواع MyBB. أي قيمة أخرى تتجاوزها لكل أنواع الملفات.";
$l['dragdrop_acp_limits_extsizes'] = "قواعد الحجم لكل امتداد (ميجابايت)";
$l['dragdrop_acp_limits_extsizes_desc'] = "قاعدة في كل سطر: الامتداد=الميجابايت، مثال: zip=500. القواعد تتجاوز دائماً الحد العام وحد نوع المرفق الأساسي.";
$l['dragdrop_acp_limits_chunk'] = "عتبة الرفع المجزأ (ميجابايت)";
$l['dragdrop_acp_limits_chunk_desc'] = "الملفات الأكبر من هذا الحجم تُرفع على شكل أجزاء بهذا الحجم متجاوزة حدود PHP الموضحة أعلاه. 0 يعطل الرفع المجزأ. الحد الأقصى 32 ميجابايت.";
$l['dragdrop_acp_limits_save'] = "حفظ حدود الحجم";
$l['dragdrop_acp_limits_saved'] = "تم حفظ حدود الحجم وسياسة قبول الصيغ.";
$l['dragdrop_acp_limits_rules'] = "القواعد النشطة لكل امتداد";
$l['dragdrop_acp_limits_norules'] = "لا توجد قواعد لكل امتداد — يُعتمد الحد العام (أو حدود أنواع MyBB).";
$l['dragdrop_acp_limits_note'] = "الأولوية لكل ملف: قاعدة الامتداد ← الحد العام ← حد نوع المرفق الأساسي ← بلا حدود. حصة التخزين (تبويب حصص المجموعات) مستقلة عن حدود الحجم وتبقى مطبقة.";

// بوابة التحميل (v2.3.0)
$l['dragdrop_acp_dlwait_info'] = "بوابة التحميل تعرض لزوار منتداك صفحة انتظار أنيقة بأسلوب Aurora Glass عند الضغط على رابط تنزيل مرفق: أيقونة الملف بلون امتداده، الحجم وعدد مرات التنزيل، حلقة عدّاد تنازلي دوّارة بالثواني، وشريط تقدم متلألئ — ثم يبدأ التحميل تلقائياً عند انتهاء العدّ. الصفحة متجاوبة، تدعم RTL، وتحترم تفضيل تقليل الحركة.";
$l['dragdrop_acp_dlwait_general'] = "إعدادات بوابة التحميل";
$l['dragdrop_acp_dlwait_enable'] = "تفعيل بوابة التحميل";
$l['dragdrop_acp_dlwait_enable_desc'] = "تشغيل أو إيقاف صفحة الانتظار قبل تنزيل المرفقات. عند الإيقاف تُفتح الملفات مباشرة كما في النواة.";
$l['dragdrop_acp_dlwait_time'] = "مدة العدّ التنازلي (ثانية)";
$l['dragdrop_acp_dlwait_time_desc'] = "من 1 إلى 60 ثانية (الافتراضي 5). يظهر العدد داخل الحلقة الدائرية مع شريط تقدم.";
$l['dragdrop_acp_dlwait_skip'] = "زر «تحميل الآن»";
$l['dragdrop_acp_dlwait_skip_desc'] = "إظهار زر تخطي يتيح بدء التحميل فوراً دون انتظار العدّ التنازلي.";
$l['dragdrop_acp_dlwait_save'] = "حفظ إعدادات البوابة";
$l['dragdrop_acp_dlwait_saved'] = "تم حفظ إعدادات بوابة التحميل.";
$l['dragdrop_acp_dlwait_preview'] = "معاينة حية للصفحة";
$l['dragdrop_acp_dlwait_scope'] = "نطاق العمل: تُمرَّر روابط التنزيل عبر البوابة في بطاقات مرفقات المواضيع (بعد إعادة التصميم) وفي روابط ملفات الرسائل الخاصة. المصغرات والصور المضمنة والروابط المباشرة لا تتأثر أبداً حتى لا يتعطل أي شيء في صفحات المنتدى.";

// الحماية والترخيص (v2.4.0)
$l['dragdrop_acp_tab_license'] = "الحماية والترخيص";
$l['dragdrop_acp_tab_license_desc'] = "حالة ترخيص الإضافة على هذا النطاق، وإدخال المفتاح الذي يفتح ميزات الإضافة.";
$l['dragdrop_acp_lic_state_licensed'] = "مرخّصة";
$l['dragdrop_acp_lic_state_locked'] = "غير مرخّصة — الميزات متوقفة";
$l['dragdrop_acp_lic_state_dev'] = "نطاق تطوير";
$l['dragdrop_acp_lic_state_missing'] = "وحدة الترخيص مفقودة";
$l['dragdrop_acp_lic_licensed_domain'] = "الإضافة مرخّصة على النطاق: {1} — جميع الميزات تعمل بلا قيود.";
$l['dragdrop_acp_lic_licensed_master'] = "الإضافة مرخّصة بمفتاح رئيسي صالح لأي نطاق — جميع الميزات تعمل بلا قيود.";
$l['dragdrop_acp_lic_locked_detail'] = "لا يوجد مفتاح ترخيص صالح لهذا النطاق — ميزات الإضافة مقفلة. احصل على مفتاح من المطوّر والصقه بالأسفل (المنتدى نفسه يبقى يعمل بشكل طبيعي).";
$l['dragdrop_acp_lic_dev_note'] = "الإضافة تعمل على نطاق تطوير (localhost أو نطاق اختبار) — الترخيص غير مطلوب أثناء التطوير والتجربة.";
$l['dragdrop_acp_lic_module_missing'] = "ملف وحدة الترخيص (inc/plugins/dragdrop_attach_license.php) مفقود أو تالف — أعد رفع جميع ملفات الإضافة كاملة حتى تعود الميزات للعمل.";
$l['dragdrop_acp_lic_domain_label'] = "نطاق منتداك المُكتشف:";
$l['dragdrop_acp_lic_domain_hint'] = "للحصول على مفتاح ترخيص صالح أرسل هذا النطاق (كما هو مكتوب تماماً) إلى المطوّر. المفتاح يعمل على هذا النطاق فقط.";
$l['dragdrop_acp_lic_form'] = "مفتاح الترخيص";
$l['dragdrop_acp_lic_key'] = "مفتاح الترخيص";
$l['dragdrop_acp_lic_key_desc'] = "الصيغة: DDA-XXXX-XXXX-XXXX-XXXX (تُقبل أيضاً بدون شرطات). اتركه فارغاً واضغط حفظ لمسح المفتاح المخزّن.";
$l['dragdrop_acp_lic_save'] = "حفظ الترخيص";
$l['dragdrop_acp_lic_saved'] = "تم قبول مفتاح الترخيص — شكراً لدعمك الإضافة!";
$l['dragdrop_acp_lic_cleared'] = "تم مسح مفتاح الترخيص المخزّن.";
$l['dragdrop_acp_lic_invalid'] = "مفتاح الترخيص غير صالح لهذا النطاق — تأكد من نسخه كما أُعطي لك تماماً، أو راسل المطوّر مع نطاقك المكتشف أعلاه.";
$l['dragdrop_acp_lic_howto'] = "كيف تعمل الحماية: المفتاح مرتبط بنطاق منتداك ولا يعمل على أي نطاق آخر. أي نسخة تُركّب بدون مفتاح صالح تبقى مقفلة من اللحظة الأولى (لا توجد فترة تجريبية) — تبقى ميزات الإضافة متوقفة بينما المنتدى نفسه يعمل بشكل طبيعي. نطاقات التطوير (localhost، 127.0.0.1، ‎*.local، ‎*.test) معفاة دائماً.";

// إعدادات الترخيص (تظهر في الإعدادات أيضاً)
$l['dragdrop_attach_license_title'] = "مفتاح الترخيص";
$l['dragdrop_attach_license_desc'] = "المفتاح المرتبط بنطاق منتداك (DDA-XXXX-XXXX-XXXX-XXXX). الإدارة الأسرع من تبويب «الحماية والترخيص» في صفحة الإضافة.";

// سطر التطوير والدعم (يظهر أسفل كل صفحات لوحة الإضافة)
$l['dragdrop_acp_credit'] = "تم تطوير هذه الإضافة بواسطة موقع <a href=\"https://nulledpost.com\" target=\"_blank\" rel=\"noopener\">nulledpost.com</a> &mdash; للتواصل والطلب والدعم الفني واتساب: <a href=\"https://wa.me/963934993506\" target=\"_blank\" rel=\"noopener\">00963934993506</a>";
