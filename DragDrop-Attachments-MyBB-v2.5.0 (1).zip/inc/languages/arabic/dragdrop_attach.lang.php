<?php
/**
 * DragDrop Attachments — Arabic front-end language pack
 * حزمة لغة الواجهة العربية لإضافة المرفقات بالسحب والإفلات
 */

$l['dragdrop_drop_text'] = "اسحب الملفات وأفلتها هنا";
$l['dragdrop_drop_active'] = "أفلت الملفات الآن";
$l['dragdrop_browse'] = "تصفح الملفات";
$l['dragdrop_note_maxfiles'] = "حتى {1} ملفات لكل رسالة";
$l['dragdrop_note_maxsize'] = "الحجم الأقصى {1} للملف الواحد";
$l['dragdrop_quota_used'] = "المساحة المستخدمة: {1} من {2}";
$l['dragdrop_uploading'] = "جارٍ الرفع…";
$l['dragdrop_busy'] = "جارٍ رفع الملفات…";
$l['dragdrop_unit_sec'] = "ث";
$l['dragdrop_remove'] = "إزالة";
$l['dragdrop_insert'] = "إدراج في المشاركة";
$l['dragdrop_remove_confirm'] = "هل أنت متأكد من إزالة هذا المرفق؟";

// لوحة مرفقات الرسائل الخاصة
$l['dragdrop_pm_title'] = "مرفقات الرسالة";
$l['dragdrop_pm_thumbnails'] = "المصغرات";
$l['dragdrop_pm_images'] = "الصور";
$l['dragdrop_pm_files'] = "الملفات";
$l['dragdrop_pm_downloads'] = "التحميلات: {1}";

// الأخطاء
$l['dragdrop_error_disabled'] = "المرفقات معطلة حالياً في المنتدى.";
$l['dragdrop_error_notallowed'] = "لا تمتلك صلاحية رفع المرفقات.";
$l['dragdrop_error_invalid_type'] = "هذا النوع من الملفات غير مسموح به.";
$l['dragdrop_error_too_large'] = "حجم الملف {1} يتجاوز الحد الأقصى المسموح وهو {2}.";
$l['dragdrop_error_quota'] = "لقد استهلكت كامل حصة التخزين المخصصة لك ({1}). يرجى حذف بعض المرفقات أولاً.";
$l['dragdrop_error_maxfiles'] = "لا يمكنك إرفاق أكثر من {1} ملفات في الرسالة الواحدة.";
$l['dragdrop_error_duplicate'] = "الملف {1} مرفق مسبقاً بهذه الرسالة.";
$l['dragdrop_error_postkey'] = "مفتاح الأمان غير صالح. يرجى تحديث الصفحة وإعادة المحاولة.";
$l['dragdrop_error_pm_disabled'] = "مرفقات الرسائل الخاصة معطلة.";
$l['dragdrop_error_upload'] = "تعذر رفع الملف، قد يكون فارغاً أو فشل الرفع.";
$l['dragdrop_error_invalid'] = "محتوى الملف غير صالح أو لا يطابق امتداده.";
$l['dragdrop_error_forum_closed'] = "هذا المنتدى مغلق — لا يمكن رفع مرفقات جديدة.";
$l['dragdrop_error_generic'] = "حدث خطأ غير معروف أثناء معالجة المرفق.";
$l['dragdrop_error_chunk_invalid'] = "طلب الرفع المجزأ غير صالح. يرجى المحاولة مرة أخرى.";
$l['dragdrop_error_chunk_restart'] = "انقطع تناغم الرفع — يرجى إعادة رفع الملف من البداية.";

// رسائل جانب العميل (JavaScript)
$l['dragdrop_error_client_too_large'] = "حجم الملف {1} يتجاوز الحد الأقصى المسموح وهو {2}.";

// بوابة التحميل — صفحة إعادة التوجيه بعدّاد تنازلي (v2.3.0)
$l['dragdrop_gate_title'] = "جارٍ تجهيز التحميل";
$l['dragdrop_gate_starts'] = "سيبدأ التحميل تلقائياً خلال";
$l['dragdrop_gate_ready'] = "ابدأ!";
$l['dragdrop_gate_now'] = "تحميل الآن";
$l['dragdrop_gate_cancel'] = "إلغاء والعودة";
$l['dragdrop_gate_hint'] = "لم يبدأ التحميل؟ اضغط زر «تحميل الآن». إذا لم يكن لديك صلاحية تنزيل هذا المرفق فلن يبدأ التحميل.";
$l['dragdrop_gate_dlcount'] = "تم تنزيله {1} مرة";

// ملاحظات منطقة الرفع
$l['dragdrop_note_alltypes'] = "جميع صيغ الملفات مسموح بها";
$l['dragdrop_note_sizerules'] = "حدود الحجم مطبقة حسب نوع الملف";
