<?php
/**
 * DragDrop Attachments — English front-end language pack
 */

$l['dragdrop_drop_text'] = "Drag & drop files here";
$l['dragdrop_drop_active'] = "Drop your files now";
$l['dragdrop_browse'] = "Browse files";
$l['dragdrop_note_maxfiles'] = "up to {1} files per message";
$l['dragdrop_note_maxsize'] = "max {1} per file";
$l['dragdrop_quota_used'] = "Storage used: {1} of {2}";
$l['dragdrop_uploading'] = "Uploading…";
$l['dragdrop_busy'] = "Uploading files…";
$l['dragdrop_unit_sec'] = "s";
$l['dragdrop_remove'] = "Remove";
$l['dragdrop_insert'] = "Insert into post";
$l['dragdrop_remove_confirm'] = "Remove this attachment?";

// PM attachments panel
$l['dragdrop_pm_title'] = "Message attachments";
$l['dragdrop_pm_thumbnails'] = "Thumbnails";
$l['dragdrop_pm_images'] = "Images";
$l['dragdrop_pm_files'] = "Files";
$l['dragdrop_pm_downloads'] = "Downloads: {1}";

// Errors
$l['dragdrop_error_disabled'] = "Attachments are currently disabled.";
$l['dragdrop_error_notallowed'] = "You are not allowed to upload attachments.";
$l['dragdrop_error_invalid_type'] = "This file type is not allowed.";
$l['dragdrop_error_too_large'] = "{1} exceeds the maximum allowed size of {2}.";
$l['dragdrop_error_quota'] = "Your attachment storage quota has been reached ({1}). Please remove some attachments first.";
$l['dragdrop_error_maxfiles'] = "You may attach up to {1} files per message.";
$l['dragdrop_error_duplicate'] = "{1} is already attached to this message.";
$l['dragdrop_error_postkey'] = "Invalid security token. Please refresh the page and try again.";
$l['dragdrop_error_pm_disabled'] = "Private message attachments are disabled.";
$l['dragdrop_error_upload'] = "The file could not be uploaded. It may be empty or the upload failed.";
$l['dragdrop_error_invalid'] = "The file content is not valid or does not match its extension.";
$l['dragdrop_error_forum_closed'] = "This forum is closed — new attachments cannot be uploaded.";
$l['dragdrop_error_generic'] = "An unknown error occurred while processing the attachment.";
$l['dragdrop_error_chunk_invalid'] = "The chunked upload request is invalid. Please try again.";
$l['dragdrop_error_chunk_restart'] = "The upload got out of sync — please start the upload again.";

// Client-side (JavaScript) messages
$l['dragdrop_error_client_too_large'] = "{1} exceeds the maximum allowed size of {2}.";

// Download gate — redirect page with countdown (v2.3.0)
$l['dragdrop_gate_title'] = "Preparing your download";
$l['dragdrop_gate_starts'] = "Your download will start automatically in";
$l['dragdrop_gate_ready'] = "Go!";
$l['dragdrop_gate_now'] = "Download now";
$l['dragdrop_gate_cancel'] = "Cancel and go back";
$l['dragdrop_gate_hint'] = "Download didn't start? Click the \"Download now\" button. If you lack permission for this attachment the download will not begin.";
$l['dragdrop_gate_dlcount'] = "Downloaded {1} time(s)";

// Drop zone notes
$l['dragdrop_note_alltypes'] = "all file types are accepted";
$l['dragdrop_note_sizerules'] = "size limits apply per file type";
