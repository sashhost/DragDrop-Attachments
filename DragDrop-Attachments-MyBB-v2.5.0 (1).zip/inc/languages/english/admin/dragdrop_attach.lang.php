<?php
/**
 * DragDrop Attachments — English Admin CP language pack
 */

$l['dragdrop_attach_name'] = "DragDrop Attachments";
$l['dragdrop_attach_desc'] = "Drag &amp; drop attachment uploads for posts, quick reply and private messages — image thumbnails, per-usergroup permissions, storage quotas and template-based design (12 templates).";
$l['dragdrop_attach_group_desc'] = "Settings for the DragDrop Attachments plugin (drag &amp; drop uploads, PM attachments, quotas and permissions).";

$l['dragdrop_attach_enabled_title'] = "Enable DragDrop Attachments";
$l['dragdrop_attach_enabled_desc'] = "When disabled, the plugin drop zones disappear and MyBB's native attachment box continues to work as usual.";

$l['dragdrop_attach_groups_title'] = "Allowed usergroups";
$l['dragdrop_attach_groups_desc'] = "Comma separated list of usergroup IDs allowed to use drag &amp; drop uploads (e.g. 2,3,4,6). Leave empty to allow every registered member (guests are never allowed).";

$l['dragdrop_attach_pm_title'] = "Private Message attachments";
$l['dragdrop_attach_pm_desc'] = "Adds a drop zone to the PM compose form and the PM quick reply, and shows the attachments to the recipients and in the sender's Sent Items folder.";

$l['dragdrop_attach_quickreply_title'] = "Forum Quick Reply support";
$l['dragdrop_attach_quickreply_desc'] = "Adds the drop zone to the thread Quick Reply form. Uploaded files are claimed through MyBB's standard posthash system when the reply is posted.";

$l['dragdrop_attach_maxfiles_title'] = "Maximum files per message";
$l['dragdrop_attach_maxfiles_desc'] = "How many files may be attached to a single message. Set 0 to follow MyBB's native limit (Configuration → Posting → maxattachments).";

$l['dragdrop_attach_quota_title'] = "Default storage quota (MB)";
$l['dragdrop_attach_quota_desc'] = "Per-user attachment storage quota in megabytes, counting posts and PM attachments together. Set 0 for unlimited (MyBB's core per-group attachquota is then used as a fallback).";

$l['dragdrop_attach_groupquotas_title'] = "Per-group storage quotas (MB)";
$l['dragdrop_attach_groupquotas_desc'] = "Overrides the default quota for specific usergroups. Format: gid=MB separated by commas, e.g. 2=50,3=200 (entries with 0 are ignored; the highest matching value wins).";

$l['dragdrop_attach_insertbutton_title'] = "Show \"Insert into post\" buttons";
$l['dragdrop_attach_insertbutton_desc'] = "Adds a button next to each staged attachment that inserts the [attachment=X] BB code at the editor cursor. Applies to post forms only.";

$l['dragdrop_attach_hidenative_title'] = "Hide the native attachment box";
$l['dragdrop_attach_hidenative_desc'] = "When the drag &amp; drop zone is active on the full post forms, hide MyBB's classic attachment box to avoid two competing upload interfaces. Disable it to keep both.";

$l['dragdrop_attach_logging_title'] = "Log upload activity";
$l['dragdrop_attach_logging_desc'] = "Records every upload attempt (successful or denied) in the activity log, viewable under Tools &amp; Maintenance → DragDrop Attachments → Logs.";

$l['dragdrop_attach_logdays_title'] = "Log retention (days)";
$l['dragdrop_attach_logdays_desc'] = "Activity log entries older than this many days are pruned automatically. Set 0 to keep them forever.";

$l['dragdrop_attach_alltypes_title'] = "Universal file type mode";
$l['dragdrop_attach_alltypes_desc'] = "Accepts EVERY file extension, even ones not defined in MyBB's attachment types (Tools → DragDrop Attachments → Size limits). Executable script extensions are always denied.";

$l['dragdrop_attach_denyext_title'] = "Blocked extensions";
$l['dragdrop_attach_denyext_desc'] = "Additional file extensions that are always rejected (comma separated). Server-executable extensions (php, asp, cgi, …) are always blocked regardless of this list.";

$l['dragdrop_attach_maxsize_title'] = "Global maximum file size (MB)";
$l['dragdrop_attach_maxsize_desc'] = "Maximum size of a single attachment in megabytes. Set 0 to follow the per-type limits of MyBB's attachment types. Set a value to override them.";

$l['dragdrop_attach_extsizes_title'] = "Per-extension size rules (MB)";
$l['dragdrop_attach_extsizes_desc'] = "One rule per line (or comma separated): extension=MB, e.g. zip=500, mp4=800, iso=2048. A rule always wins over the global maximum and over the core attachment type limit.";

$l['dragdrop_attach_chunk_title'] = "Chunked upload threshold (MB)";
$l['dragdrop_attach_chunk_desc'] = "Files larger than this are uploaded in slices of this size, bypassing PHP's upload_max_filesize / post_max_size limits — this is what makes very large files possible. Set 0 to disable. Hard cap: 32 MB.";

$l['dragdrop_attach_postbit_title'] = "Professional post attachments design";
$l['dragdrop_attach_postbit_desc'] = "Restyles the attachments box shown under posts with a 2026 look: file cards with a colored extension chip, size and download glyph, plus a responsive thumbnail grid with smooth load-in effects (works for all viewers).";

$l['dragdrop_attach_dlwait_title'] = "Download gate (redirect page with countdown)";
$l['dragdrop_attach_dlwait_desc'] = "When a visitor clicks an attachment download link, a professional Aurora Glass waiting page appears with a circular countdown, then the download starts automatically. Applies to the postbit attachment cards and private-message file links.";

$l['dragdrop_attach_dlwait_time_title'] = "Waiting time (seconds)";
$l['dragdrop_attach_dlwait_time_desc'] = "How many seconds the countdown runs before the download starts automatically (1-60, default 5).";

$l['dragdrop_attach_dlwait_skip_title'] = "\"Download now\" button (skip waiting)";
$l['dragdrop_attach_dlwait_skip_desc'] = "Show a button that lets the visitor start the download immediately without waiting for the countdown.";

// ---------------------------------------------------------------------
// Admin CP control panel module (Tools & Maintenance → DragDrop Attachments)
// ---------------------------------------------------------------------

$l['dragdrop_acp_menu'] = "DragDrop Attachments";
$l['dragdrop_acp_permission'] = "Can manage the DragDrop Attachments panel";

$l['dragdrop_acp_tab_stats'] = "Statistics";
$l['dragdrop_acp_tab_stats_desc'] = "Storage usage, uploads per period, top users, file types and forums.";
$l['dragdrop_acp_tab_browse'] = "Attachments";
$l['dragdrop_acp_tab_browse_desc'] = "Search, inspect and delete attachments (posts, PMs, drafts and staged uploads).";
$l['dragdrop_acp_tab_quotas'] = "Group quotas";
$l['dragdrop_acp_tab_quotas_desc'] = "Per-usergroup storage quota overrides with a visual overview.";
$l['dragdrop_acp_tab_limits'] = "Size limits";
$l['dragdrop_acp_tab_limits_desc'] = "Accepted file types, maximum sizes per file/extension and chunked uploads for large files.";
$l['dragdrop_acp_tab_dlwait'] = "Download gate";
$l['dragdrop_acp_tab_dlwait_desc'] = "Professional redirect page with a countdown before attachment downloads, with a live preview.";
$l['dragdrop_acp_tab_logs'] = "Activity log";
$l['dragdrop_acp_tab_logs_desc'] = "Every upload attempt made through the drag &amp; drop zones.";
$l['dragdrop_acp_tab_tools'] = "Tools";
$l['dragdrop_acp_tab_tools_desc'] = "Orphaned file cleanup, PM mapping integrity, template repair and system checks.";

$l['dragdrop_acp_yes'] = "Yes";
$l['dragdrop_acp_no'] = "No";

// Statistics
$l['dragdrop_acp_stats_settings_link'] = "Open the DragDrop Attachments settings";
$l['dragdrop_acp_stats_overview'] = "Attachment overview";
$l['dragdrop_acp_stats_metric'] = "Metric";
$l['dragdrop_acp_stats_value'] = "Value";
$l['dragdrop_acp_stats_total'] = "Total attachments";
$l['dragdrop_acp_stats_size'] = "Storage used";
$l['dragdrop_acp_stats_today'] = "New today";
$l['dragdrop_acp_stats_week'] = "Last 7 days";
$l['dragdrop_acp_stats_month'] = "Last 30 days";
$l['dragdrop_acp_stats_unapproved'] = "Awaiting approval";
$l['dragdrop_acp_stats_pm'] = "PM attachments";
$l['dragdrop_acp_stats_drafts'] = "Draft attachments";
$l['dragdrop_acp_stats_staged'] = "Staged (unclaimed)";
$l['dragdrop_acp_stats_downloads'] = "Total downloads";
$l['dragdrop_acp_stats_topusers'] = "Top users by storage";
$l['dragdrop_acp_stats_topext'] = "Top file types";
$l['dragdrop_acp_stats_topforums'] = "Top forums";
$l['dragdrop_acp_stats_server'] = "System checks";

$l['dragdrop_acp_col_user'] = "User";
$l['dragdrop_acp_col_count'] = "Files";
$l['dragdrop_acp_col_size'] = "Size";
$l['dragdrop_acp_col_controls'] = "Actions";
$l['dragdrop_acp_col_ext'] = "Extension";
$l['dragdrop_acp_col_forum'] = "Forum";
$l['dragdrop_acp_col_file'] = "File";
$l['dragdrop_acp_col_posted'] = "Bound to";
$l['dragdrop_acp_col_downloads'] = "Downloads";
$l['dragdrop_acp_col_date'] = "Date";
$l['dragdrop_acp_col_ip'] = "IP address";
$l['dragdrop_acp_col_group'] = "Usergroup";
$l['dragdrop_acp_col_quota'] = "Quota (MB)";
$l['dragdrop_acp_col_effective'] = "Effective quota";

// Browser
$l['dragdrop_acp_browse_view'] = "View";
$l['dragdrop_acp_browse_filters'] = "Filters";
$l['dragdrop_acp_browse_keyword'] = "Filename contains";
$l['dragdrop_acp_browse_uid'] = "User ID";
$l['dragdrop_acp_browse_ext'] = "Extension";
$l['dragdrop_acp_browse_forum'] = "Forum";
$l['dragdrop_acp_browse_forum_all'] = "All forums";
$l['dragdrop_acp_browse_context'] = "Type";
$l['dragdrop_acp_browse_ctx_all'] = "All types";
$l['dragdrop_acp_browse_inpost'] = "Post";
$l['dragdrop_acp_browse_inpm'] = "Private message";
$l['dragdrop_acp_browse_indraft'] = "PM draft";
$l['dragdrop_acp_browse_instaged'] = "Staged upload";
$l['dragdrop_acp_browse_sort'] = "Sort by";
$l['dragdrop_acp_sort_date'] = "Newest first";
$l['dragdrop_acp_sort_size'] = "Largest first";
$l['dragdrop_acp_sort_downloads'] = "Most downloaded";
$l['dragdrop_acp_sort_name'] = "Filename (A-Z)";
$l['dragdrop_acp_browse_visible'] = "Visibility";
$l['dragdrop_acp_browse_vis_all'] = "All attachments";
$l['dragdrop_acp_browse_vis_waiting'] = "Awaiting approval only";
$l['dragdrop_acp_browse_apply'] = "Filter";
$l['dragdrop_acp_browse_results'] = "Attachments";
$l['dragdrop_acp_browse_none'] = "No matching attachments found.";
$l['dragdrop_acp_browse_unapproved'] = "Awaiting approval";

$l['dragdrop_acp_delete'] = "Delete";
$l['dragdrop_acp_delete_confirm'] = "Are you sure you want to permanently delete this attachment?";
$l['dragdrop_acp_delete_confirm_named'] = "Are you sure you want to permanently delete \"{1}\"? The file will be removed from the server as well.";
$l['dragdrop_acp_delete_success'] = "The attachment has been deleted.";
$l['dragdrop_acp_delete_missing'] = "The requested attachment could not be found.";

// Quotas
$l['dragdrop_acp_quotas_users'] = "Primary members";
$l['dragdrop_acp_quota_inherit'] = "inherits default";
$l['dragdrop_acp_quota_core'] = "MyBB core limit";
$l['dragdrop_acp_quotas_unlimited'] = "Unlimited";
$l['dragdrop_acp_quotas_note'] = "Leave the field empty (or 0) for a group to inherit the default quota. Quotas count post and private message attachments together for each member.";
$l['dragdrop_acp_quotas_save'] = "Save quotas";
$l['dragdrop_acp_quotas_saved'] = "The group quotas have been saved.";
$l['dragdrop_acp_quotas_default'] = "Current default quota: {1} MB per member (a group override always wins).";
$l['dragdrop_acp_quotas_default_none'] = "No default quota is set — groups without an override have unlimited storage (MyBB's per-group attachquota is used as a fallback when set).";

// Logs
$l['dragdrop_acp_logs_disabled'] = "Upload activity logging is currently disabled.";
$l['dragdrop_acp_logs_status'] = "Status";
$l['dragdrop_acp_logs_status_all'] = "All statuses";
$l['dragdrop_acp_log_ok'] = "OK";
$l['dragdrop_acp_log_denied'] = "Denied";
$l['dragdrop_acp_log_error'] = "Error";
$l['dragdrop_acp_logs_search'] = "Username or filename…";
$l['dragdrop_acp_logs_prune'] = "Prune older than {1} days";
$l['dragdrop_acp_logs_clear'] = "Clear all logs";
$l['dragdrop_acp_logs_clear_confirm'] = "Delete EVERY activity log entry? This cannot be undone.";
$l['dragdrop_acp_logs_pruned'] = "Activity logs older than {1} day(s) have been deleted.";
$l['dragdrop_acp_logs_cleared'] = "All activity logs have been deleted.";
$l['dragdrop_acp_logs_keep'] = "Log retention: entries older than {1} day(s) are pruned automatically.";
$l['dragdrop_acp_logs_none'] = "No matching log entries.";
$l['dragdrop_acp_logs_detail'] = "Details";

// Tools
$l['dragdrop_acp_tools_orphans_card'] = "Orphaned files";
$l['dragdrop_acp_tools_orphans_title'] = "Files in the uploads directory that are no longer referenced";
$l['dragdrop_acp_tools_orphans_desc'] = "Scans the uploads directory (including monthly sub-directories) for files that do not belong to any attachment row. Files younger than 3 days are skipped because they may still be claimed by an open form.";
$l['dragdrop_acp_tools_scan'] = "Scan now";
$l['dragdrop_acp_tools_orphans_found'] = "{1} orphaned file(s) found, totalling {2}.";
$l['dragdrop_acp_tools_orphans_none'] = "No orphaned files found — the uploads directory is clean.";
$l['dragdrop_acp_tools_delete_orphans'] = "Delete orphaned files ({1})";
$l['dragdrop_acp_orphans_deleted'] = "{1} orphaned file(s) deleted and {2} of disk space freed.";

$l['dragdrop_acp_tools_pm_card'] = "PM attachment mapping";
$l['dragdrop_acp_tools_pm_title'] = "Orphaned private message mapping rows";
$l['dragdrop_acp_tools_pm_desc'] = "Verifies that every row in the internal PM attachment mapping still points to an existing attachment and an existing private message, and removes the leftovers.";
$l['dragdrop_acp_tools_pm_issues'] = "{1} orphaned mapping row(s) found.";
$l['dragdrop_acp_tools_pm_ok'] = "The PM attachment mapping is clean.";
$l['dragdrop_acp_tools_pm_fix'] = "Remove orphaned rows ({1})";
$l['dragdrop_acp_pm_fixed'] = "{1} orphaned mapping row(s) removed.";

$l['dragdrop_acp_tools_tpl_card'] = "Plugin templates";
$l['dragdrop_acp_tools_tpl_title'] = "Template set status";
$l['dragdrop_acp_tools_tpl_desc'] = "The plugin ships 12 templates in the Global Templates set. Reinstalling restores the originals if any of them were deleted or broken while editing.";
$l['dragdrop_acp_tools_tpl_ok'] = "All {1} templates are present in the global template set.";
$l['dragdrop_acp_tools_tpl_missing'] = "Only {1} of {2} templates found — reinstall to restore the missing ones.";
$l['dragdrop_acp_tools_tpl_reinstall'] = "Reinstall templates";
$l['dragdrop_acp_tpl_reinstalled'] = "The plugin templates have been reinstalled.";

// Diagnostics
$l['dragdrop_acp_diag_check'] = "Check";
$l['dragdrop_acp_diag_value'] = "Value";
$l['dragdrop_acp_diag_version'] = "Plugin version";
$l['dragdrop_acp_diag_php'] = "PHP version";
$l['dragdrop_acp_diag_uploads_dir'] = "Uploads directory";
$l['dragdrop_acp_diag_missing'] = "missing";
$l['dragdrop_acp_diag_uploads_writable'] = "Uploads directory writable";
$l['dragdrop_acp_diag_monthly'] = "Current monthly directory";
$l['dragdrop_acp_diag_ready'] = "exists";
$l['dragdrop_acp_diag_will_create'] = "created on first upload";
$l['dragdrop_acp_diag_gd'] = "GD extension (thumbnails)";
$l['dragdrop_acp_diag_attachtypes'] = "Allowed attachment types";
$l['dragdrop_acp_diag_maxfiles'] = "Max files per message";
$l['dragdrop_acp_diag_core_limit'] = "core limit";
$l['dragdrop_acp_diag_logging'] = "Upload activity logging";
$l['dragdrop_acp_diag_php_limits'] = "PHP upload limits";
$l['dragdrop_acp_diag_alltypes'] = "Universal file type mode";
$l['dragdrop_acp_diag_chunking'] = "Chunked uploads above";
$l['dragdrop_acp_diag_disabled'] = "disabled";
$l['dragdrop_acp_diag_templates'] = "Plugin templates present";

// Size limits
$l['dragdrop_acp_limits_info'] = "Accept any file type, control the maximum size of attachments and enable sliced uploads for very large files. Settings entered here are the same as the plugin settings group — they apply everywhere the drop zone is used.";
$l['dragdrop_acp_limits_php'] = "Server limits reported by PHP: upload_max_filesize = {1} · post_max_size = {2}. Slices larger than these values are rejected by the web server before the plugin runs — keep the chunk threshold below them.";
$l['dragdrop_acp_limits_types'] = "Accepted file types";
$l['dragdrop_acp_limits_sizes'] = "Maximum file sizes";
$l['dragdrop_acp_limits_alltypes'] = "Universal file type mode";
$l['dragdrop_acp_limits_alltypes_desc'] = "When enabled, every extension is accepted even when it is not defined under Configuration → Attachment Types. Extensions in the block list below (and server-executable scripts) are always rejected.";
$l['dragdrop_acp_limits_denyext'] = "Blocked extensions";
$l['dragdrop_acp_limits_denyext_desc'] = "Comma separated extra extensions to reject, e.g. exe,msi,bat. The built-in server-executable list (php, phar, asp, cgi, …) cannot be removed.";
$l['dragdrop_acp_limits_maxsize'] = "Global maximum file size (MB)";
$l['dragdrop_acp_limits_maxsize_desc'] = "0 = follow MyBB's per-type limits. Any other value overrides them for every file type.";
$l['dragdrop_acp_limits_extsizes'] = "Per-extension size rules (MB)";
$l['dragdrop_acp_limits_extsizes_desc'] = "One rule per line: extension=MB, e.g. zip=500. Rules always win over the global maximum and the core attachment type limit.";
$l['dragdrop_acp_limits_chunk'] = "Chunked upload threshold (MB)";
$l['dragdrop_acp_limits_chunk_desc'] = "Files above this size are uploaded in slices of this size, bypassing the PHP limits shown above. 0 disables chunked uploads. Hard cap 32 MB.";
$l['dragdrop_acp_limits_save'] = "Save size limits";
$l['dragdrop_acp_limits_saved'] = "The size limits and file type policy have been saved.";
$l['dragdrop_acp_limits_rules'] = "Active per-extension rules";
$l['dragdrop_acp_limits_norules'] = "No per-extension rules defined — the global maximum (or MyBB's per-type limits) applies.";
$l['dragdrop_acp_limits_note'] = "Priority per file: extension rule → global maximum → core attachment type limit → unlimited. The storage quota (Group quotas tab) is independent of the size limits and still applies.";

// Download gate (v2.3.0)
$l['dragdrop_acp_dlwait_info'] = "The download gate shows your visitors an elegant Aurora Glass waiting page when they click an attachment download link: an extension-colored file icon, size and download count, a rotating circular countdown in seconds and a shimmering progress bar — then the download starts automatically when the count ends. The page is responsive, RTL-aware and honors the reduced-motion preference.";
$l['dragdrop_acp_dlwait_general'] = "Download gate settings";
$l['dragdrop_acp_dlwait_enable'] = "Enable the download gate";
$l['dragdrop_acp_dlwait_enable_desc'] = "Turn the pre-download waiting page on or off. When off, files open directly as in core MyBB.";
$l['dragdrop_acp_dlwait_time'] = "Countdown duration (seconds)";
$l['dragdrop_acp_dlwait_time_desc'] = "Between 1 and 60 seconds (default 5). The count shows inside the circular ring with a progress bar.";
$l['dragdrop_acp_dlwait_skip'] = "\"Download now\" button";
$l['dragdrop_acp_dlwait_skip_desc'] = "Show a skip button that starts the download immediately without waiting for the countdown.";
$l['dragdrop_acp_dlwait_save'] = "Save gate settings";
$l['dragdrop_acp_dlwait_saved'] = "The download gate settings have been saved.";
$l['dragdrop_acp_dlwait_preview'] = "Live preview of the page";
$l['dragdrop_acp_dlwait_scope'] = "Scope: download links are routed through the gate in the postbit attachment cards (after the redesign) and in private-message file links. Thumbnails, inline images and direct links are never affected so nothing breaks on forum pages.";

// License & protection (v2.4.0)
$l['dragdrop_acp_tab_license'] = "License & Protection";
$l['dragdrop_acp_tab_license_desc'] = "License status for this domain and entry of the key that unlocks the plugin features.";
$l['dragdrop_acp_lic_state_licensed'] = "Licensed";
$l['dragdrop_acp_lic_state_locked'] = "Unlicensed — features locked";
$l['dragdrop_acp_lic_state_dev'] = "Development domain";
$l['dragdrop_acp_lic_state_missing'] = "License module missing";
$l['dragdrop_acp_lic_licensed_domain'] = "The plugin is licensed for the domain: {1} — every feature runs without limits.";
$l['dragdrop_acp_lic_licensed_master'] = "The plugin is licensed with a master key valid on any domain — every feature runs without limits.";
$l['dragdrop_acp_lic_locked_detail'] = "There is no valid license key for this domain — the plugin features are locked. Get a key from the developer and paste it below (the forum itself keeps working normally).";
$l['dragdrop_acp_lic_dev_note'] = "The plugin is running on a development domain (localhost or a test host) — no license is required while developing or testing.";
$l['dragdrop_acp_lic_module_missing'] = "The license module file (inc/plugins/dragdrop_attach_license.php) is missing or corrupted — re-upload the complete plugin package to restore the features.";
$l['dragdrop_acp_lic_domain_label'] = "Detected forum domain:";
$l['dragdrop_acp_lic_domain_hint'] = "To obtain a valid license key send this domain (exactly as shown) to the developer. The key works on this domain only.";
$l['dragdrop_acp_lic_form'] = "License key";
$l['dragdrop_acp_lic_key'] = "License key";
$l['dragdrop_acp_lic_key_desc'] = "Format: DDA-XXXX-XXXX-XXXX-XXXX (dashes optional). Leave empty and save to clear the stored key.";
$l['dragdrop_acp_lic_save'] = "Save license";
$l['dragdrop_acp_lic_saved'] = "The license key was accepted — thank you for supporting the plugin!";
$l['dragdrop_acp_lic_cleared'] = "The stored license key has been cleared.";
$l['dragdrop_acp_lic_invalid'] = "This license key is not valid for this domain — paste it exactly as provided, or contact the developer with your detected domain above.";
$l['dragdrop_acp_lic_howto'] = "How protection works: the key is bound to your forum domain and does not work anywhere else. A copy installed without a valid key stays LOCKED from the first moment (no trial period) — the plugin features remain off while the forum itself keeps working normally. Development domains (localhost, 127.0.0.1, *.local, *.test) are always exempt.";

// License settings (also visible in the settings group)
$l['dragdrop_attach_license_title'] = "License key";
$l['dragdrop_attach_license_desc'] = "The key bound to your forum domain (DDA-XXXX-XXXX-XXXX-XXXX). The License tab of the plugin panel is the faster way to manage it.";

// Developer credit footer (shown at the bottom of every plugin panel page)
$l['dragdrop_acp_credit'] = "This plugin is developed by <a href=\"https://nulledpost.com\" target=\"_blank\" rel=\"noopener\">nulledpost.com</a> &mdash; for orders, support and contact on WhatsApp: <a href=\"https://wa.me/963934993506\" target=\"_blank\" rel=\"noopener\">+963 934 993 506</a>";
