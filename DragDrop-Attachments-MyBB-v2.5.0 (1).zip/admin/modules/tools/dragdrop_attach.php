<?php
/**
 * DragDrop Attachments — Admin CP control panel module
 *
 * المرفقات بالسحب والإفلات — لوحة تحكم الإدارة
 * Tools & Maintenance → DragDrop Attachments
 *
 * Pages: Statistics · Attachment browser · Group quotas · Activity logs · Tools
 *
 * Requires the DragDrop Attachments plugin to be active (shared helpers live
 * in inc/plugins/dragdrop_attach.php).
 */

// Disallow direct access to this file for security reasons
if(!defined("IN_ADMINCP"))
{
        die("Direct initialization of this file is not allowed.<br /><br />Please make sure IN_ADMINCP is defined.");
}

// The plugin must be active: shared helpers live in inc/plugins/dragdrop_attach.php
if(!function_exists("dragdrop_attach_info"))
{
        flash_message("DragDrop Attachments is not active — activate it from Configuration → Plugins first. (الإضافة غير مفعّلة، فعّلها من الإعدادات ← الإضافات أولاً)", "error");
        admin_redirect("index.php?module=plugins");
}

$lang->load("dragdrop_attach", false, true);

$page->add_breadcrumb_item($lang->dragdrop_acp_menu, "index.php?module=tools-dragdrop_attach");

$plugins->run_hooks("admin_tools_dragdrop_attach_begin");

$base_url = "index.php?module=tools-dragdrop_attach";
$attachtypes = (array)$cache->read("attachtypes");

$sub_tabs = array(
        "stats" => array(
                "title" => $lang->dragdrop_acp_tab_stats,
                "link" => $base_url,
                "description" => $lang->dragdrop_acp_tab_stats_desc
        ),
        "browse" => array(
                "title" => $lang->dragdrop_acp_tab_browse,
                "link" => $base_url."&amp;action=browse",
                "description" => $lang->dragdrop_acp_tab_browse_desc
        ),
        "quotas" => array(
                "title" => $lang->dragdrop_acp_tab_quotas,
                "link" => $base_url."&amp;action=quotas",
                "description" => $lang->dragdrop_acp_tab_quotas_desc
        ),
        "limits" => array(
                "title" => $lang->dragdrop_acp_tab_limits,
                "link" => $base_url."&amp;action=limits",
                "description" => $lang->dragdrop_acp_tab_limits_desc
        ),
        "dlwait" => array(
                "title" => $lang->dragdrop_acp_tab_dlwait,
                "link" => $base_url."&amp;action=dlwait",
                "description" => $lang->dragdrop_acp_tab_dlwait_desc
        ),
        "logs" => array(
                "title" => $lang->dragdrop_acp_tab_logs,
                "link" => $base_url."&amp;action=logs",
                "description" => $lang->dragdrop_acp_tab_logs_desc
        ),
        "tools" => array(
                "title" => $lang->dragdrop_acp_tab_tools,
                "link" => $base_url."&amp;action=tools",
                "description" => $lang->dragdrop_acp_tab_tools_desc
        ),
        "license" => array(
                "title" => $lang->dragdrop_acp_tab_license,
                "link" => $base_url."&amp;action=license",
                "description" => $lang->dragdrop_acp_tab_license_desc
        ),
);

/* --------------------------------------------------------------------- */
/* Local helpers                                                          */
/* --------------------------------------------------------------------- */

/**
 * Developer credit footer — echoed at the bottom of every module page.
 * نص التطوير والدعم (nulledpost.com + واتساب) أسفل كل صفحات لوحة الإضافة.
 */
function dragdrop_attach_acp_credit()
{
        global $lang;

        if(!isset($lang->dragdrop_acp_credit) || (string)$lang->dragdrop_acp_credit === '')
        {
                return;
        }

        echo '<div style="clear: both; text-align: center; margin: 18px 0 6px; padding: 10px 14px; background: #f7f9fc; border: 1px solid #dfe6ef; border-radius: 6px; color: #5b6a7f; font-size: 12px; line-height: 2;">'.$lang->dragdrop_acp_credit.'</div>';
}

/**
 * Colored status badge for log rows.
 */
function dragdrop_attach_acp_badge($status)
{
        global $lang;

        $titles = array(
                "ok" => $lang->dragdrop_acp_log_ok,
                "denied" => $lang->dragdrop_acp_log_denied,
                "error" => $lang->dragdrop_acp_log_error
        );

        $title = isset($titles[$status]) ? $titles[$status] : htmlspecialchars_uni($status);

        return '<span class="dda-badge dda-badge-'.htmlspecialchars_uni($status).'">'.htmlspecialchars_uni($title).'</span>';
}

/**
 * Label + optional front-end link describing what an attachment is bound to.
 *
 * @return array(label, url-or-empty)
 */
function dragdrop_attach_acp_context_label($pid, $draft, $pmid)
{
        global $lang;

        if($pid > 0)
        {
                return array($lang->dragdrop_acp_browse_inpost, "");
        }

        if($pmid > 0)
        {
                return $draft
                        ? array($lang->dragdrop_acp_browse_indraft, "")
                        : array($lang->dragdrop_acp_browse_inpm, "../private.php?action=read&amp;pmid=".$pmid);
        }

        return array($lang->dragdrop_acp_browse_instaged, "");
}

/**
 * Run the read-only system checks shown on the stats and tools pages.
 *
 * @return array each item: label, value, ok (bool), info (bool = neutral)
 */
function dragdrop_attach_acp_diagnostics()
{
        global $mybb, $db, $lang, $cache;

        $uploadspath = !empty($mybb->settings['uploadspath']) ? $mybb->settings['uploadspath'] : './uploads';
        $abs = mk_path_abs($uploadspath);
        $month = gmdate("Ym");
        $gd = function_exists("imagecreatetruecolor");
        $types = count((array)$cache->read("attachtypes"));

        $titles = array();
        foreach(dragdrop_attach_default_templates() as $title => $body)
        {
                $titles[] = $db->escape_string($title);
        }
        $found_templates = 0;
        if(!empty($titles))
        {
                $query = $db->simple_select("templates", "COUNT(tid) AS cnt", "sid = '-2' AND title IN ('".implode("','", $titles)."')");
                $found_templates = (int)$db->fetch_field($query, "cnt");
        }

        $checks = array();

        $checks[] = array(
                "label" => $lang->dragdrop_acp_diag_version,
                "value" => DRAGDROP_ATTACH_VERSION,
                "ok" => true, "info" => true
        );

        $checks[] = array(
                "label" => $lang->dragdrop_acp_diag_php,
                "value" => PHP_VERSION,
                "ok" => true, "info" => true
        );

        $checks[] = array(
                "label" => $lang->dragdrop_acp_diag_uploads_dir,
                "value" => htmlspecialchars_uni($uploadspath).(is_dir($abs) ? "" : " (".$lang->dragdrop_acp_diag_missing.")"),
                "ok" => is_dir($abs)
        );

        $checks[] = array(
                "label" => $lang->dragdrop_acp_diag_uploads_writable,
                "value" => is_dir($abs) && is_writable($abs) ? $lang->dragdrop_acp_yes : $lang->dragdrop_acp_no,
                "ok" => is_dir($abs) && is_writable($abs)
        );

        $checks[] = array(
                "label" => $lang->dragdrop_acp_diag_monthly,
                "value" => $month.": ".(is_dir($abs."/".$month) ? $lang->dragdrop_acp_diag_ready : $lang->dragdrop_acp_diag_will_create),
                "ok" => true,
                "info" => !is_dir($abs."/".$month)
        );

        $checks[] = array(
                "label" => $lang->dragdrop_acp_diag_gd,
                "value" => $gd ? $lang->dragdrop_acp_yes : $lang->dragdrop_acp_no,
                "ok" => $gd,
                "info" => !$gd
        );

        $checks[] = array(
                "label" => $lang->dragdrop_acp_diag_attachtypes,
                "value" => $types,
                "ok" => $types > 0
        );

        $maxfiles = (int)$mybb->settings['dragdrop_attach_maxfiles'];

        $checks[] = array(
                "label" => $lang->dragdrop_acp_diag_maxfiles,
                "value" => $maxfiles > 0 ? $maxfiles : $lang->dragdrop_acp_diag_core_limit,
                "ok" => true, "info" => true
        );

        $checks[] = array(
                "label" => $lang->dragdrop_acp_diag_logging,
                "value" => dragdrop_attach_logging_enabled() ? $lang->dragdrop_acp_yes : $lang->dragdrop_acp_no,
                "ok" => true, "info" => true
        );

        $upl = ini_get("upload_max_filesize");
        $post = ini_get("post_max_size");

        $checks[] = array(
                "label" => $lang->dragdrop_acp_diag_php_limits,
                "value" => "upload_max_filesize=".($upl !== false && $upl !== "" ? $upl : "?")." &middot; post_max_size=".($post !== false && $post !== "" ? $post : "?"),
                "ok" => true, "info" => true
        );

        $all_types = dragdrop_attach_all_types();

        $checks[] = array(
                "label" => $lang->dragdrop_acp_diag_alltypes,
                "value" => $all_types ? $lang->dragdrop_acp_yes : $lang->dragdrop_acp_no,
                "ok" => true, "info" => true
        );

        $chunk_bytes = dragdrop_attach_chunk_bytes();

        $checks[] = array(
                "label" => $lang->dragdrop_acp_diag_chunking,
                "value" => $chunk_bytes > 0 ? get_friendly_size($chunk_bytes) : $lang->dragdrop_acp_diag_disabled,
                "ok" => true, "info" => true
        );

        $checks[] = array(
                "label" => $lang->dragdrop_acp_diag_templates,
                "value" => $found_templates." / ".count($titles),
                "ok" => $found_templates >= count($titles) && count($titles) > 0
        );

        return $checks;
}

/**
 * Render the diagnostics table.
 */
function dragdrop_attach_acp_render_diagnostics()
{
        global $lang;

        $table = new Table;

        $table->construct_header($lang->dragdrop_acp_diag_check);
        $table->construct_header($lang->dragdrop_acp_diag_value, array("class" => "align_center"));

        foreach(dragdrop_attach_acp_diagnostics() as $check)
        {
                $mark = "&#10003;"; // check mark
                $color = "#5da05f";

                if(empty($check['info']) && empty($check['ok']))
                {
                        $mark = "&#10007;"; // cross
                        $color = "#d9534f";
                }
                elseif(!empty($check['info']))
                {
                        $mark = "&#8226;"; // neutral dot
                        $color = "#888888";
                }

                $table->construct_cell('<span style="color:'.$color.';font-weight:bold;">'.$mark.'</span> '.$check['label']);
                $table->construct_cell($check['value'], array("class" => "align_center"));
                $table->construct_row();
        }

        $table->output($lang->dragdrop_acp_stats_server);
}

/**
 * Scan the uploads directory (root + one level of YYYYMM sub-directories)
 * for files that are not referenced by any attachment row and are older
 * than the cutoff. Read-only.
 *
 * @param int $cutoff unix timestamp
 * @return array of rel, abs, size, mtime
 */
function dragdrop_attach_acp_scan_orphans($cutoff)
{
        global $mybb, $db;

        $uploadspath = !empty($mybb->settings['uploadspath']) ? $mybb->settings['uploadspath'] : './uploads';
        $abs = mk_path_abs($uploadspath);

        $results = array();

        if(!is_dir($abs))
        {
                return $results;
        }

        $dirs = array($abs);

        if(($dh = @opendir($abs)) !== false)
        {
                while(($entry = readdir($dh)) !== false)
                {
                        if($entry === "." || $entry === "..")
                        {
                                continue;
                        }

                        $path = $abs."/".$entry;

                        if(is_dir($path) && preg_match("#^[0-9]{6}$#", $entry))
                        {
                                $dirs[] = $path;
                        }
                }
                closedir($dh);
        }

        foreach($dirs as $dir)
        {
                if(($dh = @opendir($dir)) === false)
                {
                        continue;
                }

                while(($file = readdir($dh)) !== false)
                {
                        if($file === "." || $file === ".." || $file === "index.html" || $file === ".htaccess")
                        {
                                continue;
                        }

                        $path = $dir."/".$file;

                        if(!is_file($path))
                        {
                                continue;
                        }

                        $rel = ($dir === $abs) ? $file : basename($dir)."/".$file;
                        $mtime = @filemtime($path);

                        if($mtime === false || $mtime > $cutoff)
                        {
                                continue; // recent files may still be claimed by an open form
                        }

                        // Referenced as the main file or as a thumbnail?
                        $refs = (int)$db->fetch_field(
                                $db->simple_select("attachments", "COUNT(aid) AS refs", "attachname = '".$db->escape_string($rel)."'"),
                                "refs"
                        );

                        if($refs == 0)
                        {
                                $refs = (int)$db->fetch_field(
                                        $db->simple_select("attachments", "COUNT(aid) AS refs", "thumbnail = '".$db->escape_string($rel)."'"),
                                        "refs"
                                );
                        }

                        if($refs > 0)
                        {
                                continue;
                        }

                        $results[] = array(
                                "rel" => $rel,
                                "abs" => $path,
                                "size" => (int)@filesize($path),
                                "mtime" => $mtime
                        );
                }
                closedir($dh);
        }

        return $results;
}

/* --------------------------------------------------------------------- */
/* Delete a single attachment (confirm page + POST execution)             */
/* --------------------------------------------------------------------- */

if($mybb->get_input('action') == "delete")
{
        $aid = (int)$mybb->get_input('aid');

        $query = $db->simple_select("attachments", "aid, pid, posthash, filename", "aid = '".$aid."'");
        $attachment = $db->fetch_array($query);

        if(!$attachment)
        {
                flash_message($lang->dragdrop_acp_delete_missing, "error");
                admin_redirect($base_url."&action=browse");
        }

        if($mybb->request_method == "post")
        {
                verify_post_check($mybb->get_input('my_post_key'));

                require_once MYBB_ROOT."inc/functions_upload.php";

                // Drop plugin-owned PM mapping rows first
                $db->delete_query("dragdrop_pm", "aid = '".$aid."'");

                if($attachment['pid'])
                {
                        remove_attachment((int)$attachment['pid'], null, $aid);
                }
                else
                {
                        remove_attachment(null, $attachment['posthash'], $aid);
                }

                log_admin_action($aid, $attachment['filename']);

                flash_message($lang->dragdrop_acp_delete_success, "success");
                admin_redirect($base_url."&action=browse");
        }

        $page->output_confirm_action(
                $base_url."&amp;action=delete&amp;aid=".$aid,
                $lang->sprintf($lang->dragdrop_acp_delete_confirm_named, htmlspecialchars_uni($attachment['filename']))
        );
}

/* --------------------------------------------------------------------- */
/* Page 1: Statistics (default)                                           */
/* --------------------------------------------------------------------- */

if(!$mybb->get_input('action'))
{
        $page->output_header($lang->dragdrop_acp_menu);
        $page->output_nav_tabs($sub_tabs, 'stats');

        // --------------------------------------------------------------
        // Overview counters
        // --------------------------------------------------------------
        $query = $db->simple_select("attachments", "COUNT(aid) AS total, COALESCE(SUM(filesize), 0) AS size, COALESCE(SUM(downloads), 0) AS downloads", "");
        $totals = $db->fetch_array($query);

        $today_cut = TIME_NOW - 86400;
        $week_cut = TIME_NOW - (7 * 86400);
        $month_cut = TIME_NOW - (30 * 86400);

        $new_today = (int)$db->fetch_field(
                $db->simple_select("attachments", "COUNT(aid) AS cnt", "dateuploaded > '".$today_cut."'"),
                "cnt"
        );
        $new_week = (int)$db->fetch_field(
                $db->simple_select("attachments", "COUNT(aid) AS cnt", "dateuploaded > '".$week_cut."'"),
                "cnt"
        );
        $new_month = (int)$db->fetch_field(
                $db->simple_select("attachments", "COUNT(aid) AS cnt", "dateuploaded > '".$month_cut."'"),
                "cnt"
        );
        $unapproved = (int)$db->fetch_field(
                $db->simple_select("attachments", "COUNT(aid) AS cnt", "visible = '0'"),
                "cnt"
        );
        $staged = (int)$db->fetch_field(
                $db->simple_select("attachments", "COUNT(aid) AS cnt", "pid = 0 AND posthash != ''"),
                "cnt"
        );

        $pm_rows = $db->query("
                SELECT COUNT(DISTINCT m.aid) AS cnt, COALESCE(SUM(a.filesize), 0) AS size
                FROM ".TABLE_PREFIX."dragdrop_pm m
                LEFT JOIN ".TABLE_PREFIX."attachments a ON (a.aid = m.aid)
                WHERE m.is_draft = 0
        ");
        $pm = $db->fetch_array($pm_rows);

        $draft_rows = $db->query("
                SELECT COUNT(DISTINCT m.aid) AS cnt
                FROM ".TABLE_PREFIX."dragdrop_pm m
                WHERE m.is_draft = 1
        ");
        $drafts = (int)$db->fetch_field($draft_rows, "cnt");

        // Quick link to the plugin settings group
        $dd_gid = (int)$db->fetch_field(
                $db->simple_select("settinggroups", "gid", "name = 'dragdrop_attach'"),
                "gid"
        );

        if($dd_gid > 0)
        {
                $page->output_alert(
                        '<a href="index.php?module=config-settings&amp;action=change&amp;gid='.$dd_gid.'">'.$lang->dragdrop_acp_stats_settings_link.'</a>'
                );
        }

        $table = new Table;

        $table->construct_header($lang->dragdrop_acp_stats_metric);
        $table->construct_header($lang->dragdrop_acp_stats_value);
        $table->construct_header($lang->dragdrop_acp_stats_metric);
        $table->construct_header($lang->dragdrop_acp_stats_value);

        $table->construct_cell("<strong>".$lang->dragdrop_acp_stats_total."</strong>");
        $table->construct_cell(my_number_format((int)$totals['total']));
        $table->construct_cell("<strong>".$lang->dragdrop_acp_stats_size."</strong>");
        $table->construct_cell(get_friendly_size((int)$totals['size']));
        $table->construct_row();

        $table->construct_cell("<strong>".$lang->dragdrop_acp_stats_today."</strong>");
        $table->construct_cell(my_number_format($new_today));
        $table->construct_cell("<strong>".$lang->dragdrop_acp_stats_week."</strong>");
        $table->construct_cell(my_number_format($new_week));
        $table->construct_row();

        $table->construct_cell("<strong>".$lang->dragdrop_acp_stats_month."</strong>");
        $table->construct_cell(my_number_format($new_month));
        $table->construct_cell("<strong>".$lang->dragdrop_acp_stats_unapproved."</strong>");
        $table->construct_cell('<a href="'.$base_url.'&amp;action=browse&amp;visible=0">'.my_number_format($unapproved).'</a>');
        $table->construct_row();

        $table->construct_cell("<strong>".$lang->dragdrop_acp_stats_pm."</strong>");
        $table->construct_cell(my_number_format((int)$pm['cnt'])." (".get_friendly_size((int)$pm['size']).")");
        $table->construct_cell("<strong>".$lang->dragdrop_acp_stats_drafts."</strong>");
        $table->construct_cell(my_number_format($drafts));
        $table->construct_row();

        $table->construct_cell("<strong>".$lang->dragdrop_acp_stats_staged."</strong>");
        $table->construct_cell(my_number_format($staged));
        $table->construct_cell("<strong>".$lang->dragdrop_acp_stats_downloads."</strong>");
        $table->construct_cell(my_number_format((int)$totals['downloads']));
        $table->construct_row();

        $table->output($lang->dragdrop_acp_stats_overview);

        // --------------------------------------------------------------
        // Top users by storage
        // --------------------------------------------------------------
        $user_rows = $db->query("
                SELECT a.uid, MIN(u.username) AS username, COUNT(a.aid) AS cnt, SUM(a.filesize) AS size
                FROM ".TABLE_PREFIX."attachments a
                LEFT JOIN ".TABLE_PREFIX."users u ON (u.uid = a.uid)
                GROUP BY a.uid
                ORDER BY size DESC
                LIMIT 10
        ");

        if($db->num_rows($user_rows) > 0)
        {
                $table = new Table;

                $table->construct_header($lang->dragdrop_acp_col_user);
                $table->construct_header($lang->dragdrop_acp_col_count, array("class" => "align_center"));
                $table->construct_header($lang->dragdrop_acp_col_size, array("class" => "align_center"));
                $table->construct_header($lang->dragdrop_acp_col_controls, array("class" => "align_center"));

                while($row = $db->fetch_array($user_rows))
                {
                        $username = ($row['username'] !== null && $row['username'] !== "") ? $row['username'] : "UID ".$row['uid'];

                        $table->construct_cell(htmlspecialchars_uni($username));
                        $table->construct_cell(my_number_format((int)$row['cnt']), array("class" => "align_center"));
                        $table->construct_cell(get_friendly_size((int)$row['size']), array("class" => "align_center"));
                        $table->construct_cell('<a href="'.$base_url.'&amp;action=browse&amp;uid='.(int)$row['uid'].'">'.$lang->dragdrop_acp_browse_view.'</a>', array("class" => "align_center"));
                        $table->construct_row();
                }

                $table->output($lang->dragdrop_acp_stats_topusers);
        }

        // --------------------------------------------------------------
        // Top file types
        // --------------------------------------------------------------
        $ext_rows = $db->query("
                SELECT LOWER(SUBSTRING_INDEX(a.filename, '.', -1)) AS ext, COUNT(a.aid) AS cnt, SUM(a.filesize) AS size
                FROM ".TABLE_PREFIX."attachments a
                GROUP BY LOWER(SUBSTRING_INDEX(a.filename, '.', -1))
                ORDER BY cnt DESC
                LIMIT 8
        ");

        if($db->num_rows($ext_rows) > 0)
        {
                $table = new Table;

                $table->construct_header($lang->dragdrop_acp_col_ext);
                $table->construct_header($lang->dragdrop_acp_col_count, array("class" => "align_center"));
                $table->construct_header($lang->dragdrop_acp_col_size, array("class" => "align_center"));
                $table->construct_header($lang->dragdrop_acp_col_controls, array("class" => "align_center"));

                while($row = $db->fetch_array($ext_rows))
                {
                        $table->construct_cell('<span class="ddattach-ext" style="direction:ltr;">'.htmlspecialchars_uni((string)$row['ext']).'</span>');
                        $table->construct_cell(my_number_format((int)$row['cnt']), array("class" => "align_center"));
                        $table->construct_cell(get_friendly_size((int)$row['size']), array("class" => "align_center"));
                        $table->construct_cell('<a href="'.$base_url.'&amp;action=browse&amp;ext='.urlencode((string)$row['ext']).'">'.$lang->dragdrop_acp_browse_view.'</a>', array("class" => "align_center"));
                        $table->construct_row();
                }

                $table->output($lang->dragdrop_acp_stats_topext);
        }

        // --------------------------------------------------------------
        // Top forums
        // --------------------------------------------------------------
        $forum_rows = $db->query("
                SELECT t.fid, MIN(f.name) AS name, COUNT(a.aid) AS cnt, SUM(a.filesize) AS size
                FROM ".TABLE_PREFIX."attachments a
                INNER JOIN ".TABLE_PREFIX."posts p ON (p.pid = a.pid)
                INNER JOIN ".TABLE_PREFIX."threads t ON (t.tid = p.tid)
                LEFT JOIN ".TABLE_PREFIX."forums f ON (f.fid = t.fid)
                GROUP BY t.fid
                ORDER BY size DESC
                LIMIT 10
        ");

        if($db->num_rows($forum_rows) > 0)
        {
                $table = new Table;

                $table->construct_header($lang->dragdrop_acp_col_forum);
                $table->construct_header($lang->dragdrop_acp_col_count, array("class" => "align_center"));
                $table->construct_header($lang->dragdrop_acp_col_size, array("class" => "align_center"));

                while($row = $db->fetch_array($forum_rows))
                {
                        $name = ($row['name'] !== null && $row['name'] !== "") ? $row['name'] : "FID ".$row['fid'];

                        $table->construct_cell('<a href="index.php?module=forum-management&amp;action=edit&amp;fid='.(int)$row['fid'].'">'.htmlspecialchars_uni($name).'</a>');
                        $table->construct_cell(my_number_format((int)$row['cnt']), array("class" => "align_center"));
                        $table->construct_cell(get_friendly_size((int)$row['size']), array("class" => "align_center"));
                        $table->construct_row();
                }

                $table->output($lang->dragdrop_acp_stats_topforums);
        }

        // --------------------------------------------------------------
        // System checks
        // --------------------------------------------------------------
        dragdrop_attach_acp_render_diagnostics();

        dragdrop_attach_acp_credit();
        $page->output_footer();
}
/* --------------------------------------------------------------------- */
/* Page 2: Attachment browser                                             */
/* --------------------------------------------------------------------- */

if($mybb->get_input('action') == "browse")
{
        $page->output_header($lang->dragdrop_acp_menu);
        $page->output_nav_tabs($sub_tabs, 'browse');

        // --------------------------------------------------------------
        // Filters
        // --------------------------------------------------------------
        $where = "1=1";

        $q = trim((string)$mybb->get_input('q'));
        if($q !== "")
        {
                $where .= " AND a.filename LIKE '%".$db->escape_string_like($q)."%'";
        }

        $f_uid = (int)$mybb->get_input('uid');
        if($f_uid > 0)
        {
                $where .= " AND a.uid = '".$f_uid."'";
        }

        $f_ext = my_strtolower(trim((string)$mybb->get_input('ext')));
        if($f_ext !== "")
        {
                $where .= " AND a.filename LIKE '%.".$db->escape_string_like($f_ext)."'";
        }

        $f_fid = (int)$mybb->get_input('fid');
        if($f_fid > 0)
        {
                $where .= " AND t.fid = '".$f_fid."'";
        }

        $f_ctx = (string)$mybb->get_input('ctx');
        switch($f_ctx)
        {
                case "post":
                        $where .= " AND a.pid > 0";
                        break;
                case "pm":
                        $where .= " AND a.pid = 0 AND m.pmaid IS NOT NULL AND m.is_draft = 0";
                        break;
                case "draft":
                        $where .= " AND a.pid = 0 AND m.is_draft = 1";
                        break;
                case "staged":
                        $where .= " AND a.pid = 0 AND m.pmaid IS NULL AND a.posthash != ''";
                        break;
        }

        if($mybb->get_input('visible') === "0")
        {
                $where .= " AND a.visible = '0'";
        }

        $sorts = array(
                "date" => "a.dateuploaded DESC",
                "size" => "a.filesize DESC",
                "downloads" => "a.downloads DESC",
                "name" => "a.filename ASC"
        );
        $f_sort = (string)$mybb->get_input('sort');
        $order = isset($sorts[$f_sort]) ? $sorts[$f_sort] : "a.dateuploaded DESC";

        $joins = "
                LEFT JOIN ".TABLE_PREFIX."posts p ON (p.pid = a.pid)
                LEFT JOIN ".TABLE_PREFIX."threads t ON (t.tid = p.tid)
                LEFT JOIN ".TABLE_PREFIX."dragdrop_pm m ON (m.aid = a.aid)";

        // --------------------------------------------------------------
        // Filter form (GET)
        // --------------------------------------------------------------
        echo '<form action="index.php" method="get">';
        echo '<input type="hidden" name="module" value="tools-dragdrop_attach" />';
        echo '<input type="hidden" name="action" value="browse" />';

        // "return" form: no <form> tag is printed, the inputs are used standalone
        $form = new Form("", "get", "", 0, "", true);

        $table = new Table;

        $table->construct_header($lang->dragdrop_acp_browse_keyword);
        $table->construct_header($lang->dragdrop_acp_browse_uid);
        $table->construct_header($lang->dragdrop_acp_browse_ext);
        $table->construct_header($lang->dragdrop_acp_browse_forum);

        $table->construct_cell($form->generate_text_box('q', htmlspecialchars_uni($q), array('style' => 'width: 95%;')));
        $table->construct_cell($form->generate_text_box('uid', $f_uid > 0 ? $f_uid : '', array('style' => 'width: 90%;')));
        $table->construct_cell($form->generate_text_box('ext', htmlspecialchars_uni($f_ext), array('style' => 'width: 90%; direction: ltr;')));

        $forums = array();
        $forum_cache = (array)$cache->read("forums");
        foreach($forum_cache as $forum)
        {
                if(!empty($forum['fid']) && isset($forum['type']) && $forum['type'] == "f")
                {
                        $forums[(int)$forum['fid']] = htmlspecialchars_uni($forum['name']);
                }
        }

        $table->construct_cell($form->generate_select_box('fid', array('0' => $lang->dragdrop_acp_browse_forum_all) + $forums, $f_fid));
        $table->construct_row();

        $table->construct_header($lang->dragdrop_acp_browse_context);
        $table->construct_header($lang->dragdrop_acp_browse_sort);
        $table->construct_header($lang->dragdrop_acp_browse_visible);
        $table->construct_header($lang->dragdrop_acp_col_controls);

        $ctx_options = array(
                "" => $lang->dragdrop_acp_browse_ctx_all,
                "post" => $lang->dragdrop_acp_browse_inpost,
                "pm" => $lang->dragdrop_acp_browse_inpm,
                "draft" => $lang->dragdrop_acp_browse_indraft,
                "staged" => $lang->dragdrop_acp_browse_instaged
        );

        $sort_options = array(
                "date" => $lang->dragdrop_acp_sort_date,
                "size" => $lang->dragdrop_acp_sort_size,
                "downloads" => $lang->dragdrop_acp_sort_downloads,
                "name" => $lang->dragdrop_acp_sort_name
        );

        $visible_options = array(
                "" => $lang->dragdrop_acp_browse_vis_all,
                "0" => $lang->dragdrop_acp_browse_vis_waiting
        );

        $table->construct_cell($form->generate_select_box('ctx', $ctx_options, $f_ctx));
        $table->construct_cell($form->generate_select_box('sort', $sort_options, $f_sort));
        $table->construct_cell($form->generate_select_box('visible', $visible_options, (string)$mybb->get_input('visible')));
        $table->construct_cell($form->generate_submit_button($lang->dragdrop_acp_browse_apply));
        $table->construct_row();

        $table->output($lang->dragdrop_acp_browse_filters);

        echo '</form>';

        // --------------------------------------------------------------
        // Results
        // --------------------------------------------------------------
        $total = (int)$db->fetch_field(
                $db->query("SELECT COUNT(DISTINCT a.aid) AS total FROM ".TABLE_PREFIX."attachments a{$joins} WHERE {$where}"),
                "total"
        );

        $perpage = 25;
        $pages = $perpage > 0 ? (int)ceil($total / $perpage) : 1;
        $current_page = (int)$mybb->get_input('page', MyBB::INPUT_INT);

        if($current_page < 1)
        {
                $current_page = 1;
        }
        if($current_page > $pages)
        {
                $current_page = $pages;
        }
        $start = ($current_page - 1) * $perpage;

        $query = $db->query("
                SELECT a.*, MIN(p.fid) AS post_fid, MIN(p.tid) AS post_tid, MIN(t.subject) AS subject, MIN(m.pmid) AS pmid, MIN(m.is_draft) AS is_draft
                FROM ".TABLE_PREFIX."attachments a{$joins}
                WHERE {$where}
                GROUP BY a.aid
                ORDER BY {$order}
                LIMIT {$start}, {$perpage}
        ");

        if($total > 0)
        {
                echo draw_admin_pagination($current_page, $perpage, $total, $base_url."&amp;action=browse&amp;q=".urlencode($q)."&amp;uid=".$f_uid."&amp;ext=".urlencode($f_ext)."&amp;fid=".$f_fid."&amp;ctx=".urlencode($f_ctx)."&amp;sort=".urlencode($f_sort)."&amp;visible=".urlencode((string)$mybb->get_input('visible')));
        }

        $table = new Table;

        $table->construct_header($lang->dragdrop_acp_col_file);
        $table->construct_header($lang->dragdrop_acp_col_user);
        $table->construct_header($lang->dragdrop_acp_col_posted);
        $table->construct_header($lang->dragdrop_acp_col_size, array("class" => "align_center"));
        $table->construct_header($lang->dragdrop_acp_col_downloads, array("class" => "align_center"));
        $table->construct_header($lang->dragdrop_acp_col_date);
        $table->construct_header($lang->dragdrop_acp_col_controls, array("class" => "align_center"));

        $count = 0;

        while($att = $db->fetch_array($query))
        {
                ++$count;
                $aid = (int)$att['aid'];
                $ext = my_strtolower(get_extension($att['filename']));

                // File cell: mini thumbnail / extension icon + name
                $thumb = '<span class="ddattach-ext" style="direction:ltr;">'.htmlspecialchars_uni(my_strtoupper($ext)).'</span>';

                if(in_array($ext, array("gif", "png", "jpg", "jpeg", "jpe", "bmp", "webp")))
                {
                        if(!empty($att['thumbnail']) && $att['thumbnail'] !== "SMALL")
                        {
                                $thumb = '<img class="ddattach-mini" src="../attachment.php?thumbnail='.$aid.'" alt="" />';
                        }
                        else
                        {
                                $thumb = '<img class="ddattach-mini" src="../attachment.php?aid='.$aid.'" alt="" />';
                        }
                }

                $cell = '<div style="display:flex;align-items:center;gap:6px;">'.$thumb.
                        '<span style="direction:ltr;"><a href="../attachment.php?aid='.$aid.'" target="_blank">'.htmlspecialchars_uni($att['filename']).'</a></span></div>';

                if($att['visible'] == 0)
                {
                        $cell .= '<br /><span style="color:#d9534f;font-size:11px;">'.$lang->dragdrop_acp_browse_unapproved.'</span>';
                }

                $table->construct_cell($cell);

                // User
                $table->construct_cell('<a href="index.php?module=user-users&amp;action=edit&amp;uid='.(int)$att['uid'].'">'.htmlspecialchars_uni('#'.(int)$att['uid']).'</a>');

                // Bound to (post / PM / draft / staged)
                list($ctx_label, $ctx_url) = dragdrop_attach_acp_context_label((int)$att['pid'], (int)$att['is_draft'], (int)$att['pmid']);

                $bound = htmlspecialchars_uni($ctx_label);

                if($ctx_url !== "")
                {
                        $bound = '<a href="'.$ctx_url.'">'.$bound.'</a>';
                }
                elseif($att['post_tid'] > 0)
                {
                        $subject = ($att['subject'] !== null && $att['subject'] !== "") ? $att['subject'] : "";
                        $bound = '<a href="../showthread.php?tid='.(int)$att['post_tid'].'&amp;pid='.$aid.'#pid'.$aid.'">'.$bound.'</a>'.
                                ($subject !== "" ? '<br /><span class="smalltext">'.htmlspecialchars_uni(my_substr($subject, 0, 40)).'</span>' : '');
                }

                $table->construct_cell($bound);
                $table->construct_cell(get_friendly_size((int)$att['filesize']), array("class" => "align_center"));
                $table->construct_cell(my_number_format((int)$att['downloads']), array("class" => "align_center"));
                $table->construct_cell(my_date("relative", (int)$att['dateuploaded']));
                $table->construct_cell('<a href="'.$base_url.'&amp;action=delete&amp;aid='.$aid.'">'.$lang->dragdrop_acp_delete.'</a>', array("class" => "align_center"));

                $table->construct_row();
        }

        if($count === 0)
        {
                $table->construct_cell($lang->dragdrop_acp_browse_none, array("colspan" => 7));
                $table->construct_row();
        }

        $table->output($lang->dragdrop_acp_browse_results." (".my_number_format($total).")");

        dragdrop_attach_acp_credit();
        $page->output_footer();
}

/* --------------------------------------------------------------------- */
/* Page 3: Group quotas                                                   */
/* --------------------------------------------------------------------- */

if($mybb->get_input('action') == "quotas")
{
        if($mybb->request_method == "post")
        {
                verify_post_check($mybb->get_input('my_post_key'));

                $pairs = array();

                $query = $db->simple_select("usergroups", "gid", "gid != '1'", array("order_by" => "gid", "order_dir" => "ASC"));

                while($group = $db->fetch_array($query))
                {
                        $gid = (int)$group['gid'];
                        $val = trim((string)$mybb->input['quota_'.$gid]);

                        if($val === "")
                        {
                                continue; // inherits the default quota
                        }

                        $mb = (float)str_replace(",", ".", $val);

                        if($mb <= 0)
                        {
                                continue; // zero means "no override" (default applies)
                        }

                        if($mb > 1000000)
                        {
                                $mb = 1000000; // sanity cap
                        }

                        $pairs[] = $gid."=".round($mb, 2);
                }

                $value = implode(",", $pairs);

                $db->update_query("settings", array("value" => $db->escape_string($value)), "name = 'dragdrop_attach_groupquotas'");
                rebuild_settings();

                log_admin_action($value);

                flash_message($lang->dragdrop_acp_quotas_saved, "success");
                admin_redirect($base_url."&action=quotas");
        }

        $page->output_header($lang->dragdrop_acp_menu);
        $page->output_nav_tabs($sub_tabs, 'quotas');

        $form = new Form($base_url."&amp;action=quotas", "post");

        // Current overrides: gid => MB
        $raw = trim((string)$mybb->settings['dragdrop_attach_groupquotas']);
        $overrides = array();

        if($raw !== "")
        {
                foreach(explode(",", $raw) as $pair)
                {
                        $pair = trim($pair);
                        if($pair === "" || strpos($pair, "=") === false)
                        {
                                continue;
                        }

                        list($gid, $mb) = explode("=", $pair, 2);

                        if((int)trim($gid) > 0 && (float)trim($mb) > 0)
                        {
                                $overrides[(int)trim($gid)] = (float)trim($mb);
                        }
                }
        }

        $default_mb = (float)$mybb->settings['dragdrop_attach_quota'];

        // Primary member counts per group (informational)
        $members = array();
        $query = $db->simple_select("users", "usergroup AS gid, COUNT(uid) AS cnt", "", array("group_by" => "usergroup"));
        while($row = $db->fetch_array($query))
        {
                $members[(int)$row['gid']] = (int)$row['cnt'];
        }

        echo '<form action="'.$base_url.'&amp;action=quotas" method="post">';

        $table = new Table;

        $table->construct_header($lang->dragdrop_acp_col_group);
        $table->construct_header($lang->dragdrop_acp_quotas_users, array("class" => "align_center"));
        $table->construct_header($lang->dragdrop_acp_col_quota, array("class" => "align_center"));
        $table->construct_header($lang->dragdrop_acp_col_effective, array("class" => "align_center"));

        $query = $db->simple_select("usergroups", "gid, title, attachquota", "gid != '1'", array("order_by" => "gid", "order_dir" => "ASC"));

        while($group = $db->fetch_array($query))
        {
                $gid = (int)$group['gid'];
                $mb = isset($overrides[$gid]) ? $overrides[$gid] : "";

                // Effective quota display
                if($mb !== "")
                {
                        $effective = '<strong>'.round((float)$mb, 2).' MB</strong>';
                }
                elseif($default_mb > 0)
                {
                        $effective = $default_mb.' MB <span class="smalltext">('.$lang->dragdrop_acp_quota_inherit.')</span>';
                }
                elseif((int)$group['attachquota'] > 0)
                {
                        $effective = round((int)$group['attachquota'] / 1024, 2).' MB <span class="smalltext">('.$lang->dragdrop_acp_quota_core.')</span>';
                }
                else
                {
                        $effective = $lang->dragdrop_acp_quotas_unlimited;
                }

                $table->construct_cell('<strong>'.htmlspecialchars_uni($group['title']).'</strong><br /><span class="smalltext">GID '.$gid.'</span>');
                $table->construct_cell(isset($members[$gid]) ? my_number_format($members[$gid]) : "0", array("class" => "align_center"));
                $table->construct_cell($form->generate_text_box('quota_'.$gid, $mb, array('style' => 'width: 80px; direction: ltr; text-align: center;')), array("class" => "align_center"));
                $table->construct_cell($effective, array("class" => "align_center"));

                $table->construct_row();
        }

        $table->output($lang->dragdrop_acp_tab_quotas);

        $buttons[] = $form->generate_submit_button($lang->dragdrop_acp_quotas_save);
        $form->output_submit_wrapper($buttons);
        $form->end();

        echo '<br /><div class="smalltext">'.$lang->dragdrop_acp_quotas_note.'</div>';

        if($default_mb > 0)
        {
                echo '<div class="smalltext">'.$lang->sprintf($lang->dragdrop_acp_quotas_default, $default_mb).'</div>';
        }
        else
        {
                echo '<div class="smalltext">'.$lang->dragdrop_acp_quotas_default_none.'</div>';
        }

        dragdrop_attach_acp_credit();
        $page->output_footer();
}

/* --------------------------------------------------------------------- */
/* Page 3b: Size limits (file types + max sizes + chunked uploads)        */
/* --------------------------------------------------------------------- */

if($mybb->get_input('action') == "limits")
{
        if($mybb->request_method == "post")
        {
                verify_post_check($mybb->get_input('my_post_key'));

                // Universal file type mode
                $alltypes = ($mybb->get_input('alltypes') == 1) ? 1 : 0;

                // Deny list — extra extensions (built-ins are always enforced)
                $deny = array();
                foreach(preg_split('#[\s,]+#', my_strtolower((string)$mybb->get_input('denyext'))) as $ext)
                {
                        $ext = preg_replace('#[^a-z0-9]#', '', $ext);
                        if($ext !== "" && !in_array($ext, dragdrop_attach_builtin_denied()))
                        {
                                $deny[] = $ext;
                        }
                }

                // Global per-file max size (MB)
                $maxsize = (float)str_replace(",", ".", (string)$mybb->get_input('maxsize'));

                if($maxsize < 0)
                {
                        $maxsize = 0;
                }

                if($maxsize > 1000000)
                {
                        $maxsize = 1000000; // sanity cap
                }

                // Per-extension size rules — "ext=MB" pairs
                $rules = array();
                foreach(preg_split('#[\r\n,]+#', (string)$mybb->get_input('extsizes')) as $pair)
                {
                        $pair = trim($pair);

                        if($pair === "" || strpos($pair, "=") === false)
                        {
                                continue;
                        }

                        list($ext, $mb) = explode("=", $pair, 2);
                        $ext = my_strtolower(preg_replace('#[^a-z0-9]#i', '', trim($ext)));
                        $mb  = (float)str_replace(",", ".", trim($mb));

                        if($ext !== "" && $mb > 0)
                        {
                                $rules[$ext] = round(min($mb, 1000000), 2);
                        }
                }

                // Chunked-upload slice threshold (MB)
                $chunk = (float)str_replace(",", ".", (string)$mybb->get_input('chunk'));

                if($chunk < 0)
                {
                        $chunk = 0;
                }

                if($chunk > 32)
                {
                        $chunk = 32; // must stay below realistic post_max_size values
                }

                $saved = array(
                        'dragdrop_attach_alltypes' => (string)$alltypes,
                        'dragdrop_attach_denyext'  => implode(",", $deny),
                        'dragdrop_attach_maxsize'  => (string)round($maxsize, 2),
                        'dragdrop_attach_extsizes' => implode(",", array_map(
                                function($ext, $mb) { return $ext."=".$mb; },
                                array_keys($rules),
                                array_values($rules)
                        )),
                        'dragdrop_attach_chunk'    => (string)round($chunk, 2)
                );

                foreach($saved as $name => $value)
                {
                        $db->update_query("settings", array("value" => $db->escape_string($value)), "name = '".$name."'");
                }

                rebuild_settings();
                log_admin_action(json_encode($saved));

                flash_message($lang->dragdrop_acp_limits_saved, "success");
                admin_redirect($base_url."&action=limits");
        }

        $page->output_header($lang->dragdrop_acp_menu);
        $page->output_nav_tabs($sub_tabs, 'limits');

        $upl = ini_get("upload_max_filesize");
        $post = ini_get("post_max_size");

        echo '<div class="alert alert-info" style="background:#eef4fa;border:1px solid #bcd4e6;border-radius:4px;padding:8px 12px;margin-bottom:10px;">'
                .$lang->dragdrop_acp_limits_info
                .'<br /><span class="smalltext">'
                .$lang->sprintf($lang->dragdrop_acp_limits_php, htmlspecialchars_uni($upl !== false && $upl !== "" ? $upl : "?"), htmlspecialchars_uni($post !== false && $post !== "" ? $post : "?"))
                .'</span></div>';

        $form = new Form($base_url."&amp;action=limits", "post");

        $form_container = new FormContainer($lang->dragdrop_acp_limits_types);

        $form_container->output_row(
                $lang->dragdrop_acp_limits_alltypes,
                $lang->dragdrop_acp_limits_alltypes_desc,
                $form->generate_onoff_radio('alltypes', (int)$mybb->settings['dragdrop_attach_alltypes'])
        );

        $form_container->output_row(
                $lang->dragdrop_acp_limits_denyext,
                $lang->dragdrop_acp_limits_denyext_desc,
                $form->generate_text_area('denyext', (string)$mybb->settings['dragdrop_attach_denyext'], array('style' => 'width: 99%; direction: ltr;', 'rows' => 3))
        );

        $form_container->end();

        $form_container = new FormContainer($lang->dragdrop_acp_limits_sizes);

        $form_container->output_row(
                $lang->dragdrop_acp_limits_maxsize,
                $lang->dragdrop_acp_limits_maxsize_desc,
                $form->generate_text_box('maxsize', (string)$mybb->settings['dragdrop_attach_maxsize'], array('style' => 'width: 90px; direction: ltr; text-align: center;'))
        );

        $form_container->output_row(
                $lang->dragdrop_acp_limits_extsizes,
                $lang->dragdrop_acp_limits_extsizes_desc,
                $form->generate_text_area('extsizes', (string)$mybb->settings['dragdrop_attach_extsizes'], array('style' => 'width: 99%; direction: ltr;', 'rows' => 4))
        );

        $form_container->output_row(
                $lang->dragdrop_acp_limits_chunk,
                $lang->dragdrop_acp_limits_chunk_desc,
                $form->generate_text_box('chunk', (string)$mybb->settings['dragdrop_attach_chunk'], array('style' => 'width: 90px; direction: ltr; text-align: center;'))
        );

        $form_container->end();

        $buttons[] = $form->generate_submit_button($lang->dragdrop_acp_limits_save);
        $form->output_submit_wrapper($buttons);
        $form->end();

        // Active per-extension rules overview
        $rules = dragdrop_attach_parse_extsizes();

        $table = new Table;

        $table->construct_header($lang->dragdrop_acp_col_ext);
        $table->construct_header($lang->dragdrop_acp_col_effective);

        if(empty($rules))
        {
                $table->construct_cell($lang->dragdrop_acp_limits_norules, array("colspan" => 2));
                $table->construct_row();
        }
        else
        {
                foreach($rules as $ext => $bytes)
                {
                        $table->construct_cell('<strong>'.htmlspecialchars_uni(my_strtoupper($ext)).'</strong>');
                        $table->construct_cell(get_friendly_size($bytes));
                        $table->construct_row();
                }
        }

        $table->output($lang->dragdrop_acp_limits_rules);

        echo '<div class="smalltext">'.$lang->dragdrop_acp_limits_note.'</div>';

        dragdrop_attach_acp_credit();
        $page->output_footer();
}

/* --------------------------------------------------------------------- */
/* Page 3c: Download gate — redirect page with a countdown (v2.3.0)      */
/* --------------------------------------------------------------------- */

if($mybb->get_input('action') == "dlwait_preview")
{
        // Live preview of the gate page with sample data (opens full-screen)
        echo dragdrop_attach_gate_html(array(
                "name"       => "aurora-design-guide.pdf",
                "ext"        => "pdf",
                "size"       => get_friendly_size(3 * 1024 * 1024 + 745 * 1024),
                "target"     => "#",
                "seconds"    => dragdrop_attach_gate_seconds(),
                "skip"       => (!isset($mybb->settings['dragdrop_attach_dlwait_skip']) || (int)$mybb->settings['dragdrop_attach_dlwait_skip'] == 1),
                "downloads"  => 42,
                "dir"        => ($lang->settings['dir'] === "rtl") ? "rtl" : "ltr",
                "bbname"     => (string)$mybb->settings['bbname'],
                "t_title"    => $lang->dragdrop_gate_title,
                "t_starts"   => $lang->dragdrop_gate_starts,
                "t_ready"    => $lang->dragdrop_gate_ready,
                "t_now"      => $lang->dragdrop_gate_now,
                "t_cancel"   => $lang->dragdrop_gate_cancel,
                "t_hint"     => $lang->dragdrop_gate_hint,
                "t_dl"       => $lang->dragdrop_gate_dlcount,
                "t_sec"      => isset($lang->dragdrop_unit_sec) ? $lang->dragdrop_unit_sec : "s"
        ));
        exit;
}

if($mybb->get_input('action') == "dlwait")
{
        if($mybb->request_method == "post")
        {
                verify_post_check($mybb->get_input('my_post_key'));

                $enabled = ($mybb->get_input('dlwait') == 1) ? 1 : 0;
                $seconds = (int)$mybb->get_input('dlwait_time');

                if($seconds < 1)
                {
                        $seconds = 1;
                }

                if($seconds > 60)
                {
                        $seconds = 60;
                }

                $skip = ($mybb->get_input('dlwait_skip') == 1) ? 1 : 0;

                $saved = array(
                        'dragdrop_attach_dlwait'      => (string)$enabled,
                        'dragdrop_attach_dlwait_time' => (string)$seconds,
                        'dragdrop_attach_dlwait_skip' => (string)$skip
                );

                foreach($saved as $name => $value)
                {
                        $db->update_query("settings", array("value" => $db->escape_string($value)), "name = '".$name."'");
                }

                rebuild_settings();
                log_admin_action(json_encode($saved));

                flash_message($lang->dragdrop_acp_dlwait_saved, "success");
                admin_redirect($base_url."&action=dlwait");
        }

        $page->output_header($lang->dragdrop_acp_menu);
        $page->output_nav_tabs($sub_tabs, 'dlwait');

        echo '<div class="alert alert-info" style="background:#eef4fa;border:1px solid #bcd4e6;border-radius:4px;padding:8px 12px;margin-bottom:10px;">'.$lang->dragdrop_acp_dlwait_info.'</div>';

        $form = new Form($base_url."&amp;action=dlwait", "post");

        $form_container = new FormContainer($lang->dragdrop_acp_dlwait_general);

        $form_container->output_row(
                $lang->dragdrop_acp_dlwait_enable,
                $lang->dragdrop_acp_dlwait_enable_desc,
                $form->generate_onoff_radio('dlwait', isset($mybb->settings['dragdrop_attach_dlwait']) ? (int)$mybb->settings['dragdrop_attach_dlwait'] : 1)
        );

        $form_container->output_row(
                $lang->dragdrop_acp_dlwait_time,
                $lang->dragdrop_acp_dlwait_time_desc,
                $form->generate_text_box('dlwait_time', (string)dragdrop_attach_gate_seconds(), array('style' => 'width: 90px; direction: ltr; text-align: center;'))
        );

        $form_container->output_row(
                $lang->dragdrop_acp_dlwait_skip,
                $lang->dragdrop_acp_dlwait_skip_desc,
                $form->generate_onoff_radio('dlwait_skip', isset($mybb->settings['dragdrop_attach_dlwait_skip']) ? (int)$mybb->settings['dragdrop_attach_dlwait_skip'] : 1)
        );

        $form_container->end();

        $buttons[] = $form->generate_submit_button($lang->dragdrop_acp_dlwait_save);
        $form->output_submit_wrapper($buttons);
        $form->end();

        echo '<br /><a class="button button-secondary" href="'.$base_url.'&amp;action=dlwait_preview" target="_blank" style="display:inline-block;padding:7px 18px;border:1px solid #bcd4e6;border-radius:4px;background:#f6fafd;text-decoration:none;">'.$lang->dragdrop_acp_dlwait_preview.' &#8599;</a>';

        echo '<br /><br /><div class="smalltext">'.$lang->dragdrop_acp_dlwait_scope.'</div>';

        dragdrop_attach_acp_credit();
        $page->output_footer();
}

/* --------------------------------------------------------------------- */
/* Page 3d: License & anti-theft protection (v2.5.0, hard lock)           */
/* --------------------------------------------------------------------- */

if($mybb->get_input('action') == "license")
{
        // Module may be missing/tampered — only the validator is optional;
        // status/ok always exist (fallback stubs in the plugin file).
        $lic_module_ok = function_exists("dragdrop_attach_lic_validate");

        if($mybb->request_method == "post")
        {
                verify_post_check($mybb->get_input('my_post_key'));

                if(!$lic_module_ok)
                {
                        flash_message($lang->dragdrop_acp_lic_module_missing, "error");
                        admin_redirect($base_url."&action=license");
                }

                // --- license key (empty input = clear the stored key) ---
                $key = trim((string)$mybb->get_input('lickey'));

                if($key !== "")
                {
                        if(dragdrop_attach_lic_validate($key) === "")
                        {
                                flash_message($lang->dragdrop_acp_lic_invalid, "error");
                                admin_redirect($base_url."&action=license");
                        }
                }

                $saved = array(
                        'dragdrop_attach_license' => $key
                );

                foreach($saved as $sname => $svalue)
                {
                        $db->update_query("settings", array("value" => $db->escape_string($svalue)), "name = '".$sname."'");
                }

                rebuild_settings();
                log_admin_action(json_encode($saved));

                if($key !== "")
                {
                        flash_message($lang->dragdrop_acp_lic_saved, "success");
                }
                else
                {
                        flash_message($lang->dragdrop_acp_lic_cleared, "success");
                }

                admin_redirect($base_url."&action=license");
        }

        $page->output_header($lang->dragdrop_acp_menu);
        $page->output_nav_tabs($sub_tabs, 'license');

        $st = dragdrop_attach_license_status();

        // ---- status card ----
        $cards = array(
                "licensed" => array($lang->dragdrop_acp_lic_state_licensed, "#0a7d32", "#e8f7ee", "#bfe3cc"),
                "locked"   => array($lang->dragdrop_acp_lic_state_locked,   "#b3261e", "#fdecea", "#f2c4bf"),
                "dev"      => array($lang->dragdrop_acp_lic_state_dev,      "#1c5bd8", "#e9f0fe", "#c3d6f7"),
                "missing"  => array($lang->dragdrop_acp_lic_state_missing,  "#b3261e", "#fdecea", "#f2c4bf"),
        );

        $card = isset($cards[$st['state']]) ? $cards[$st['state']] : $cards['locked'];

        $detail = "";

        switch($st['state'])
        {
                case "licensed":
                        $detail = $st['master']
                                ? $lang->dragdrop_acp_lic_licensed_master
                                : $lang->sprintf($lang->dragdrop_acp_lic_licensed_domain, htmlspecialchars_uni($st['domain']));
                        break;

                case "locked":
                        $detail = $lang->dragdrop_acp_lic_locked_detail;
                        break;

                case "dev":
                        $detail = $lang->dragdrop_acp_lic_dev_note;
                        break;

                case "missing":
                        $detail = $lang->dragdrop_acp_lic_module_missing;
                        break;
        }

        echo '<div style="border:1px solid '.$card[3].';border-radius:6px;background:'.$card[2].';padding:12px 14px;margin-bottom:12px;">'
                .'<span style="display:inline-block;padding:3px 12px;border-radius:999px;color:#fff;font-weight:bold;background:'.$card[1].';">'.htmlspecialchars_uni($card[0]).'</span>'
                .'<div style="margin-top:8px;">'.$detail.'</div>'
                .'</div>';

        echo '<div class="alert alert-info" style="background:#eef4fa;border:1px solid #bcd4e6;border-radius:4px;padding:8px 12px;margin-bottom:10px;">'
                .$lang->dragdrop_acp_lic_domain_label
                .' <code style="direction:ltr;unicode-bidi:embed;padding:2px 8px;background:#fff;border:1px solid #d5dbe2;border-radius:4px;">'.($st['domain'] !== "" ? htmlspecialchars_uni($st['domain']) : "?").'</code>'
                .'<br /><span class="smalltext">'.$lang->dragdrop_acp_lic_domain_hint.'</span></div>';

        $form = new Form($base_url."&amp;action=license", "post");

        $form_container = new FormContainer($lang->dragdrop_acp_lic_form);

        $form_container->output_row(
                $lang->dragdrop_acp_lic_key,
                $lang->dragdrop_acp_lic_key_desc,
                $form->generate_text_box('lickey', (string)(isset($mybb->settings['dragdrop_attach_license']) ? $mybb->settings['dragdrop_attach_license'] : ""), array('style' => 'width: 420px; direction: ltr;'))
        );

        $form_container->end();

        $buttons[] = $form->generate_submit_button($lang->dragdrop_acp_lic_save);
        $form->output_submit_wrapper($buttons);
        $form->end();

        echo '<br /><div class="smalltext">'.$lang->dragdrop_acp_lic_howto.'</div>';

        dragdrop_attach_acp_credit();
        $page->output_footer();
}

/* --------------------------------------------------------------------- */
/* Page 4: Upload activity log                                            */
/* --------------------------------------------------------------------- */

if($mybb->get_input('action') == "logs")
{
        // ---- POST actions: prune / clear ------------------------------------
        if($mybb->request_method == "post")
        {
                verify_post_check($mybb->get_input('my_post_key'));

                $do = (string)$mybb->get_input('do');

                if($do == "clear")
                {
                        $db->delete_query("dragdrop_log", "1=1");

                        log_admin_action("clear");

                        flash_message($lang->dragdrop_acp_logs_cleared, "success");
                        admin_redirect($base_url."&action=logs");
                }

                if($do == "prune")
                {
                        $days = (int)$mybb->settings['dragdrop_attach_logdays'];

                        if($days > 0)
                        {
                                $db->delete_query("dragdrop_log", "dateline < '".(TIME_NOW - ($days * 86400))."'");
                        }

                        log_admin_action("prune", $days);

                        flash_message($lang->sprintf($lang->dragdrop_acp_logs_pruned, $days), "success");
                        admin_redirect($base_url."&action=logs");
                }

                admin_redirect($base_url."&action=logs");
        }

        $page->output_header($lang->dragdrop_acp_menu);
        $page->output_nav_tabs($sub_tabs, 'logs');

        if(!dragdrop_attach_logging_enabled())
        {
                $page->output_alert(
                        $lang->dragdrop_acp_logs_disabled.
                        ' <a href="index.php?module=config-settings&amp;action=change&amp;gid='.((int)$db->fetch_field($db->simple_select("settinggroups", "gid", "name = 'dragdrop_attach'"), "gid")).'">'.$lang->dragdrop_acp_stats_settings_link.'</a>'
                );
        }

        $days = (int)$mybb->settings['dragdrop_attach_logdays'];

        // ---- Action bar: prune + clear (one small form each) ------------------
        echo '<div style="margin-bottom:8px;">';

        $form_prune = new Form($base_url."&amp;action=logs&amp;do=prune", "post", "dda_logs_prune");
        echo $form_prune->generate_submit_button($lang->sprintf($lang->dragdrop_acp_logs_prune, $days > 0 ? $days : 30), array('class' => 'button_no'));
        $form_prune->end();

        echo ' ';

        $form_clear = new Form($base_url."&amp;action=logs&amp;do=clear", "post", "dda_logs_clear");
        echo $form_clear->generate_submit_button($lang->dragdrop_acp_logs_clear, array('class' => 'button_yes', 'onclick' => "return confirm('".str_replace("'", "\\'", $lang->dragdrop_acp_logs_clear_confirm)."');"));
        $form_clear->end();

        echo '</div>';

        // ---- Filters (GET) ---------------------------------------------------
        $where = "1=1";

        $f_status = (string)$mybb->get_input('status');
        if(in_array($f_status, array("ok", "denied", "error")))
        {
                $where .= " AND status = '".$db->escape_string($f_status)."'";
        }

        $f_ctx = (string)$mybb->get_input('ctx');
        if(in_array($f_ctx, array("post", "pm")))
        {
                $where .= " AND context = '".$db->escape_string($f_ctx)."'";
        }

        $q = trim((string)$mybb->get_input('q'));
        if($q !== "")
        {
                $escaped = $db->escape_string_like($q);
                $where .= " AND (username LIKE '%".$escaped."%' OR filename LIKE '%".$escaped."%')";
        }

        // ---- Table -----------------------------------------------------------
        $total = (int)$db->fetch_field(
                $db->simple_select("dragdrop_log", "COUNT(lid) AS total", $where),
                "total"
        );

        $perpage = 25;
        $pages = $perpage > 0 ? (int)ceil($total / $perpage) : 1;
        $current_page = (int)$mybb->get_input('page', MyBB::INPUT_INT);

        if($current_page < 1)
        {
                $current_page = 1;
        }
        if($current_page > $pages)
        {
                $current_page = $pages;
        }
        $start = ($current_page - 1) * $perpage;

        $query = $db->simple_select(
                "dragdrop_log",
                "*",
                $where,
                array("order_by" => "dateline", "order_dir" => "DESC", "limit_start" => $start, "limit" => $perpage)
        );

        if($total > $perpage)
        {
                echo draw_admin_pagination($current_page, $perpage, $total, $base_url."&amp;action=logs&amp;status=".urlencode($f_status)."&amp;ctx=".urlencode($f_ctx)."&amp;q=".urlencode($q));
        }

        $table = new Table;

        $table->construct_header($lang->dragdrop_acp_col_date);
        $table->construct_header($lang->dragdrop_acp_col_user);
        $table->construct_header($lang->dragdrop_acp_col_file);
        $table->construct_header($lang->dragdrop_acp_browse_context);
        $table->construct_header($lang->dragdrop_acp_logs_status);
        $table->construct_header($lang->dragdrop_acp_col_ip);
        $table->construct_header($lang->dragdrop_acp_logs_detail);

        $count = 0;

        while($log = $db->fetch_array($query))
        {
                ++$count;

                $file_cell = '<span style="direction:ltr;">'.htmlspecialchars_uni($log['filename']).'</span><br /><span class="smalltext">'.get_friendly_size((int)$log['filesize']).'</span>';
                $detail = ($log['message'] !== "") ? '<span title="'.htmlspecialchars_uni($log['message']).'">'.htmlspecialchars_uni(my_substr($log['message'], 0, 60)).'</span>' : "&mdash;";

                $table->construct_cell(my_date("relative", (int)$log['dateline']));
                $table->construct_cell('<a href="index.php?module=user-users&amp;action=edit&amp;uid='.(int)$log['uid'].'">'.htmlspecialchars_uni($log['username'] !== "" ? $log['username'] : "#".(int)$log['uid']).'</a>');
                $table->construct_cell($file_cell);
                $table->construct_cell($log['context'] == "pm" ? $lang->dragdrop_acp_browse_inpm : $lang->dragdrop_acp_browse_inpost, array("class" => "align_center"));
                $table->construct_cell(dragdrop_attach_acp_badge($log['status']), array("class" => "align_center"));
                $table->construct_cell('<span style="direction:ltr;">'.htmlspecialchars_uni((string)$log['ipaddress']).'</span>', array("class" => "align_center"));
                $table->construct_cell($detail);

                $table->construct_row();
        }

        if($count === 0)
        {
                $table->construct_cell($lang->dragdrop_acp_logs_none, array("colspan" => 7));
                $table->construct_row();
        }

        $table->output($lang->dragdrop_acp_tab_logs." (".my_number_format($total).")");

        // ---- Filter form (GET) ------------------------------------------------
        echo '<form action="index.php" method="get">';
        echo '<input type="hidden" name="module" value="tools-dragdrop_attach" />';
        echo '<input type="hidden" name="action" value="logs" />';

        $filter_form = new Form("", "get", "", 0, "", true);

        $status_options = array(
                "" => $lang->dragdrop_acp_logs_status_all,
                "ok" => $lang->dragdrop_acp_log_ok,
                "denied" => $lang->dragdrop_acp_log_denied,
                "error" => $lang->dragdrop_acp_log_error
        );

        $ctx_options = array(
                "" => $lang->dragdrop_acp_browse_ctx_all,
                "post" => $lang->dragdrop_acp_browse_inpost,
                "pm" => $lang->dragdrop_acp_browse_inpm
        );

        echo '<table style="width:100%;" class="general"><tr>';
        echo '<td>'.$filter_form->generate_text_box('q', htmlspecialchars_uni($q), array('placeholder' => $lang->dragdrop_acp_logs_search)).'</td>';
        echo '<td>'.$filter_form->generate_select_box('status', $status_options, $f_status).'</td>';
        echo '<td>'.$filter_form->generate_select_box('ctx', $ctx_options, $f_ctx).'</td>';
        echo '<td>'.$filter_form->generate_submit_button($lang->dragdrop_acp_browse_apply).'</td>';
        echo '</tr></table>';
        echo '</form>';

        if(dragdrop_attach_logging_enabled() && $days > 0)
        {
                echo '<div class="smalltext" style="margin-top:6px;">'.$lang->sprintf($lang->dragdrop_acp_logs_keep, $days).'</div>';
        }

        dragdrop_attach_acp_credit();
        $page->output_footer();
}

/* --------------------------------------------------------------------- */
/* Page 5: Tools & maintenance                                            */
/* --------------------------------------------------------------------- */

if($mybb->get_input('action') == "tools")
{
        if($mybb->request_method == "post")
        {
                verify_post_check($mybb->get_input('my_post_key'));

                $do = (string)$mybb->get_input('do');

                // ---- Delete orphaned files (re-scanned at execution time) --------
                if($do == "orphan_clean")
                {
                        require_once MYBB_ROOT."inc/functions_upload.php";

                        $cutoff = TIME_NOW - (3 * 86400);
                        $files = dragdrop_attach_acp_scan_orphans($cutoff);

                        $deleted = 0;
                        $freed = 0;

                        foreach($files as $f)
                        {
                                if(strpos($f['rel'], "..") !== false || strpos($f['rel'], "\\") !== false)
                                {
                                        continue; // safety: never touch anything outside uploads
                                }

                                // Re-verify that nothing references the file
                                $refs = (int)$db->fetch_field(
                                        $db->simple_select("attachments", "COUNT(aid) AS refs", "attachname = '".$db->escape_string($f['rel'])."' OR thumbnail = '".$db->escape_string($f['rel'])."'"),
                                        "refs"
                                );

                                if($refs > 0)
                                {
                                        continue;
                                }

                                delete_uploaded_file($f['abs']);
                                $deleted++;
                                $freed += (int)$f['size'];
                        }

                        log_admin_action("orphan_clean", $deleted, $freed);

                        flash_message($lang->sprintf($lang->dragdrop_acp_orphans_deleted, my_number_format($deleted), get_friendly_size($freed)), "success");
                        admin_redirect($base_url."&action=tools");
                }

                // ---- Clean orphaned PM mapping rows ------------------------------
                if($do == "pm_integrity")
                {
                        $pmaid_orphans = array();

                        // 1. Mappings whose attachment row is gone
                        $query = $db->query("
                                SELECT m.pmaid
                                FROM ".TABLE_PREFIX."dragdrop_pm m
                                LEFT JOIN ".TABLE_PREFIX."attachments a ON (a.aid = m.aid)
                                WHERE a.aid IS NULL
                        ");

                        while($row = $db->fetch_array($query))
                        {
                                $pmaid_orphans[] = (int)$row['pmaid'];
                        }

                        // 2. Mappings whose PM row is gone (sent copies and drafts alike)
                        $query = $db->query("
                                SELECT m.pmaid
                                FROM ".TABLE_PREFIX."dragdrop_pm m
                                LEFT JOIN ".TABLE_PREFIX."privatemessages pm ON (pm.pmid = m.pmid)
                                WHERE pm.pmid IS NULL
                        ");

                        while($row = $db->fetch_array($query))
                        {
                                $pmaid_orphans[] = (int)$row['pmaid'];
                        }

                        $pmaid_orphans = array_values(array_unique($pmaid_orphans));

                        if(!empty($pmaid_orphans))
                        {
                                $db->delete_query("dragdrop_pm", "pmaid IN (".implode(",", $pmaid_orphans).")");
                        }

                        $fixed = count($pmaid_orphans);

                        log_admin_action("pm_integrity", $fixed);

                        flash_message($lang->sprintf($lang->dragdrop_acp_pm_fixed, my_number_format($fixed)), "success");
                        admin_redirect($base_url."&action=tools");
                }

                // ---- Reinstall the plugin templates ------------------------------
                if($do == "templates_reinstall")
                {
                        dragdrop_attach_install_templates();

                        log_admin_action("templates_reinstall");

                        flash_message($lang->dragdrop_acp_tpl_reinstalled, "success");
                        admin_redirect($base_url."&action=tools");
                }

                admin_redirect($base_url."&action=tools");
        }

        $page->output_header($lang->dragdrop_acp_menu);
        $page->output_nav_tabs($sub_tabs, 'tools');

        // ==================================================================
        // Card 1: orphaned files
        // ==================================================================
        $orphan_scan = null;

        if($mybb->get_input('do') == "orphan_scan")
        {
                $orphan_scan = dragdrop_attach_acp_scan_orphans(TIME_NOW - (3 * 86400));
        }

        $table = new Table;
        $table->construct_cell('<strong>'.$lang->dragdrop_acp_tools_orphans_title.'</strong><br /><span class="smalltext">'.$lang->dragdrop_acp_tools_orphans_desc.'</span>');
        $table->construct_row();

        if(is_array($orphan_scan))
        {
                if(empty($orphan_scan))
                {
                        $table->construct_cell($lang->dragdrop_acp_tools_orphans_none);
                        $table->construct_row();
                }
                else
                {
                        $total_size = 0;

                        foreach($orphan_scan as $f)
                        {
                                $total_size += (int)$f['size'];
                        }

                        $table->construct_cell('<span style="color:#d9534f;font-weight:bold;">'.$lang->sprintf($lang->dragdrop_acp_tools_orphans_found, my_number_format(count($orphan_scan)), get_friendly_size($total_size)).'</span>');
                        $table->construct_row();

                        // Preview list (first 50)
                        foreach(array_slice($orphan_scan, 0, 50) as $f)
                        {
                                $table->construct_cell('<span style="direction:ltr;font-family:monospace;font-size:11px;">uploads/'.htmlspecialchars_uni($f['rel']).'</span> <span class="smalltext">('.get_friendly_size((int)$f['size']).')</span>');
                                $table->construct_row();
                        }

                        if(count($orphan_scan) > 50)
                        {
                                $table->construct_cell('<span class="smalltext">+'.my_number_format(count($orphan_scan) - 50).' …</span>');
                                $table->construct_row();
                        }
                }
        }

        // Card 1 action: GET scan link, or POST clean button inside the form
        $orphan_form = new Form($base_url."&amp;action=tools&amp;do=orphan_clean", "post", "dda_orphan_clean");

        if(is_array($orphan_scan) && !empty($orphan_scan))
        {
                $table->construct_cell($orphan_form->generate_submit_button($lang->sprintf($lang->dragdrop_acp_tools_delete_orphans, count($orphan_scan)), array('class' => 'button_yes')));
        }
        else
        {
                $table->construct_cell('<a href="'.$base_url.'&amp;action=tools&amp;do=orphan_scan" class="button button_no">'.$lang->dragdrop_acp_tools_scan.'</a>');
        }

        $table->construct_row();
        $table->output($lang->dragdrop_acp_tools_orphans_card);

        $orphan_form->end();

        // ==================================================================
        // Card 2: PM mapping integrity
        // ==================================================================
        $orphan_maps = 0;

        $query = $db->query("
                SELECT COUNT(*) AS cnt
                FROM ".TABLE_PREFIX."dragdrop_pm m
                LEFT JOIN ".TABLE_PREFIX."attachments a ON (a.aid = m.aid)
                WHERE a.aid IS NULL
        ");
        $orphan_maps += (int)$db->fetch_field($query, "cnt");

        $query = $db->query("
                SELECT COUNT(*) AS cnt
                FROM ".TABLE_PREFIX."dragdrop_pm m
                LEFT JOIN ".TABLE_PREFIX."privatemessages pm ON (pm.pmid = m.pmid)
                WHERE pm.pmid IS NULL
        ");
        $orphan_maps += (int)$db->fetch_field($query, "cnt");

        $pm_form = new Form($base_url."&amp;action=tools&amp;do=pm_integrity", "post", "dda_pm_fix");

        $table = new Table;
        $table->construct_cell('<strong>'.$lang->dragdrop_acp_tools_pm_title.'</strong><br /><span class="smalltext">'.$lang->dragdrop_acp_tools_pm_desc.'</span>');
        $table->construct_row();

        $table->construct_cell($orphan_maps > 0
                ? '<span style="color:#d9534f;font-weight:bold;">'.$lang->sprintf($lang->dragdrop_acp_tools_pm_issues, my_number_format($orphan_maps)).'</span>'
                : $lang->dragdrop_acp_tools_pm_ok);
        $table->construct_row();

        if($orphan_maps > 0)
        {
                $table->construct_cell($pm_form->generate_submit_button($lang->sprintf($lang->dragdrop_acp_tools_pm_fix, my_number_format($orphan_maps)), array('class' => 'button_yes')));
        }
        else
        {
                $table->construct_cell('<span class="smalltext" style="color:#5da05f;">&#10003; '.$lang->dragdrop_acp_tools_pm_ok.'</span>');
        }

        $table->construct_row();
        $table->output($lang->dragdrop_acp_tools_pm_card);

        $pm_form->end();

        // ==================================================================
        // Card 3: plugin templates
        // ==================================================================
        $titles = array();
        foreach(dragdrop_attach_default_templates() as $title => $body)
        {
                $titles[] = $db->escape_string($title);
        }

        $found_templates = 0;

        if(!empty($titles))
        {
                $found_templates = (int)$db->fetch_field(
                        $db->simple_select("templates", "COUNT(tid) AS cnt", "sid = '-2' AND title IN ('".implode("','", $titles)."')"),
                        "cnt"
                );
        }

        $expected_templates = count($titles);

        $tpl_form = new Form($base_url."&amp;action=tools&amp;do=templates_reinstall", "post", "dda_tpl_reinstall");

        $table = new Table;
        $table->construct_cell('<strong>'.$lang->dragdrop_acp_tools_tpl_title.'</strong><br /><span class="smalltext">'.$lang->dragdrop_acp_tools_tpl_desc.'</span>');
        $table->construct_row();

        $table->construct_cell($found_templates >= $expected_templates
                ? $lang->sprintf($lang->dragdrop_acp_tools_tpl_ok, $expected_templates)
                : '<span style="color:#d9534f;font-weight:bold;">'.$lang->sprintf($lang->dragdrop_acp_tools_tpl_missing, $found_templates, $expected_templates).'</span>');
        $table->construct_row();

        $table->construct_cell($tpl_form->generate_submit_button($lang->dragdrop_acp_tools_tpl_reinstall, array('class' => 'button_no')));
        $table->construct_row();
        $table->output($lang->dragdrop_acp_tools_tpl_card);

        $tpl_form->end();

        // ==================================================================
        // Card 4: diagnostics (read-only)
        // ==================================================================
        dragdrop_attach_acp_render_diagnostics();

        dragdrop_attach_acp_credit();
        $page->output_footer();
}
